
//  Producers.cpp

#include "pch.h"

//======================  CProductData  ==================================

CProductData::CProductData(GoodID ID = -1) : _productID(ID)
{
	active = false;

	initMonth = -1;
	availableAtStep = -1;
	delayMonths = 0;
	totalWorkPerUnit = 0;
	lifetimeSteps = 0;

	delayedProductQuantity = 0;
	productDeliveryTimestep = 0;
	RetainedEmployees = 0;
	AccumulatedWork = 0;
	ProductionPrice = 0;

	nonConsumedPerUnit.clear();
	consumedPerUnit.clear();
	consumedCostFraction.clear();
};
CProductData::~CProductData() {}

//======================  CProducer  ===================================

CProducer::CProducer(GoodID gId, GoodID ID, CGeneration* pGenerat,
	CTrader* manager)
	: CTrader(Producer, ID, pGenerat), _producerType(gId)
{
	_LastUsedTimestep = 0;
	_InitCapital = 0;
	_TotalRetainedWorkers = 0;
	_NoFirstDemandYet = true;
}

CProducer::CProducer(const CProducer& prototy)
	: CTrader(Producer, prototy._ID, CivData::pCivData->pGeneration),
	_producerType(prototy._producerType)
{
	_Manager = nullptr;
	_InitCapital = 0;

	//0614 setMyPriceOf(workers_n, _pGeneration->initSalary());
	_myPrice[workers_n] = _pGeneration->initSalary();

	_vEmployees = prototy._vEmployees;
	_TotalRetainedWorkers = 0;
	immobilizedMinimums = prototy.immobilizedMinimums;
	_ImmobilizedGoods = prototy._ImmobilizedGoods;

	_Goods_to_be_produced = prototy._Goods_to_be_produced;
	_ListOfGoods_to_buy = prototy._ListOfGoods_to_buy;
	_Goods_I_have = prototy._Goods_I_have;
	_Goods_to_sell = prototy._Goods_to_sell;

	_myPrice = prototy._myPrice;
	_myPriceAdapt = prototy._myPriceAdapt;

	_LastUsedTimestep = _pGeneration->CurrentTimestep;
	_NoFirstDemandYet = true;

	for (auto PDatPair : prototy.myProductsData)
	{
		GoodID gID = PDatPair.first;
		myProductsData[gID] = new CProductData(*PDatPair.second);
	}
}

CProducer::~CProducer()
{
}

double CProducer::StartupProducerPrice(CTrader* pManager) const
{
	// Here defined as the production cost of 2 units of each product
	// TODO: add immobileMinimum 

	double producerPrice = 0;

	for (auto prodPair : myProductsData)
	{
		GoodID productID = prodPair.first;

		const GoodValue productQuantity = 1;
		double productionCostOfID = 0;

		// Round inputs up to the productUnits produced by integer inputs
		// (especially the number of workers_n)
		GoodValue usedWorkers;
		if (myProductsData.at(productID)->totalWorkPerUnit > 0)
		{
			usedWorkers = productQuantity *
				myProductsData.at(productID)->totalWorkPerUnit;
			productionCostOfID +=
				usedWorkers * pManager->myCurrentPriceOf(workers_n);
		}
		else
		{
			usedWorkers = ceil(productQuantity *
				myProductsData.at(productID)->nonConsumedPerUnit[workers_n]);
			productionCostOfID += usedWorkers * (1 + myProductsData.at(productID)
				->delayMonths) * pManager->myCurrentPriceOf(workers_n);
		}

		const map<GoodID, double>& ConsumedPerUnit =
			myProductsData.at(productID)->consumedPerUnit;
		for (auto inPair : ConsumedPerUnit)
		{
			GoodID inputID = inPair.first;
			if (ConsumedPerUnit.at(inputID) == 0)
				continue;

			double priceOfInputID = 0;
			if (_pGeneration->CurrentTimestep > 0)
			{
				priceOfInputID = CivData::pCivData->pCurrentGenerationData->MarketPrices[inputID]
					.at(_pGeneration->CurrentTimestep - 1);
				if (priceOfInputID == 0)
					return 9e9;// inputID not available yet
			}

			// Round up to the finalProductQuantity produced by integer inputs
			GoodValue usedOfID = ceil(productQuantity * ConsumedPerUnit.at(inputID));

			double consumedCostFraction = 1.0;
			if (myProductsData.at(productID)->consumedCostFraction.find(inputID)
				!= myProductsData.at(productID)->consumedCostFraction.end())
				consumedCostFraction =
				myProductsData.at(productID)->consumedCostFraction[inputID];

			productionCostOfID += usedOfID * consumedCostFraction * priceOfInputID;
		}

		producerPrice += productionCostOfID;
	}

	return producerPrice;
}

GoodValue CProducer::clearVariablesOfProductID(GoodID _productID)
{
	myProductsData[_productID]->active = false;

	myProductsData[_productID]->delayedProductQuantity = 0;
	myProductsData[_productID]->productDeliveryTimestep = 0;
	myProductsData[_productID]->ProductionPrice = 0;
	myProductsData[_productID]->AccumulatedWork = 0;

	_TotalRetainedWorkers -= myProductsData[_productID]->RetainedEmployees;

	GoodValue returnedEmployees =
		myProductsData[_productID]->RetainedEmployees;
	myProductsData[_productID]->RetainedEmployees = 0;
	return returnedEmployees;
}

double CProducer::initialPriceOfProductID(GoodID productID)
{
	double workTime;
	if (myProductsData.at(productID)->totalWorkPerUnit > 0)
		workTime = myProductsData.at(productID)->totalWorkPerUnit;
	else
		workTime = myProductsData[productID]->nonConsumedPerUnit[workers_n]
		* (1 + myProductsData[productID]->delayMonths);

	double productPrice = myCurrentPriceOf(workers_n) * workTime;

	for (auto inGood : myProductsData[productID]->consumedPerUnit)
	{
		GoodID consumedID = inGood.first;
		GoodValue consumedQuantity = inGood.second;
		if (CivData::pCivData->ProducerType_of_this_productID[consumedID] == this->_ID)
			continue;// neglect seed cost

		double consumedCost = 1.0;
		if (myProductsData[productID]->consumedCostFraction.find(consumedID)
			!= myProductsData[productID]->consumedCostFraction.end())
			consumedCost = myProductsData[productID]->consumedCostFraction[consumedID];
		if (_Manager != nullptr)
			productPrice += consumedQuantity * consumedCost
			* _Manager->myCurrentPriceOf(consumedID);
	}

	myProductsData[productID]->ProductionPrice = productPrice;
	setMyPriceOf(productID, myProductsData[productID]->ProductionPrice);

	return productPrice;
}

bool CProducer::IsActiveProducer()
{
	for (auto productPair : myProductsData)
		if (productPair.second->active)
			return true;

	return false;
}

// Activity  ---------------------------------------------------------------


void CProducer::MonthlyActivity()
{
	//assert(_pGeneration->CheckGenerationBalance());

	MakeListOfInteractingIndivsAndProducers();

	MakeListOfDemandsForMyProducts();

	if (_NoFirstDemandYet) return;

	MakeListOfGoodsToBuy();// input goods, based on products demand

	BuyGoods();

	RunProducer();

	BuyGoods();// more input goods as recommended by producer

	SellMyProductsToInteractingNeighbors();

	ReturnLoansToMyBank();

	TransferProfitToManager();

	if (_pGeneration->CurrentMonth == 11)
		PayAnnualTax();

	assert(_pGeneration->CheckGenerationBalance());
}

GoodValue CProducer::TransferProfitToManager()
{
	GoodValue currentDebt = -_pUsedBank->ClientCurrentBalance(this);

	if (currentDebt > 0 || Cash() <= 2 * _MinCash)
		return 0;

	GoodValue retProfit = Cash() - _MinCash;

	CBankEntry accStatus =
		_Manager->_pUsedBank->ClientCashOperation(_Manager, retProfit);
	if (accStatus._operationOK) // if Manager balance = 0, account closed
	{
		_Manager->_myBankAccountStatus = accStatus;
		Cash() -= retProfit;

		assert(_pGeneration->CheckGenerationBalance());
		return retProfit;
	}

	return retProfit;
}

void CProducer::MakeListOfDemandsForMyProducts()
{
	// Ask each neighbor the quantity demanded for each product
	GoodValue neighborPurchaseMax = 0;

	// Prepare a blank list with all my products
	for (auto productData : myProductsData)
	{
		//_Goods_to_be_produced[productData.first] = 0;
		_Goods_to_sell[productData.first];// productID needs to be available
	}

	for (auto& gn : _Goods_to_be_produced)
	{
		GoodID productID = gn.first;

		if (_Goods_to_be_produced(productID) == 0)
		{
			assert(productID != workers_n);// money and workers are not produced

			for (auto nNei : _InteractingTraders)
			{
				CTrader& neighbor = *nNei.second;

				neighborPurchaseMax = neighbor._ListOfGoods_to_buy(productID);
				if (neighborPurchaseMax <= 0)
					continue;

				_Goods_to_be_produced[productID] += neighborPurchaseMax;
				if (_NoFirstDemandYet)
				{
					// there has been demand for this Producer at least once
					_MinCash = 0;//0602 _InitCapital / 2; get ready to start production
					_NoFirstDemandYet = false;
				}
			}
		}

		_Goods_to_be_produced[productID] = max((GoodValue)0,
			_Goods_to_be_produced(productID) - _Goods_to_sell(productID));

		if (!CivData::pCivData->bSingleRobot)
			_Goods_to_be_produced[productID] =
			min<GoodValue>(_Goods_to_be_produced(productID),
				_InitCapital / _myPrice.at(productID));
	}
}

void CProducer::MakeListOfGoodsToBuy()
{
	_ListOfGoods_to_buy -= _ListOfGoods_to_buy;// reset to 0

	if (_Goods_to_be_produced.size() == 0)
		return;

	// 1. Leave only those _Goods_to_be_produced > 0 that can be started this month

	// 2. Prepare the _ListOfGoods_to_buy list of input quantities needed for this month

	vector<GoodID> productIDs;
	for (auto productdataPair : myProductsData)
		productIDs.push_back(productdataPair.first);

	shuffle(productIDs.begin(), productIDs.end(), CivData::pCivData->myRandomEngine);

	for (auto productID : productIDs)
	{
		GoodValue desiredProductUnits = _Goods_to_be_produced(productID);
		if (desiredProductUnits <= 0)
			continue;

		// Ask only for those _productID not running that can be started now.
		if (myProductsData[productID]->active || // If production of productID is underway or...
			(myProductsData[productID]->initMonth != -1 // can't start any month and...
				&& myProductsData[productID]->initMonth != // ...can't start this month
				CivData::pCivData->currentMonthN))
			// then it can't be started this month
			continue;

		// Query returns extraNeededInputGoods to prepare the _ListOfGoods_to_buy list

		CGoods extraNeededInputGoods;// returned: desirable input quantities

		GoodValue productQuantity =
			Query(productID, desiredProductUnits, _Goods_I_have, extraNeededInputGoods);

		// workers_n can be in _ListOfGoods_to_buy and in temporarily in _Goods_I_have
		// (different from myProductsData[productID]->RetainedEmployees)
		for (auto gPair : extraNeededInputGoods)
		{
			auto inputID = gPair.first;
			auto extraID = gPair.second.quantity();
			if (extraID == 0)
				continue;

			// Producers with an initMonth need to carry these values onto next months
			if (getMyProducerOfProductID(inputID) != nullptr)
			{
				GoodValue sellID = _Goods_to_sell.at(inputID).quantity();
				auto tobeproduced = max((GoodValue)0, extraID - sellID);

				if (tobeproduced > 0)
				{
					_Goods_I_have[inputID] += sellID;
					_Goods_to_sell[inputID] = 0;
					_Goods_to_be_produced[inputID] =
						max(_Goods_to_be_produced(inputID), tobeproduced);
				}
				else // sellID > extraID
				{
					_Goods_I_have[inputID] += extraID;
					_Goods_to_sell[inputID] -= extraID;
				}
			}
			else
				_ListOfGoods_to_buy[inputID] =
				max(_ListOfGoods_to_buy(inputID), extraNeededInputGoods(inputID));
		}
	}
}

// Production  ---------------------------------------------------------------

void CProducer::RunProducer()
{
	if ((_Goods_I_have(workers_n) == 0)
		&& !HasActiveProducer())
	{
		//0616_Goods_to_be_produced -= _Goods_to_be_produced;
		return;
	}

	vector<GoodID> productIDs;
	for (auto productdataPair : myProductsData)
		productIDs.push_back(productdataPair.first);

	shuffle(productIDs.begin(), productIDs.end(),
		CivData::pCivData->myRandomEngine);

	GoodValue toBePayedThisMonth = 0;
	for (auto productID : productIDs)
	{
		auto productData = myProductsData[productID];

		CGoods extraNeededInputGoods;// returned: desirable input quantities
		CGoods gDeltaRet;// returned, +-increments of each (in/out) good type
		GoodValue desiredProductUnits = 0;

		// Run Producer

		GoodValue toBePayedForThisProduct = 0;
		if (!productData->active)// first or only month (delayMonths==0)
		{   // decreases available workers
			if (_Goods_I_have(workers_n) == 0)
				continue;// may get delayed product from other productID

			GoodValue desiredProductUnits = _Goods_to_be_produced(productID);

			if (!(productData->initMonth == -1
				|| productData->initMonth == CivData::pCivData->currentMonthN)
				|| desiredProductUnits == 0)
				continue; // can't start this month or product qtty = 0

			toBePayedForThisProduct =
				Produce(productID, desiredProductUnits,
					_Goods_I_have, extraNeededInputGoods, gDeltaRet);
		}
		else // active: intermediate or last month, returns toBePayedThisMonth
			 // last-month: gDeltaRet also returns product and releases retained workers
		{
			toBePayedForThisProduct =
				Produce(productID, desiredProductUnits,
					_Goods_I_have, extraNeededInputGoods, gDeltaRet);
		}

		toBePayedThisMonth += toBePayedForThisProduct;

		if (gDeltaRet[productID] > 0 && CivData::pCivData->bSingleRobot)
		{
			(*CivData::pCivData->pOutf) << "Step " << _pGeneration->CurrentTimestep
				<< ": Executed "
				<< CivData::pCivData->GoodID2Name[productID] << endl;

			(*CivData::pCivData->pOutf).flush();
		}
		// Apply changes

		if (productData->active)
		{
			for (auto gPair : extraNeededInputGoods)
			{
				if (gPair.second.quantity() == 0)
					continue;

				auto inputID = gPair.first;
				// Producers with an initMonth need to carry these values onto next months
				_ListOfGoods_to_buy[inputID] = max(_ListOfGoods_to_buy(inputID),
					extraNeededInputGoods(inputID));
			}
		}
		else // not active: finished or couldn't start
		{
			if (gDeltaRet[productID] > 0) // finished
			{
				// wait to next product demand to build the _ListOfGoods_to_buy

				/*for (auto gPair : extraNeededInputGoods)
				{
					if (gPair.second.quantity() == 0)
						continue;

					auto inputID = gPair.first;
					if (inputID == workers_n)
					{ // don't hire workers until next timestep
						_ListOfGoods_to_buy[workers_n] = 0;
						continue;
					}

					// Producers with an initMonth need to carry these values onto next months
					_ListOfGoods_to_buy[inputID] = max(_ListOfGoods_to_buy(inputID),
						extraNeededInputGoods(inputID));
				}*/
			}
			else // couldn't start
			{
				for (auto gPair : extraNeededInputGoods)
				{
					if (gPair.second.quantity() == 0)
						continue;

					auto inputID = gPair.first;
					if (inputID == workers_n)
					{
						// Don't hire workers until needed 
						// other producers may need them even in this timestep
						_ListOfGoods_to_buy[workers_n] = 0;
						continue;
					}
				}
			}
		}

		// Apply gDeltaRet increments of output and input goods 

		for (auto gPair : gDeltaRet)
		{
			auto gID = gPair.first;
			if (gPair.second.quantity() == 0)
				continue;

			if (gID == productID)
			{
				// Warning: case gDeltaRet[productID]<0: for example, builder can take
				// some building_2 as immobilized
				if (gDeltaRet(gID) > 0)
				{
					_Goods_to_sell[gID] += gDeltaRet(gID);

					_Goods_to_be_produced[gID] =
						max<GoodValue>(0, _Goods_to_be_produced(gID) - gDeltaRet(gID));
				}
				else // gDeltaRet[productID]<0
					_Goods_I_have[gID] += gDeltaRet(gID);
			}
			else if (gID == workers_n)
			{
				// Bookkeeping of workers retained (gDeltaRet<0) and returned(>0)
				// vEmployees.size: GoodsIhaveWorkers + _TotalRetainedWorkers
				_Goods_I_have[workers_n] += gDeltaRet[workers_n];
				_TotalRetainedWorkers += -gDeltaRet(workers_n);
				continue;
			}
			else
				_Goods_I_have[gID] += gDeltaRet(gID);
		}
	}

	assert(toBePayedThisMonth >= _TotalRetainedWorkers);
	if (toBePayedThisMonth > 0)
		_HasWorkedCurrentMonth = true; // Producer active this month

	// Lay off excess employees:

	while ((GoodValue)_vEmployees.size() > toBePayedThisMonth)
	{
		ReleaseLastEmployee();
		_Goods_I_have[workers_n] -= 1;
	}
	assert(_Goods_I_have[workers_n] >= 0);// plus retained

// Pay salaries to employees

	GoodValue salary = myCurrentPriceOf(workers_n);

	for (auto pWorker : _vEmployees)
	{
		assert(pWorker->_HasWorkedCurrentMonth == false);// Unemployment flag
		pWorker->_HasWorkedCurrentMonth = true;

		if ((*CivData::pCivData).at(CivData::kUseMoney))
		{
			string concept = "";
			if ((*CivData::pCivData)[CivData::kWriteTransactions]
				&& (_ID == (*CivData::pCivData)[CivData::kWriteIndivN]
					|| pWorker->_ID == (*CivData::pCivData)[CivData::kWriteIndivN])
				)
				concept = " pays salary= " + to_string(salary) + " in cash to ";
			bool done = PayInCash(this, pWorker, salary, concept);

			if (!done)
			{
				_MinCash += salary;
				if ((*CivData::pCivData)[CivData::kWriteTransactions]
					&& (_ID == (*CivData::pCivData)[CivData::kWriteIndivN]
						|| pWorker->_ID == (*CivData::pCivData)[CivData::kWriteIndivN])
					)
					concept = " transfers salary= " + to_string(salary) + " to ";
				done = _pUsedBank->PayThroughBankTransfer(this, pWorker, salary, concept);
				if (!done)
				{
					//assert(false);// my Bank has not enough resources
					break;
				}
			}
		}
	}
}

GoodValue CProducer::Query(const GoodID productID, GoodValue& desiredProductUnits,
	const CGoods& availableInputGoods, CGoods& extraNeededInputGoods) const
{
	// If production of productID is already underway or it can't be started
	// this month return productUnits = 0.
	// Otherwise return an estimate of the product quantity that can be produced with the
	// availableInputGoods as well as the extraNeededInputGoods to get the desiredProductUnits

	extraNeededInputGoods.clear();
	const map<GoodID, double>& nonConsumedPerUnit =
		myProductsData.at(productID)->nonConsumedPerUnit;
	const map<GoodID, double>& consumedPerUnit =
		myProductsData.at(productID)->consumedPerUnit;
	int currentMonth = CivData::pCivData->currentMonthN;

	int currentTimestep = CivData::pCivData->currentTimestep;

	if (currentTimestep < myProductsData.at(productID)->availableAtStep)
		return 0;

	GoodValue productQuantity = 0;

	if (myProductsData.at(productID)->active
		|| !(myProductsData.at(productID)->initMonth == -1
			|| myProductsData.at(productID)->initMonth == currentMonth))
		return (productQuantity = 0); // already active or can't start this month

	// Can start this month: first calculate the workersNeeded

	map<GoodID, double> maxProductFromGoodID;

	GoodValue workersNeeded = 0;
	GoodValue availableWorkers = 0;
	if (myProductsData.at(productID)->totalWorkPerUnit > 0)
	{
		assert(nonConsumedPerUnit.find(workers_n) == nonConsumedPerUnit.end());

		workersNeeded = desiredProductUnits *
			myProductsData.at(productID)->totalWorkPerUnit;

		if (availableInputGoods.find(workers_n) != availableInputGoods.end())
			availableWorkers = availableInputGoods.at(workers_n).quantity();

		if (availableWorkers == 0)
			maxProductFromGoodID[workers_n] = 0;
		else // production can start, although may need more months work
			maxProductFromGoodID[workers_n] = desiredProductUnits;

		if (availableWorkers < workersNeeded)
			extraNeededInputGoods[workers_n] = workersNeeded - availableWorkers;
	}
	else
	{
		workersNeeded = ceil(desiredProductUnits * nonConsumedPerUnit.at(workers_n));

		// Optimize the used workers by increasing the production quantity if necessary.
		// At the end, production may be denied to avoid too expensive production.

		desiredProductUnits = floor(workersNeeded / nonConsumedPerUnit.at(workers_n));
	}

	// 1. Find maxProductFromGoodID for the nonConsumed Goods available.
	// (Immobilized IDs, and possibly workers, come in as nonConsumed InputGoods)

	for (auto inPair : nonConsumedPerUnit)
	{
		GoodID inputID = inPair.first;

		assert(inputID != workers_n || myProductsData.at(productID)->totalWorkPerUnit == 0);

		GoodValue neededOfID = 0;
		if (inputID == workers_n)
			neededOfID = workersNeeded;
		else
			neededOfID = ceil(desiredProductUnits * nonConsumedPerUnit.at(inputID));

		GoodValue availableOfID = 0;
		if (availableInputGoods.find(inputID) != availableInputGoods.end())
			availableOfID = availableInputGoods.at(inputID).quantity();

		GoodValue immobOfID = -1;// no immobilizedMinimums (constraints) for this ID
		if (immobilizedMinimums.find(inputID) != immobilizedMinimums.end())
			// add the goods already immobilized
			immobOfID = _ImmobilizedGoods.at(inputID)._quantity; // immobOfID >= 0: immobilizedMinimums
		if (immobOfID > 0)
			availableOfID += immobOfID;

		// Now make an estimate of maxProductFromGoodID that could be produced, based on:
		// neededOfID, availableOfID, immobOfID

		maxProductFromGoodID[inputID] = desiredProductUnits;
		if (availableOfID >= neededOfID)
		{
			maxProductFromGoodID[inputID] = desiredProductUnits;
		}
		else // availableOfID < neededOfID
		{
			extraNeededInputGoods[inputID] = neededOfID - availableOfID;

			if (immobOfID < 0) // no immob constraints for this ID, example: workers
			{
				maxProductFromGoodID[inputID] = min(maxProductFromGoodID[inputID],
					floor(availableOfID / nonConsumedPerUnit.at(inputID)));
			}
			else // immobOfID>=0, there are immobNeeds and Goods
			{
				// There are two types of behaviors for immobilizedMinimums(ID) = MinOfID:

				if (immobilizedMinimums.at(inputID) == 0)// example land for product wheat
				// MinOfID=0: maxProduct is proportional to availableOfID ( < neededOfID). 
				// but, unlike for immobOfID < 0, this good will be kept as _ImmobilizedGoods
				{
					maxProductFromGoodID[inputID] = min(maxProductFromGoodID[inputID],
						floor(availableOfID / nonConsumedPerUnit.at(inputID)));
				}
				else
					// MinOfID > 0, example carpentry: no building necessary
					// for small production of product doors:
					// if(neededOfID < MinOfID) maxProduct=desiredProductUnits;
					// else maxProduct=0;
					// The quantities used are retained as _ImmobilizedGoods
				{
					GoodValue qttyID = max(immobilizedMinimums.at(inputID), availableOfID);
					maxProductFromGoodID[inputID] = min(maxProductFromGoodID[inputID],
						floor(qttyID / nonConsumedPerUnit.at(inputID)));
				}
			}
		}
		assert(extraNeededInputGoods[inputID] >= 0);
	}

	// 2. Find maxProductFromGoodID for Consumed InputGoods

	for (auto inPair : consumedPerUnit)
	{
		GoodID inputID = inPair.first;
		assert(inputID != productID); // no seeds

		GoodValue availableOfID = availableInputGoods.at(inputID).quantity();

		// some goods can be in both nonconsumed and consumed sets (like machinery in 
		// a carfactory)
		if (maxProductFromGoodID.find(inputID) == maxProductFromGoodID.end())
			maxProductFromGoodID[inputID] = floor(availableOfID / consumedPerUnit.at(inputID));
		else
			maxProductFromGoodID[inputID] = min(maxProductFromGoodID[inputID],
				floor(availableOfID / consumedPerUnit.at(inputID)));

		if (maxProductFromGoodID[inputID] < desiredProductUnits)
			extraNeededInputGoods[inputID] =
			ceil(desiredProductUnits * consumedPerUnit.at(inputID)) - availableOfID;
	}

	// 3. Find the final productUnits that can be produced with these availableInputGoods

	productQuantity = desiredProductUnits;
	for (auto inTy : maxProductFromGoodID)
		if (maxProductFromGoodID[inTy.first] < productQuantity)
			productQuantity = maxProductFromGoodID[inTy.first];

	GoodValue minQtty = MinimumProductUnits(productID);
	if (productQuantity >= minQtty / 10.0) // avoid too expensive production
		return productQuantity;
	else
		return 0;
}

GoodValue CProducer::Produce(const GoodID productID, GoodValue desiredProductUnits,
	const CGoods& availableInputGoods, CGoods& extraNeededInputGoods,
	CGoods& gDeltaRet)
{
	// extraNeededInputGoods: return desirable extra input Quantities
	gDeltaRet.clear(); // +-increments of each (in/out) good type

	auto& productData = myProductsData[productID];
	const map<GoodID, double>& nonConsumedPerUnit =
		productData->nonConsumedPerUnit;
	const map<GoodID, double>& ConsumedPerUnit =
		productData->consumedPerUnit;

	int currentTimestep = CivData::pCivData->currentTimestep;

	if (currentTimestep < productData->availableAtStep)
		return 0;

	int currentMonth = CivData::pCivData->currentMonthN;

	GoodValue workersPayedThisMonth = 0;

	if (!productData->active)
	{
		// Begin production after preliminary query

		GoodValue productUnits = Query(productID, desiredProductUnits,
			availableInputGoods, extraNeededInputGoods);

		if (productUnits <= 0)
			return 0;

		// Don't change productUnits!
		// We only know that productUnits can be produced. Carry out the changes
		// in the input and output variables

		_LastUsedTimestep = currentTimestep;

		GoodValue availableOfID = 0;
		GoodValue usedOfID = 0;

		// Workers first:-----------------------------------------
		availableOfID = availableInputGoods.at(workers_n).quantity();

		GoodValue neededOfID = 0;
		if (myProductsData.at(productID)->totalWorkPerUnit > 0)
			neededOfID = productUnits * myProductsData.at(productID)->totalWorkPerUnit;
		else
		{
			assert(nonConsumedPerUnit.at(workers_n) > 0);
			neededOfID = ceil(productUnits * nonConsumedPerUnit.at(workers_n));
		}

		usedOfID = min(availableOfID, neededOfID);

		//-------------------------------------------------------

		workersPayedThisMonth = usedOfID;

		for (auto inPair : nonConsumedPerUnit)
		{
			GoodID inputID = inPair.first;

			if (nonConsumedPerUnit.at(inputID) == 0)
				continue;

			usedOfID = ceil(productUnits * nonConsumedPerUnit.at(inputID));

			if (availableInputGoods.find(inputID) == availableInputGoods.end())
				availableOfID = 0;
			else
				availableOfID = availableInputGoods.at(inputID).quantity();

			//     ----- _ImmobilizedGoods  ---------------

			if (immobilizedMinimums.find(inputID) != immobilizedMinimums.end())
			{
				availableOfID += _ImmobilizedGoods(inputID);

				GoodValue minimumOfID = immobilizedMinimums.at(inputID);

				// There are two types of behaviors depending on minimumOfID (>=0):

				// Producer type 1:
				if (minimumOfID == 0) // like land for product wheat
				{
					// productUnits is proportional to usedOfID, as already calculated
					assert(usedOfID <= availableOfID);
				}
				else // minimumOfID > 0 (Example: machinery, building...):
				// Producer type 2:
				// This allows a builder begin to build without having a building intially.
				// The extra quantities used are retained, added to _ImmobilizedGoods.

				{
					assert(usedOfID <= minimumOfID// like a small building to start a carpentry
						|| usedOfID <= availableOfID);// above minimumOfID is proportional
				}

				if (usedOfID > _ImmobilizedGoods(inputID)) // Producer's size grow
				{
					GoodValue extra = usedOfID - _ImmobilizedGoods(inputID);
					_ImmobilizedGoods[inputID] += extra;
					gDeltaRet[inputID] = -extra;// take it from input
				}
			}
		}

		double productionCost = 0;
		for (auto inPair : ConsumedPerUnit)
		{
			GoodID inputID = inPair.first;
			if (ConsumedPerUnit.at(inputID) == 0)
				continue;

			availableOfID = 0;
			if (availableInputGoods.find(inputID) != availableInputGoods.end())
				availableOfID += availableInputGoods.at(inputID).quantity();

			// Assign gDeltaRet delta values:

			usedOfID = ceil(productUnits * ConsumedPerUnit.at(inputID));
			assert(usedOfID <= availableOfID);

			gDeltaRet[inputID] = -usedOfID;

			double consumedCostFraction = 1.0;
			if (productData->consumedCostFraction.find(inputID)
				!= productData->consumedCostFraction.end())
				consumedCostFraction = productData->consumedCostFraction[inputID];

			// use pre-adapted prices
			productionCost += usedOfID * myCurrentPriceOf(inputID) * _myPriceAdapt
				* consumedCostFraction;
		}

		// --------  Update production price  -------------------------------

		double productionPrice = 0;
		double finalProductPrice = 0;
		double profit =
			CivData::pCivData->at(CivData::kPriceProfitPer100) / 100.0;

		if ((*CivData::pCivData).at(CivData::kUseMoney))
		{
			// use pre-adapted prices
			if (myProductsData.at(productID)->totalWorkPerUnit > 0)
				productionCost += myProductsData.at(productID)->totalWorkPerUnit
				* productUnits * (myCurrentPriceOf(workers_n) * _myPriceAdapt);
			else
				productionCost += workersPayedThisMonth
				* (myCurrentPriceOf(workers_n) * _myPriceAdapt)
				* (1 + productData->delayMonths);
		}
		// GDP data  -----------------------

		CGenerationData* pGenDat = CivData::pCivData->pCurrentGenerationData;
		pGenDat->pAccumGDP->at(currentTimestep) += productionCost;

		productionPrice = productionCost / productUnits;
		finalProductPrice = productionPrice * profit;

		if ((*CivData::pCivData).at(CivData::kFixedPrices))
		{
			double marketPrice = (*CivData::pCivData).pCurrentGenerationData->
				MarketPrices[productID][0];
			if (marketPrice == 0)
				(*CivData::pCivData).pCurrentGenerationData->
				MarketPrices[productID][0] = finalProductPrice;
			else
				finalProductPrice = marketPrice;
		}

		productData->ProductionPrice = finalProductPrice;
		setMyPriceOf(productID, finalProductPrice);
		// ----------------------------------------------------------------

		// Finally, release the product and return

		if (productData->delayMonths == 0
			&& myProductsData.at(productID)->totalWorkPerUnit == 0)
		{
			// single month Producer

			gDeltaRet[productID] = productUnits;
		}
		else if (myProductsData.at(productID)->totalWorkPerUnit == 0)
		{
			// this first month is like a sowing month or start of building

			productData->productDeliveryTimestep =
				currentTimestep + productData->delayMonths;

			productData->delayedProductQuantity = productUnits;

			productData->RetainedEmployees = workersPayedThisMonth;
			gDeltaRet[workers_n] = -productData->RetainedEmployees;
			// working until productDeliveryTimestep and returned then.

			productData->active = true;
		}
		else // this product results from total accumulated work
		{
			GoodValue totalWorkNeeded = productUnits
				* myProductsData.at(productID)->totalWorkPerUnit;

			if (workersPayedThisMonth == totalWorkNeeded)
			{
				// all work done in this first month, release product

				gDeltaRet[productID] = productUnits;
				gDeltaRet[workers_n] = 0;// no workers retained
				productData->active = false;
			}
			else // this is only the first month, more are needed
			{
				productData->AccumulatedWork
					= workersPayedThisMonth;

				productData->delayedProductQuantity
					= productUnits;

				// retain workers until productDeliveryTimestep
				productData->RetainedEmployees =
					workersPayedThisMonth;
				gDeltaRet[workers_n] =
					-productData->RetainedEmployees;

				productData->active = true;
			}
		}
	}
	else // already active from previous month
	{
		if (myProductsData.at(productID)->totalWorkPerUnit > 0)
		{
			GoodValue totalWorkNeeded =
				myProductsData.at(productID)->totalWorkPerUnit
				* productData->delayedProductQuantity;

			GoodValue additionalWorkers = availableInputGoods.at(workers_n).quantity();

			if (productData->AccumulatedWork +
				(productData->RetainedEmployees + additionalWorkers)
				>= totalWorkNeeded)
			{
				// Work finished

				workersPayedThisMonth = totalWorkNeeded - productData->AccumulatedWork;
				productData->AccumulatedWork = 0;

				// release retained workers and product

				gDeltaRet[workers_n] = productData->RetainedEmployees;
				productData->RetainedEmployees = 0;

				gDeltaRet[productID] = productData->delayedProductQuantity;
				productData->delayedProductQuantity = 0;

				productData->active = false;
			}
			else // take all new Workers and release produced units if any
			{
				productData->RetainedEmployees += additionalWorkers;
				gDeltaRet[workers_n] = -additionalWorkers;

				workersPayedThisMonth = productData->RetainedEmployees;

				productData->AccumulatedWork += workersPayedThisMonth;

				GoodValue unitsProduced =
					floor(productData->AccumulatedWork
						/ myProductsData.at(productID)->totalWorkPerUnit);

				if (unitsProduced > 0)
				{
					// release units already produced and stop or continue production

					gDeltaRet[productID] = unitsProduced;
					productData->delayedProductQuantity -= unitsProduced;

					// remaining accumulated work: discard or keep to continue production
					productData->AccumulatedWork -= ceil(unitsProduced *
						myProductsData.at(productID)->totalWorkPerUnit);
					if (productData->AccumulatedWork < 0)
						productData->AccumulatedWork = 0;

					// stop production if there is already stock to sell
					if (_Goods_to_sell(productID) > 0)
					{
						productData->delayedProductQuantity = 0;
						productData->AccumulatedWork = 0;

						// return all retained employees
						gDeltaRet[workers_n] =
							productData->RetainedEmployees;
						productData->RetainedEmployees = 0;

						productData->active = false;
					}
					else
					{ // continue production with the AccumulatedWork and RetainedEmployees
						extraNeededInputGoods[workers_n] =
							max<GoodValue>(0,
								ceil(productData->delayedProductQuantity
									* myProductsData.at(productID)->totalWorkPerUnit)
								- productData->AccumulatedWork);
					}
				}
			}
		}
		else
		{
			workersPayedThisMonth = productData->RetainedEmployees;

			if (currentTimestep
				>= productData->productDeliveryTimestep) // harvestMonth
			{
				gDeltaRet[productID] = productData->delayedProductQuantity;
				productData->delayedProductQuantity = 0;

				gDeltaRet[workers_n] = productData->RetainedEmployees;
				productData->RetainedEmployees = 0;

				productData->productDeliveryTimestep = 1e9;
				productData->active = false;
			}
		}
	}

	return workersPayedThisMonth;
}

GoodValue CProducer::MinimumProductUnits(const GoodID productID) const
{
	GoodValue minQtty = 1;
	for (auto inPair : myProductsData.at(productID)->nonConsumedPerUnit)
	{
		GoodID inputID = inPair.first;
		minQtty = max<GoodValue>(minQtty, 1.0 / inPair.second);
	}
	return minQtty;
}


// Market  ---------------------------------------------------------------

void CProducer::SellMyProductsToInteractingNeighbors()
{
	for (auto& goodPair : _Goods_to_sell)
	{
		CGood& good = goodPair.second;
		if (good._ID == workers_n || good.quantity() <= 0)
			continue;
		for (auto nNei : _InteractingTraders)
		{
			auto& neighbor = *nNei.second;// _Manager->_pGeneration->at(nNei);

			TradeGoodWithNeighbor(neighbor, good, MarketOperation::sell);
			assert(_pGeneration->CheckGenerationBalance());
		}
	}
}

// Employees  ---------------------------------------------------------------

bool CProducer::TryToHireNeighbor(CTrader& neighbor)
{
	// Hiring should only be initiated by Manager

	if (!neighbor.canBeEmployed())
		return 0;

	if ((*CivData::pCivData).at(CivData::kUseMoney))
	{
		CGood good(workers_n, 1);

		auto priceAgreed = AgreePriceWithNeighbor(this, &neighbor,
			good, MarketOperation::buy);

		if (priceAgreed <= 0)
			return false;

		// report info
		_pGeneration->thisTimestepTradedPrices[workers_n] += priceAgreed;
		_pGeneration->thisTimestepNtrades[workers_n]++;

		if (!(*CivData::pCivData).at(CivData::kFixedPrices))
		{
			// Both individuals learn from this SUCCESSFUL Market interaction

			neighbor.setMyPriceOf(workers_n,
				min((double)CivData::pCivData->minSalary * CivData::pCivData->maxPriceFactor,
					neighbor._myPrice[workers_n] * neighbor._myPriceAdapt));

			setMyPriceOf(workers_n,
				max((double)CivData::pCivData->minSalary, _myPrice[workers_n] / _myPriceAdapt));
		}
	}

	neighbor._Manager = this;

	_vEmployees.push_back(&neighbor);

	--_ListOfGoods_to_buy[workers_n]._quantity;
	assert(_Goods_I_have[workers_n] >= 0);// plus retained
	_Goods_I_have[workers_n] += 1;

	return true;
}

CTrader* CProducer::ReleaseLastEmployee()
{
	CTrader* employee = _vEmployees.back();

	assert(employee->_Manager == this);
	employee->_Manager = nullptr;

	_vEmployees.pop_back();
	return employee;
}

bool CProducer::ReleaseThisEmployee(CTrader& employee)
{
	assert(employee._Manager == this);
	employee._Manager = nullptr;

	for (int nEmployee = 0; nEmployee < _vEmployees.size(); ++nEmployee)
		if (_vEmployees[nEmployee]->_ID == employee._ID)
		{
			_vEmployees[nEmployee] = _vEmployees.back();
			_vEmployees.pop_back();
			break;
		}
	return true;
}
