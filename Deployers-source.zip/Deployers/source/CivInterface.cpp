
// CivInterface.cpp

// "Deployers: 
//  The Spontaneous Rise and Deployment of Economic Systems"
/*
Ludwig von Mises: "For the purpose of [human] science we must start
from the action of the individual because this is the only thing of
which we can have direct cognition. The idea of a society that could
operate or manifest itself apart from the action of individuals is
absurd. Everything social must in some way be recognizable in the
action of the individual.... Every form of society is operative in
the actions of individuals aiming at definite ends...."
*/

#include "pch.h"
#include "CivInterface.h"
#include "GlgMain.h"
#include <math.h>

#ifndef no_init_all
#define no_init_all
#endif

int fontSize = 2;
double nIndivsToPlot = 50;
double MaxYears = 1;
double nIndividuals = 1;

double XYscale = 1.0;

CCivilization* pCivilization = 0;
GlgAppContext AppContext;

void showCurrentYearNumber()
{
	double curr = (double)CivData::pCivData->currentYearN;
	CivData::pCivData->pInterface->SetResource("SpinnerYears/Value",
		curr + 1);

	CivData::pCivData->pInterface->Update();
}

// Main Entry point

int GlgMain(int argc, char* argv[], GlgAppContext InitAppContext)
{
	GlgSessionC glg_session(False, InitAppContext, argc, argv);
	AppContext = glg_session.GetAppContext();

	CivData::pCivData = new CivData();

	CivInterface Civ_Interface;
	CCivilization myCivilization(&Civ_Interface);
	Civ_Interface.pCivilization = &myCivilization;
	pCivilization = &myCivilization;

	Civ_Interface.LoadWidget("DeployersInterface.g");

	// (Xleft,Ytop, width,height)
	Civ_Interface.SetSize(10, 10, 1300 * XYscale, 950 * XYscale);

	Civ_Interface.SetResource("ScreenName", "Deployers");

	// Enable callbacks before hierarchy definition
	Civ_Interface.EnableCallback(GLG_INPUT_CB);
	Civ_Interface.EnableCallback(GLG_TRACE_CB);

	// Set initial parameters.
	Civ_Interface.InitializeDrawing();
	Civ_Interface.LoadParametersButton();

	// Start periodic dynamic updates.
	// Civ_Interface.StartUpdates();
	return (int)GlgMainLoop(AppContext);

	delete CivData::pCivData;
}

void CivInterface::LoadParametersButton()
{
	OutputDataValid = false;
	CivData::pCivData->LoadParameters();

	nIndividuals = (*CivData::pCivData)[CivData::kIndividuals];
	int nTimesteps = (CivData::pCivData->at(CivData::kYears))
		* CivData::pCivData->stepsPerYear;

	SetResource("MaxIndividualsBox/Value", nIndividuals);
	SetResource("SpinnerIndividuals/Value", nIndividuals);

	MaxYears = (*CivData::pCivData)[CivData::kYears];
	SetResource("MaxYearsBox/Value", MaxYears);
	SetResource("SpinnerYears/Value", MaxYears);

	SetResource("GPlotEveryNstepsBox/Value",
		CivData::pCivData->at(CivData::kPlotEveryNsteps));

	SetResource("MaxNplotCurvesBox/Value",
		CivData::pCivData->at(CivData::kMaxNplotCurves));

	_lineWidth = CivData::pCivData->at(CivData::kLineWidth);
	SetResource("SpinnerLineWidth/Value", _lineWidth);

	Update();

	ReadInputInterface();
}

void CivInterface::ReadInputInterface()
{
	double ni, ny, value;

	GetResource("MaxIndividualsBox/Value", &nIndividuals);
	(*CivData::pCivData)[CivData::kIndividuals] = nIndividuals;
	ni = nIndividuals;
	SetResource("SpinnerIndividuals/MaxValue", nIndividuals);
	SetResource("SpinnerIndividuals/Value", nIndividuals);

	GetResource("MaxYearsBox/Value", &MaxYears);
	(*CivData::pCivData)[CivData::kYears] = MaxYears;
	ny = MaxYears;
	SetResource("SpinnerYears/MaxValue", MaxYears);
	SetResource("SpinnerYears/Value", 0.);

	GetResource("GPlotEveryNstepsBox/Value", &value);
	CivData::pCivData->at(CivData::kPlotEveryNsteps) = (int)value;
	GetResource("MaxNplotCurvesBox/Value", &value);
	CivData::pCivData->at(CivData::kMaxNplotCurves) = value;
	GetResource("SpinnerLineWidth/Value", &value);
	_lineWidth = value;

	double nTimesteps = ny * CivData::pCivData->stepsPerYear;

	OutputDataValid = false;

	SetResource("$IndividualsTotalGraph/DataGroupOne/Factor", 0.0);// N curves, reset curves
	SetResource("$ProducersTotalGraph/DataGroupOne/Factor", 0.0);// N curves, reset curves
	SetResource("$BankValuesGraph/DataGroupOne/Factor", 0.0);// N curves, reset curves
	SetResource("$CentralBankValuesGraph/DataGroupOne/Factor", 0.0);// N curves, reset curves
	SetResource("$CashGraph/DataGroupOne/Factor", 0.0);// N curves, reset curves
	SetResource("$TheStateValuesGraph/DataGroupOne/Factor", 0.0);// N curves, reset curves
	SetResource("$TheStateGoodsGraph/DataGroupOne/Factor", 0.0);// N curves, reset curves

	SetResource("$BanksFinalValuesGraph/DataGroup/Factor", 0.0);// N curves, reset curves
	SetResource("$IndivPlusProdPlusBankGraph/DataGroupOne/Factor", 0.0);// N curves, reset curves
	SetResource("$IndividualGoodsGraph/DataGroupOne/Factor", 0.0); // N curves, reset curves
	SetResource("$IndividualValuesGraph/DataGroupOne/Factor", 0.0); // N curves, reset curves
	SetResource("$ProducerValuesGraph/DataGroupOne/Factor", 0.0); // N curves, reset curves
	SetResource("$TotalGoodsGraph/DataGroupOne/Factor", 0.0); // N curves, reset curves
	SetResource("$AggregatesGraph/DataGroupOne/Factor", 0.0); // N curves, reset curves
	SetResource("$BankValuesGraph/DataGroupOne/Factor", 0.0); // N curves, reset curves
	SetResource("$CentralBankValuesGraph/DataGroupOne/Factor", 0.0); // N curves, reset curves
	SetResource("$MarketPricesGraph/DataGroupOne/Factor", 0.0); // N curves, reset curves

	SetResource("SpinnerSelectIndividual/MaxValue", ni - 1);
	SetResource("SpinnerSelectTotalIndividual/MaxValue", ni - 1);

	Update();
}

void CivInterface::RunButton()
{
	ReadInputInterface();

	pCivilization->runCivilization();  //<<<<<<<<<<<<<<<<<<<<<

	CivData::pCivData->currentIndividualN = 0;
	SetResource("SpinnerSelectIndividual/Value",
		CivData::pCivData->currentIndividualN);

	SetResource("SpinnerSelectTotalIndividual/Value",
		(*CivData::pCivData)[CivData::kIndividuals] - 1);

	previousSelectedIndiv = -1;
	CivData::pCivData->pCurrentGenerationData->selectedBankN = -1;

	Update();

	OutputDataValid = true;

	plotIndivPlusProdPlusBankFinalValues();
	plotBanksFinalTotalValues();
	plotProducersTotalValues();
	plotIndividualsTotalValues();

	plotAggregates();
	plotMarketPrices();
	plotTotalHomeGoods();

	plotCentralBankValues();
	plotTotalCash();
	plotTheStateValues();
	plotTheStateGoods();

	plotCurrentIndividual();
}

void CivInterface::InitializeDrawing()
{
	double nGenerations = max(1, (*CivData::pCivData)[CivData::kGenerations]);
	(*CivData::pCivData)[CivData::kGenerations] = nGenerations;
	double nIndividuals = max(1, (*CivData::pCivData)[CivData::kIndividuals]);
	(*CivData::pCivData)[CivData::kIndividuals] = nIndividuals;
	nIndividuals = nIndividuals;
	double nYears = (*CivData::pCivData)[CivData::kYears];
	MaxYears = nYears;
	double nTimesteps = nYears * CivData::pCivData->stepsPerYear;
	double nMaxNplotCurves = max(0, (*CivData::pCivData)[CivData::kMaxNplotCurves]);
	(*CivData::pCivData)[CivData::kMaxNplotCurves] = nMaxNplotCurves;
	SetResource("MaxIndividualsBox/MaxValue", 1000000);
	SetResource("MaxYearsBox/MaxValue", 500);
	SetResource("SpinnerYears/MaxValue", MaxYears);
	SetResource("SpinnerIndividuals/MaxValue", nIndividuals);
	SetResource("SpinnerSelectIndividual/Value", 0.);
	SetResource("SpinnerSelectTotalIndividual/Value", 0.);
	SetResource("SpinnerLineWidth/Value", _lineWidth);
	SetResource("MaxNplotCurvesBox/Value",
		CivData::pCivData->at(CivData::kMaxNplotCurves));

	SetResource("$IndividualGoodsGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);
	SetResource("$ProducerValuesGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);
	SetResource("$TotalGoodsGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);
	SetResource("$AggregatesGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);
	SetResource("$BankValuesGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);
	SetResource("$CentralBankValuesGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);
	SetResource("$MarketPricesGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);

	SetResource("BanksFinalValuesSymbolsButton/OnState", 0.);

	string title = "Final (Manager + Producers + Bank) Value";
	SetResource("$IndivPlusProdPlusBankGraph/Title/String", title.c_str());

	title = "Individuals Max Total Value";
	SetResource("$IndividualsTotalGraph/Title/String", title.c_str());

	title = "Producers Max Total Value";
	SetResource("$ProducersTotalGraph/Title/String", title.c_str());

	Update();

	InitialDraw();// Display GLG window.
}

void CivInterface::Trace(GlgObjectC& callback_viewport,
	GlgTraceCBStruct* trace_data)
{
	if (!OutputDataValid)
		return;

	typedef enum
	{
		BUTTON_PRESS = 0,
		RESIZE,
		MOUSE_MOVE
	} EventID;

	int
		event_type = 0;
	GlgPoint mouse;

	double width, height;
	GlgObjectC event_vp;
	event_vp = trace_data->viewport;

	// Process events that occur in GenerationsViewport 
	int nGenerations = (int)CivData::pCivData->at(CivData::kGenerations);
	int nYears = (int)CivData::pCivData->at(CivData::kYears);
	int nIndividuals = (int)CivData::pCivData->at(CivData::kIndividuals);

	double XvalMouse, YvalMouse, dist2, dist2prev = 1e99;
	int generNear = -1, yearNearr = -1, indivNearr = -1;
	GlgObjectC IndividualsTotalVP = GetResourceObject("$IndividualsTotalGraph");
	GlgObjectC ProducersTotalVP = GetResourceObject("$ProducersTotalGraph");
	GlgObjectC BanksFinalValuesVP = GetResourceObject("$BanksFinalValuesGraph");
	GlgObjectC IndivPlusProdPlusBankVP = GetResourceObject("$IndivPlusProdPlusBankGraph");

	CGenerationData* pGenDat = CivData::pCivData->pCivilizationData->at(
		CivData::pCivData->currentGenerationN);

	if (event_vp.Same(IndivPlusProdPlusBankVP))
	{
		// Platform-specific code to extract event information.
		switch (trace_data->event->message)
		{
		case WM_LBUTTONDOWN:
		case WM_MOUSEMOVE:
			mouse.x = GET_X_LPARAM(trace_data->event->lParam);
			mouse.y = GET_Y_LPARAM(trace_data->event->lParam);
			mouse.z = 0;

			switch (trace_data->event->message)
			{
			case WM_LBUTTONDOWN:
				event_type = BUTTON_PRESS;
				break;
			case WM_MOUSEMOVE:
				event_type = MOUSE_MOVE;
				break;
			}
			break;

		case WM_SIZE:
			width = LOWORD(trace_data->event->lParam) + GLG_COORD_MAPPING_ADJ;
			height = HIWORD(trace_data->event->lParam) + GLG_COORD_MAPPING_ADJ;
			event_type = RESIZE;
			break;

		default: return;
		}

		string strX, strY;
		double offtop, offbott, offleft, offright;
		double innerHeight, innerWidth;
		int indivNear = 0;
		switch (event_type)
		{
		case BUTTON_PRESS:
			GetResource("$IndivPlusProdPlusBankGraph/DataArea/OffsetTop", &offtop);
			GetResource("$IndivPlusProdPlusBankGraph/DataArea/OffsetBottom", &offbott);
			GetResource("$IndivPlusProdPlusBankGraph/DataArea/OffsetLeft", &offleft);
			GetResource("$IndivPlusProdPlusBankGraph/DataArea/OffsetRight", &offright);

			GetResource("$IndivPlusProdPlusBankGraph/InnerHeight", &innerHeight);
			GetResource("$IndivPlusProdPlusBankGraph/InnerWidth", &innerWidth);

			double Xval, Yval, xx, yy;
			double xMax, yMax;
			GetResource("$IndivPlusProdPlusBankGraph/YHigh", &yMax);
			GetResource("$IndivPlusProdPlusBankGraph/XHigh", &xMax);

			XvalMouse = (mouse.x - offleft) /
				(innerWidth - offleft + offright * innerWidth / 2000);

			YvalMouse = (innerHeight - mouse.y + offbott) /
				(innerHeight + offbott + offtop * innerHeight / 2000);

			for (int generN = 0; generN < nGenerations; ++generN)
			{
				for (int idx = 0; idx <
					pGenDat->pIndivPlusProdPlusBankFinalSortedVal->size(); ++idx)
				{
					strX = "$IndivPlusProdPlusBankGraph/DataGroupOne/DataGroup"
						+ to_string(generN) + "/Points/DataSample"
						+ to_string(idx) + "/XValue";
					GetResource(strX.c_str(), &xx);
					strY = "$IndivPlusProdPlusBankGraph/DataGroupOne/DataGroup"
						+ to_string(generN) + "/Points/DataSample"
						+ to_string(idx) + "/YValue";
					GetResource(strY.c_str(), &yy);

					Xval = xx / xMax;
					Yval = yy / yMax;
					dist2 = (Xval - XvalMouse) * (Xval - XvalMouse)
						+ (Yval - YvalMouse) * (Yval - YvalMouse);
					if (dist2 < dist2prev)
					{
						generNear = generN;
						indivNear = (int)xx;
						dist2prev = dist2;
					}
				}
			}

			pGenDat = CivData::pCivData->pCivilizationData->at(generNear);
			if (CivData::pCivData->currentGenerationN == generNear
				&& CivData::pCivData->currentIndividualN ==
				(*pGenDat->pIndivPlusProdPlusBankFinalSortedVal)[indivNear].second)
				break;

			CivData::pCivData->currentGenerationN = generNear;

			CivData::pCivData->currentIndividualN =
				(*pGenDat->pIndivPlusProdPlusBankFinalSortedVal)[indivNear].second;

			CivData::pCivData->pInterface
				->SetResource("SpinnerSelectIndividual/Value",
					CivData::pCivData->currentIndividualN);
			CivData::pCivData->pInterface
				->SetResource("SpinnerSelectTotalIndividual/Value",
					CivData::pCivData->currentIndividualN);

			plotCurrentIndividual();

			break;

		case RESIZE:
			break;

		case MOUSE_MOVE:
			break;

		default: return;
		}
	}
	else if (event_vp.Same(BanksFinalValuesVP))
	{
		// Platform-specific code to extract event information.
		switch (trace_data->event->message)
		{
		case WM_LBUTTONDOWN:
		case WM_MOUSEMOVE:
			mouse.x = GET_X_LPARAM(trace_data->event->lParam);
			mouse.y = GET_Y_LPARAM(trace_data->event->lParam);
			mouse.z = 0;

			switch (trace_data->event->message)
			{
			case WM_LBUTTONDOWN:
				event_type = BUTTON_PRESS;
				break;
			case WM_MOUSEMOVE:
				event_type = MOUSE_MOVE;
				break;
			}
			break;

		case WM_SIZE:
			width = LOWORD(trace_data->event->lParam) + GLG_COORD_MAPPING_ADJ;
			height = HIWORD(trace_data->event->lParam) + GLG_COORD_MAPPING_ADJ;
			event_type = RESIZE;
			break;

		default: return;
		}

		string strX, strY;
		double offtop, offbott, offleft, offright;
		double innerHeight, innerWidth;
		int nearestBankN = 0;
		int nBanks = 0;
		switch (event_type)
		{
		case BUTTON_PRESS:
			// select Bank and its Manager
			// Commercial Banks IDs (=ownerID):  (*pGenDat).pBanksIDs
			if ((*(*pGenDat).pBanksIDs).size() == 0)
				return;

			GetResource("$BanksFinalValuesGraph/DataArea/OffsetTop", &offtop);
			GetResource("$BanksFinalValuesGraph/DataArea/OffsetBottom", &offbott);
			GetResource("$BanksFinalValuesGraph/DataArea/OffsetLeft", &offleft);
			GetResource("$BanksFinalValuesGraph/DataArea/OffsetRight", &offright);

			GetResource("$BanksFinalValuesGraph/InnerHeight", &innerHeight);
			GetResource("$BanksFinalValuesGraph/InnerWidth", &innerWidth);

			double Xval, Yval, xx, yy;
			double xMax, yMax, yMin;
			GetResource("$BanksFinalValuesGraph/YHigh", &yMax);
			GetResource("$BanksFinalValuesGraph/YLow", &yMin);
			GetResource("$BanksFinalValuesGraph/XHigh", &xMax);

			XvalMouse = (mouse.x - offleft) /
				(innerWidth - offleft + offright * innerWidth / 2000);

			YvalMouse = (innerHeight - mouse.y + offbott) /
				(innerHeight + offbott + offtop * innerHeight / 2000);

			generNear = CivData::pCivData->currentGenerationN;

			pGenDat = CivData::pCivData->pCurrentGenerationData;
			nBanks = (int)(*(*pGenDat).pBanksIDs).size();
			if (nBanks == 1)
			{
				nearestBankN = 0;
			}
			else
			{
				dist2prev = 1e99;
				for (int idx = 0; idx < nBanks; ++idx)
				{
					strX = "$BanksFinalValuesGraph/DataGroup/Points/DataSample"
						+ to_string(idx) + "/XValue";
					GetResource(strX.c_str(), &xx);
					strY = "$BanksFinalValuesGraph/DataGroup/Points/DataSample"
						+ to_string(idx) + "/YValue";
					GetResource(strY.c_str(), &yy);

					Xval = xx / xMax;
					Yval = yy / yMax;
					dist2 = (Xval - XvalMouse) * (Xval - XvalMouse)
						;// +(Yval - YvalMouse) * (Yval - YvalMouse);
					if (dist2 < dist2prev)
					{
						nearestBankN = (int)xx;
						dist2prev = dist2;
					}
				}
			}

			pGenDat->selectedBankN = nearestBankN;

			if (CivData::pCivData->currentGenerationN == generNear
				&& CivData::pCivData->currentIndividualN ==
				(*(*pGenDat).pBanksIDs)[nearestBankN]) // CentralBankID = ManagerID
				break; // selected already

			CivData::pCivData->currentGenerationN = generNear;

			CivData::pCivData->currentIndividualN =
				(*(*pGenDat).pBanksIDs)[nearestBankN]; // CentralBankID = ManagerID

			CivData::pCivData->pInterface
				->SetResource("SpinnerSelectIndividual/Value",
					CivData::pCivData->currentIndividualN);
			CivData::pCivData->pInterface
				->SetResource("SpinnerSelectTotalIndividual/Value",
					CivData::pCivData->currentIndividualN);

			plotCurrentIndividual();

			break;

		case RESIZE:
			break;

		case MOUSE_MOVE:
			break;

		default: return;
		}
	}
	else if (event_vp.Same(ProducersTotalVP))
	{
		// Platform-specific code to extract event information.
		switch (trace_data->event->message)
		{
		case WM_LBUTTONDOWN:
		case WM_MOUSEMOVE:
			mouse.x = GET_X_LPARAM(trace_data->event->lParam);
			mouse.y = GET_Y_LPARAM(trace_data->event->lParam);
			mouse.z = 0;

			switch (trace_data->event->message)
			{
			case WM_LBUTTONDOWN:
				event_type = BUTTON_PRESS;
				break;
			case WM_MOUSEMOVE:
				event_type = MOUSE_MOVE;
				break;
			}
			break;

		case WM_SIZE:
			width = LOWORD(trace_data->event->lParam) + GLG_COORD_MAPPING_ADJ;
			height = HIWORD(trace_data->event->lParam) + GLG_COORD_MAPPING_ADJ;
			event_type = RESIZE;
			break;

		default: return;
		}

		string strX, strY;
		double offtop, offbott, offleft, offright;
		double innerHeight, innerWidth;
		int indivNear = 0;
		switch (event_type)
		{
		case BUTTON_PRESS:
			// selectCurrentGenerationAndIndividual

			GetResource("$ProducersTotalGraph/DataArea/OffsetTop", &offtop);
			GetResource("$ProducersTotalGraph/DataArea/OffsetBottom", &offbott);
			GetResource("$ProducersTotalGraph/DataArea/OffsetLeft", &offleft);
			GetResource("$ProducersTotalGraph/DataArea/OffsetRight", &offright);

			GetResource("$ProducersTotalGraph/InnerHeight", &innerHeight);
			GetResource("$ProducersTotalGraph/InnerWidth", &innerWidth);

			double Xval, Yval, xx, yy;
			double xMax, yMax;
			GetResource("$ProducersTotalGraph/YHigh", &yMax);
			GetResource("$ProducersTotalGraph/XHigh", &xMax);

			XvalMouse = (mouse.x - offleft) /
				(innerWidth - offleft + offright * innerWidth / 2000);

			YvalMouse = (innerHeight - mouse.y + offbott) /
				(innerHeight + offbott + offtop * innerHeight / 2000);

			for (int generN = 0; generN < nGenerations; ++generN)
			{
				for (int idx = 0; idx < pGenDat->pProducersTotSortedVal->size(); ++idx)
				{
					strX = "$ProducersTotalGraph/DataGroupOne/DataGroup"
						+ to_string(generN) + "/Points/DataSample"
						+ to_string(idx) + "/XValue";
					GetResource(strX.c_str(), &xx);
					strY = "$ProducersTotalGraph/DataGroupOne/DataGroup"
						+ to_string(generN) + "/Points/DataSample"
						+ to_string(idx) + "/YValue";
					GetResource(strY.c_str(), &yy);

					Xval = xx / xMax;
					Yval = yy / yMax;
					dist2 = (Xval - XvalMouse) * (Xval - XvalMouse)
						+ (Yval - YvalMouse) * (Yval - YvalMouse);
					if (dist2 < dist2prev)
					{
						generNear = generN;
						indivNear = (int)xx;
						dist2prev = dist2;
					}
				}
			}

			pGenDat = CivData::pCivData->pCivilizationData->at(generNear);
			if (CivData::pCivData->currentGenerationN == generNear
				&& CivData::pCivData->currentIndividualN ==
				(*pGenDat->pProducersTotSortedVal)[indivNear].second)
				break;

			CivData::pCivData->currentGenerationN = generNear;

			CivData::pCivData->currentIndividualN =
				(*pGenDat->pProducersTotSortedVal)[indivNear].second;

			CivData::pCivData->pInterface
				->SetResource("SpinnerSelectIndividual/Value",
					CivData::pCivData->currentIndividualN);
			CivData::pCivData->pInterface
				->SetResource("SpinnerSelectTotalIndividual/Value",
					CivData::pCivData->currentIndividualN);

			plotCurrentIndividual();

			break;

		case RESIZE:
			break;

		case MOUSE_MOVE:
			break;

		default: return;
		}
	}
	else if (event_vp.Same(IndividualsTotalVP))
	{
		// Platform-specific code to extract event information.
		switch (trace_data->event->message)
		{
		case WM_LBUTTONDOWN:
		case WM_MOUSEMOVE:
			mouse.x = GET_X_LPARAM(trace_data->event->lParam);
			mouse.y = GET_Y_LPARAM(trace_data->event->lParam);
			mouse.z = 0;

			switch (trace_data->event->message)
			{
			case WM_LBUTTONDOWN:
				event_type = BUTTON_PRESS;
				break;
			case WM_MOUSEMOVE:
				event_type = MOUSE_MOVE;
				break;
			}
			break;

		case WM_SIZE:
			width = LOWORD(trace_data->event->lParam) + GLG_COORD_MAPPING_ADJ;
			height = HIWORD(trace_data->event->lParam) + GLG_COORD_MAPPING_ADJ;
			event_type = RESIZE;
			break;

		default: return;
		}

		string strX, strY;
		double offtop, offbott, offleft, offright;
		double innerHeight, innerWidth;
		int indivNear = 0;
		switch (event_type)
		{
		case BUTTON_PRESS:
			// selectCurrentGenerationAndIndividual

			GetResource("$IndividualsTotalGraph/DataArea/OffsetTop", &offtop);
			GetResource("$IndividualsTotalGraph/DataArea/OffsetBottom", &offbott);
			GetResource("$IndividualsTotalGraph/DataArea/OffsetLeft", &offleft);
			GetResource("$IndividualsTotalGraph/DataArea/OffsetRight", &offright);

			GetResource("$IndividualsTotalGraph/InnerHeight", &innerHeight);
			GetResource("$IndividualsTotalGraph/InnerWidth", &innerWidth);

			double Xval, Yval, xx, yy;
			double xMax, yMax;
			GetResource("$IndividualsTotalGraph/YHigh", &yMax);
			GetResource("$IndividualsTotalGraph/XHigh", &xMax);

			XvalMouse = (mouse.x - offleft) /
				(innerWidth - offleft + offright * innerWidth / 2000);

			YvalMouse = (innerHeight - mouse.y + offbott) /
				(innerHeight + offbott + offtop * innerHeight / 2000);

			for (int generN = 0; generN < nGenerations; ++generN)
			{
				for (int idx = 0; idx < pGenDat->pIndividualsTotSortedVal->size(); ++idx)
				{
					strX = "$IndividualsTotalGraph/DataGroupOne/DataGroup"
						+ to_string(generN) + "/Points/DataSample"
						+ to_string(idx) + "/XValue";
					GetResource(strX.c_str(), &xx);
					strY = "$IndividualsTotalGraph/DataGroupOne/DataGroup"
						+ to_string(generN) + "/Points/DataSample"
						+ to_string(idx) + "/YValue";
					GetResource(strY.c_str(), &yy);

					Xval = xx / xMax;
					Yval = yy / yMax;
					dist2 = (Xval - XvalMouse) * (Xval - XvalMouse)
						+ (Yval - YvalMouse) * (Yval - YvalMouse);
					if (dist2 < dist2prev)
					{
						generNear = generN;
						indivNear = (int)xx;
						dist2prev = dist2;
					}
				}
			}

			pGenDat = CivData::pCivData->pCivilizationData->at(generNear);
			if (CivData::pCivData->currentGenerationN == generNear
				&& CivData::pCivData->currentIndividualN ==
				(*pGenDat->pIndividualsTotSortedVal)[indivNear].second)
				break;

			CivData::pCivData->currentGenerationN = generNear;

			CivData::pCivData->currentIndividualN =
				(*pGenDat->pIndividualsTotSortedVal)[indivNear].second;

			CivData::pCivData->pInterface
				->SetResource("SpinnerSelectIndividual/Value",
					CivData::pCivData->currentIndividualN);
			CivData::pCivData->pInterface
				->SetResource("SpinnerSelectTotalIndividual/Value",
					CivData::pCivData->currentIndividualN);

			plotCurrentIndividual();

			break;

		case RESIZE:
			break;

		case MOUSE_MOVE:
			break;

		default: return;
		}
	}
}

void CivInterface::Input(GlgObjectC& viewport, GlgObjectC& message)
{
	CONST char
		* format,
		* action,
		* origin;

	// Get the message's format, action and origin.
	message.GetResource("Format", &format);
	message.GetResource("Action", &action);
	message.GetResource("Origin", &origin);

	// Handle window closing. May use viewport's name.
	if (strcmp(format, "Window") == 0)
	{
		if (strcmp(action, "DeleteWindow") == 0)
			exit(0);
	}

	// Process CustomEvents
	else if (strcmp(format, "CustomEvent") == 0 &&
		strcmp(action, "MouseClick") == 0)
	{
		/*
			message.GetResource("EventLabel", &event_label);
			if (strcmp(event_label, "MarkerClick") == 0) //Graph Bar selected
			{
				message.GetResource("Object/DisableInput", &XValue);
				message.GetResource("Object/DrawMarkers", &mouse.x);
				//message.GetResource("Object/", &mouse.z);
				//			message.GetResource("Object/YValue", &YValue);
			}
		}
		else if (strcmp(format, "ObjectSelection") == 0
			&& strcmp(action, "MouseClick") == 0)
		{
			GlgObject selection_array =
				GlgGetResourceObject(message, (char *)"SelectionArray");
			for (int i = 0; i < GlgGetSize(selection_array); ++i)
				GlgObject selected_object = GlgGetElement(selection_array, i);//
		*/
	}
	else if (strcmp(format, "Text") == 0  // Input Box
		&& strcmp(action, "ValueChanged") == 0)
	{
		double value;
		if (strcmp(origin, "GPlotEveryNstepsBox") == 0)
		{
			GetResource("GPlotEveryNstepsBox/Value", &value);
			CivData::pCivData->at(CivData::kPlotEveryNsteps) = (int)value;

			previousSelectedIndiv = -1;

			plotAggregates();
			plotMarketPrices();
			plotTotalHomeGoods();

			plotCentralBankValues();
			plotTotalCash();
			plotTheStateValues();
			plotTheStateGoods();

			plotCurrentIndividual();
		}
		if (strcmp(origin, "MaxNplotCurvesBox") == 0)
		{
			GetResource("MaxNplotCurvesBox/Value", &value);
			CivData::pCivData->at(CivData::kMaxNplotCurves) = value;

			plotAggregates();
			plotMarketPrices();
			plotTotalHomeGoods();

			plotCentralBankValues();
			plotTotalCash();
			plotTheStateValues();
			plotTheStateGoods();

			plotCurrentIndividual();
		}
	}
	// Input event occurred in a button.
	else if (strcmp(format, "Button") == 0) //************ BUTTONS  **********************
	{
		if (strcmp(action, "Activate") == 0) //***** Push buttons *********************
		{ //for Toggle button events use "ValueChanged" and GetResource( "OnState", &value )
			if (strcmp(origin, "QuitButton") == 0)
				// User selected a Quit button: exit the program.
				exit(0);
			else if (strcmp(origin, "RunButton") == 0)
				RunButton();
			else if (strcmp(origin, "ButtonLoadParameters") == 0)
				LoadParametersButton();
			else if (strcmp(origin, "ButtonSaveParameters") == 0)
			{
				ReadInputInterface();
			}
		}
		else if (strcmp(action, "ValueChanged") == 0) //********Toggle buttons ********
		{
			if (strcmp(origin, "IndivPlusWriteButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				if (value)
					plotIndivPlusProdPlusBankFinalValues();
			}
			else if (strcmp(origin, "BanksFinalValuesSymbolsButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				switch ((int)value)
				{
				case 0:
					SetResource("$BanksFinalValuesGraph/DataGroup/DrawMarkers", 0.);
					break;
				case 1:
					SetResource("$BanksFinalValuesGraph/DataGroup/DrawMarkers", 1.);
					break;
				default: break;
				}
				plotBanksFinalTotalValues();
				plotBankValues();
			}
			else if (strcmp(origin, "GoodsSymbolsButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				switch ((int)value)
				{
				case 0:
					SetResource("$TotalGoodsGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);
					break;
				case 1:
					SetResource("$TotalGoodsGraph/DataGroupOne/DataGroup/DrawMarkers", 1.);
					break;
				default: break;
				}
				plotTotalHomeGoods();
			}
			else if (strcmp(origin, "TotalGoodsLegendButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				switch ((int)value)
				{
				case 0:
					SetResource("$TotalGoodsGraph/LegendObject/Visibility", 0.);
					break;
				case 1:
					SetResource("$TotalGoodsGraph/LegendObject/Visibility", 1.);
					break;
				default: break;
				}
				plotTotalHomeGoods();
			}
			else if (strcmp(origin, "TotalGoodsWriteButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				if (value)
					plotTotalHomeGoods();
			}
			else if (strcmp(origin, "AggregatesLegendButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				switch ((int)value)
				{
				case 0:
					SetResource("$AggregatesGraph/LegendObject/Visibility", 0.);
					break;
				case 1:
					SetResource("$AggregatesGraph/LegendObject/Visibility", 1.);
					break;
				default: break;
				}
				plotAggregates();
			}
			else if (strcmp(origin, "AggregatesWriteButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				if (value)
					plotAggregates();
			}
			else if (strcmp(origin, "TheStateGoodsWriteButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				if (value)
					plotTheStateGoods();
			}
			else if (strcmp(origin, "IndividualGoodsSymbolsButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				switch ((int)value)
				{
				case 0:
					SetResource("$IndividualGoodsGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);
					break;
				case 1:
					SetResource("$IndividualGoodsGraph/DataGroupOne/DataGroup/DrawMarkers", 1.);
					break;
				default: break;
				}
				plotIndivHomeGoods();
			}
			else if (strcmp(origin, "IndividualGoodsLegendButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				switch ((int)value)
				{
				case 0:
					SetResource("$IndividualGoodsGraph/LegendObject/Visibility", 0.);
					break;
				case 1:
					SetResource("$IndividualGoodsGraph/LegendObject/Visibility", 1.);
					break;
				default: break;
				}
				plotIndivHomeGoods();
			}
			else if (strcmp(origin, "IndividualGoodsLockButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				if (!value)
					plotIndivHomeGoods();
			}
			else if (strcmp(origin, "IndividualGoodsWriteButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				if (value)
					plotIndivHomeGoods();
			}
			else if (strcmp(origin, "ProducerValuesLegendButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				switch ((int)value)
				{
				case 0:
					SetResource("$ProducerValuesGraph/LegendObject/Visibility", 0.);
					break;
				case 1:
					SetResource("$ProducerValuesGraph/LegendObject/Visibility", 1.);
					break;
				default: break;
				}
				plotProducerValues();
			}
			else if (strcmp(origin, "ProducerValuesLockButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				if (!value)
					plotProducerValues();
			}
			else if (strcmp(origin, "ProducerValuesWriteButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				if (value)
					plotProducerValues();
			}
			else if (strcmp(origin, "ProducerValuesSymbButton") == 0)
			{
				plotProducerValues();
			}
			else if (strcmp(origin, "IndividualValuesLockButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				if (!value)
					plotIndividualValues();
			}
			else if (strcmp(origin, "IndividualValuesSymbButton") == 0)
			{
				plotIndividualValues();
			}
			else if (strcmp(origin, "MarketPricesSymbolsButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				switch ((int)value)
				{
				case 0:
					SetResource("$MarketPricesGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);
					break;
				case 1:
					SetResource("$MarketPricesGraph/DataGroupOne/DataGroup/DrawMarkers", 1.);
					break;
				default: break;
				}
				plotMarketPrices();
			}
			else if (strcmp(origin, "MarketPricesLegendButton") == 0)
			{
				double value;
				message.GetResource("OnState", &value);

				switch ((int)value)
				{
				case 0:
					SetResource("$MarketPricesGraph/LegendObject/Visibility", 0.);
					break;
				case 1:
					SetResource("$MarketPricesGraph/LegendObject/Visibility", 1.);
					break;
				default: break;
				}
				plotMarketPrices();
			}
		}
	}
	else if (strcmp(format, "Spinner") == 0) //************ SPINNERS  **********************
	{
		double ni;
		double thisYearValue = 0;
		if (strcmp(origin, "SpinnerSelectIndividual") == 0)
		{
			if (!OutputDataValid)
			{
				message.SetResource("Value", 0.);
				Update();
				return;
			}

			// Retrieve current value from a message object.
			message.GetResource("Value", &ni);

			if (ni != CivData::pCivData->currentIndividualN)
			{
				CivData::pCivData->currentIndividualN = ni;

				plotCurrentIndividual();
			}
		}
		else if (strcmp(origin, "SpinnerLineWidth") == 0)
		{
			if (!OutputDataValid)
			{
				//message.SetResource("Value", 0.);
				//Update();
				return;
			}

			double value;
			// Retrieve current value from a message object.
			message.GetResource("Value", &value);

			if ((int)value != _lineWidth)
			{
				_lineWidth = value;

				plotAggregates();
				plotMarketPrices();
				plotTotalHomeGoods();

				plotCentralBankValues();
				plotTotalCash();
				plotTheStateValues();
				plotTheStateGoods();

				plotCurrentIndividual();
			}
		}
		else if (strcmp(origin, "SpinnerYears") == 0)
		{
			/*double nYears, prevMax;
			message.GetResource("MaxValue", &prevMax);
			message.SetResource("MaxValue", MaxYears);

			message.GetResource("Value", &nYears);
			CivData::pCivData->at(CivData::kYears) = nYears;

			message.SetResource("MaxValue", nYears);// max(prevMax, nYears));*/
		}
		else if (strcmp(origin, "SpinnerSelectTotalIndividual") == 0)
		{
			// Retrieve current value from a message object.
			message.GetResource("Value", &ni);
			if ((int)ni != CivData::pCivData->currentIndividualN)
			{
				CivData::pCivData->currentIndividualN = ni;
				SetResource("SpinnerSelectIndividual/Value", ni);

				plotCurrentIndividual();
			}
		}
	}
}


void CivInterface::plotIndivPlusProdPlusBankFinalValues()
{
	if (!OutputDataValid)
		return;

	/*double lock;
	GetResource("IndivPlusProdPlusBankLockButton/OnState", &lock);
	if (lock)
		return;*/

	CGenerationData* pGenDat = CivData::pCivData->pCurrentGenerationData;
	const vector< pair<double, GoodID> >* pIndivPlusProdPlusBankFinalSortedVal =
		CivData::pCivData->pCurrentGenerationData
		->pIndivPlusProdPlusBankFinalSortedVal;

	int nToPlot = (int)pIndivPlusProdPlusBankFinalSortedVal->size();

	int generN = 0;
	int Ncurves = 1;
	SetResource("$IndivPlusProdPlusBankGraph/DataGroupOne/Factor", Ncurves);
	SetResource("$IndivPlusProdPlusBankGraph/DataGroupOne/DataGroup/Factor",
		1 + (double)nToPlot);
	//SetResource("$IndivPlusProdPlusBankGraph/DataGroupOne/DataGroup/DrawLines", 1);
	//SetResource("$IndivPlusProdPlusBankGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);
	SetResource("$IndivPlusProdPlusBankGraph/XLabelGroup/Factor", 10);
	// X axis tics
	SetResource("$IndivPlusProdPlusBankGraph/XHigh", (double)nToPlot - 1);

	double maxYValue =
		pGenDat->pIndivPlusProdPlusBankFinalSortedVal->front().first;
	double minYValue =
		pGenDat->pIndivPlusProdPlusBankFinalSortedVal->back().first;

	double YHigh = 1.1 * maxYValue;
	double YLow = min(0, minYValue);
	SetResource("$IndivPlusProdPlusBankGraph/YHigh", YHigh);
	SetResource("$IndivPlusProdPlusBankGraph/YLow", YLow);
	SetResource("$IndivPlusProdPlusBankGraph/YLabelGroup/Factor", 5);
	SetResource("$IndivPlusProdPlusBankGraph/YLabelGroup/MinorFactor", 0.);
	SetResource("$IndivPlusProdPlusBankGraph/YAxisLabel/FontSize", 5);
	SetResource("$IndivPlusProdPlusBankGraph/YAxisLabel/String", "Total");
	Update();

	string str = "Click to select an Indiv.";
	SetResource("$IndivPlusProdPlusBankGraph/MyText/String", str.c_str());

	// Draw markers on selected generation curve only

	str = "$IndivPlusProdPlusBankGraph/DataGroupOne/DataGroup"
		+ to_string(generN) + "/DrawLines";// select curve
	SetResource(str.c_str(), 0.);
	if (generN == CivData::pCivData->currentGenerationN)
	{
		str = "$IndivPlusProdPlusBankGraph/DataGroupOne/DataGroup"
			+ to_string(generN) + "/DrawMarkers";// select curve
		SetResource(str.c_str(), 1.);
	}
	else
	{
		str = "$IndivPlusProdPlusBankGraph/DataGroupOne/DataGroup"
			+ to_string(generN) + "/DrawMarkers";// select curve
		SetResource(str.c_str(), 0.);
	}
	Update();

	double WriteButton = 0.0;
	GetResource("IndivPlusWriteButton/OnState", &WriteButton);

	ofstream indivOutf;
	if (WriteButton)
	{
		indivOutf.open("_IndivPlusProd.c");
		indivOutf << "\nIndivPlusProdPlusBank:\n";
	}

	// Plot Producers total values

	for (int indivN = 0; indivN < nToPlot; ++indivN)
	{
		string strX = "$IndivPlusProdPlusBankGraph/DataGroupOne/DataGroup"
			+ to_string(generN) + "/XEntryPoint";// select curve
		SetResource(strX.c_str(), indivN);

		string strY = "$IndivPlusProdPlusBankGraph/DataGroupOne/DataGroup"
			+ to_string(generN) + "/YEntryPoint";
		SetResource(strY.c_str(),
			(*pIndivPlusProdPlusBankFinalSortedVal)[indivN].first);

		if (WriteButton)
			indivOutf << indivN << " "
			<< (*pIndivPlusProdPlusBankFinalSortedVal)[indivN].first << endl;
	}
	Update();
}

void CivInterface::plotBanksFinalTotalValues()
{
	if (!OutputDataValid
		|| CivData::pCivData->pCurrentGenerationData->mBankData.size() == 0)
		return;

	CGenerationData& GenDat = *CivData::pCivData->pCurrentGenerationData;

	int currGenerN = (int)CivData::pCivData->currentGenerationN;
	int nIndividuals =
		CivData::pCivData->pCivilizationData->at(currGenerN)->nIndividuals;
	int nTimesteps = CivData::pCivData->at(CivData::kYears)
		* CivData::pCivData->stepsPerYear;

	auto pGenDat = CivData::pCivData->pCurrentGenerationData;
	const auto BanksFinalTotal = pGenDat->mBankData;

	GoodValue YHigh = 0;
	GoodValue YLow = 0;
	for (auto pair : BanksFinalTotal)
	{
		if (pair.second->pColectedInterests->at(nTimesteps - 1) > YHigh)
			YHigh = pair.second->pColectedInterests->at(nTimesteps - 1);
		if (pair.second->pColectedInterests->at(nTimesteps - 1) < YLow)
			YLow = pair.second->pColectedInterests->at(nTimesteps - 1);
	}

	// X axis
	int nXpoints = max(2, (int)BanksFinalTotal.size());
	SetResource("$BanksFinalValuesGraph/DataGroup/Factor", nXpoints);
	SetResource("$BanksFinalValuesGraph/XLabelGroup/Factor", nXpoints - 1);
	SetResource("$BanksFinalValuesGraph/XLow", 0.0);
	SetResource("$BanksFinalValuesGraph/XHigh", nXpoints - 1);
	// Y axis
	SetResource("$BanksFinalValuesGraph/YLow", YLow);
	SetResource("$BanksFinalValuesGraph/YHigh", YHigh);
	SetResource("$BanksFinalValuesGraph/YLabelGroup/Factor", 5);
	SetResource("$BanksFinalValuesGraph/YAxisLabel/String", "M.U.");
	SetResource("$BanksFinalValuesGraph/YLabelGroup/YLabel/Format", "%.1E");

	SetResource("$BanksFinalValuesGraph/XLabelGroup/MinorFactor", 0.);

	SetResource("$BanksFinalValuesGraph/DataGroup/DrawLines", 1.);
	SetResource("$BanksFinalValuesGraph/DataGroup/Polygon/LineWidth", _lineWidth);
	SetResource("$BanksFinalValuesGraph/DataGroup/DrawMarkers", 1.);
	SetResource("$BanksFinalValuesGraph/DataGroup/Marker/MarkerSize", 14.);

	double symb;
	GetResource("BanksFinalValuesSymbolsButton/OnState", &symb);
	Update();
	string strX;
	int bankN = -1;
	for (auto pair : BanksFinalTotal)
	{
		++bankN;

		SetResource("$BanksFinalValuesGraph/DataGroup/XEntryPoint", bankN);
		SetResource("$BanksFinalValuesGraph/DataGroup/YEntryPoint",
			pair.second->pColectedInterests->at(nTimesteps - 1));

		bool visib = symb;
		if (GenDat.selectedBankN >= 0)
			visib = (!symb && bankN == pGenDat->selectedBankN)
			|| (symb && bankN != pGenDat->selectedBankN);

		strX = "$BanksFinalValuesGraph/DataGroup/Markers/Marker"
			+ to_string(bankN) + "/Visibility";
		SetResource(strX.c_str(), visib);
	}

	Update();
}

void CivInterface::plotProducersTotalValues()
{
	if (!OutputDataValid)
		return;

	CGenerationData* pGenDat = CivData::pCivData->pCurrentGenerationData;
	const vector< pair<double, GoodID> >* pProducersTotSortedVal =
		CivData::pCivData->pCurrentGenerationData->pProducersTotSortedVal;

	int nToPlot = (int)pProducersTotSortedVal->size();

	int generN = 0;
	int Ncurves = 1;
	SetResource("$ProducersTotalGraph/DataGroupOne/Factor", Ncurves);
	SetResource("$ProducersTotalGraph/DataGroupOne/DataGroup/Factor",
		1 + (double)nToPlot);
	SetResource("$ProducersTotalGraph/DataGroupOne/DataGroup/DrawLines", 1);
	SetResource("$ProducersTotalGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);
	SetResource("$ProducersTotalGraph/XLabelGroup/Factor", 10);
	// X axis tics
	SetResource("$ProducersTotalGraph/XHigh", (double)nToPlot - 1);

	double maxYValue =
		pGenDat->pProducersTotSortedVal->front().first;
	double minYValue =
		pGenDat->pProducersTotSortedVal->back().first;

	double YHigh = 1.1 * maxYValue;
	double YLow = min(0, minYValue);
	SetResource("$ProducersTotalGraph/YHigh", YHigh);
	SetResource("$ProducersTotalGraph/YLow", YLow);
	SetResource("$ProducersTotalGraph/YLabelGroup/Factor", 5);
	SetResource("$ProducersTotalGraph/YLabelGroup/MinorFactor", 0.);
	SetResource("$ProducersTotalGraph/YAxisLabel/FontSize", 5);
	SetResource("$ProducersTotalGraph/YAxisLabel/String", "Total");
	Update();

	string str = "Click to select an Individual's Producers";
	SetResource("$ProducersTotalGraph/MyText/String", str.c_str());

	// Draw markers on selected generation curve only

	str = "$ProducersTotalGraph/DataGroupOne/DataGroup"
		+ to_string(generN) + "/DrawLines";// select curve
	SetResource(str.c_str(), 0.);
	if (generN == CivData::pCivData->currentGenerationN)
	{
		str = "$ProducersTotalGraph/DataGroupOne/DataGroup"
			+ to_string(generN) + "/DrawMarkers";// select curve
		SetResource(str.c_str(), 1.);
	}
	else
	{
		str = "$ProducersTotalGraph/DataGroupOne/DataGroup"
			+ to_string(generN) + "/DrawMarkers";// select curve
		SetResource(str.c_str(), 0.);
	}
	Update();

	// Plot Producers total values

	for (int indivN = 0; indivN < nToPlot; ++indivN)
	{
		string strX = "$ProducersTotalGraph/DataGroupOne/DataGroup"
			+ to_string(generN) + "/XEntryPoint";// select curve
		SetResource(strX.c_str(), indivN);

		string strY = "$ProducersTotalGraph/DataGroupOne/DataGroup"
			+ to_string(generN) + "/YEntryPoint";
		SetResource(strY.c_str(), (*pProducersTotSortedVal)[indivN].first);
	}
	Update();
}

void CivInterface::plotIndividualsTotalValues()
{
	if (!OutputDataValid)
		return;

	/*double lock;
	GetResource("IndividualsTotalLockButton/OnState", &lock);
	if (lock)
		return;*/

	CGenerationData* pGenDat = CivData::pCivData->pCurrentGenerationData;
	const vector< pair<double, GoodID> >* pIndividualsTotSortedVal =
		CivData::pCivData->pCurrentGenerationData->pIndividualsTotSortedVal;

	int nToPlot = (int)pIndividualsTotSortedVal->size();

	int generN = 0;
	int Ncurves = 1;
	SetResource("$IndividualsTotalGraph/DataGroupOne/Factor", Ncurves);
	SetResource("$IndividualsTotalGraph/DataGroupOne/DataGroup/Factor",
		1 + (double)nToPlot);
	SetResource("$IndividualsTotalGraph/DataGroupOne/DataGroup/DrawLines", 1);
	SetResource("$IndividualsTotalGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);
	SetResource("$IndividualsTotalGraph/XLabelGroup/Factor", 10);
	// X axis tics
	SetResource("$IndividualsTotalGraph/XHigh", (double)nToPlot - 1);

	double maxYValue =
		pGenDat->pIndividualsTotSortedVal->front().first;
	double minYValue =
		pGenDat->pIndividualsTotSortedVal->back().first;

	double YHigh = 1.1 * maxYValue;
	double YLow = min(0, minYValue);
	SetResource("$IndividualsTotalGraph/YHigh", YHigh);
	SetResource("$IndividualsTotalGraph/YLow", YLow);
	SetResource("$IndividualsTotalGraph/YLabelGroup/Factor", 5);
	SetResource("$IndividualsTotalGraph/YLabelGroup/MinorFactor", 0.);
	SetResource("$IndividualsTotalGraph/YAxisLabel/FontSize", 5);
	SetResource("$IndividualsTotalGraph/YAxisLabel/String", "Total");
	Update();

	string str = "Click to select an Indiv.";
	SetResource("$IndividualsTotalGraph/MyText/String", str.c_str());

	// Draw markers on selected generation curve only

	str = "$IndividualsTotalGraph/DataGroupOne/DataGroup"
		+ to_string(generN) + "/DrawLines";// select curve
	SetResource(str.c_str(), 0.);
	if (generN == CivData::pCivData->currentGenerationN)
	{
		str = "$IndividualsTotalGraph/DataGroupOne/DataGroup"
			+ to_string(generN) + "/DrawMarkers";// select curve
		SetResource(str.c_str(), 1.);
	}
	else
	{
		str = "$IndividualsTotalGraph/DataGroupOne/DataGroup"
			+ to_string(generN) + "/DrawMarkers";// select curve
		SetResource(str.c_str(), 0.);
	}
	Update();

	// Plot Individuals total values

	for (int indivN = 0; indivN < nToPlot; ++indivN)
	{
		string strX = "$IndividualsTotalGraph/DataGroupOne/DataGroup"
			+ to_string(generN) + "/XEntryPoint";// select curve
		SetResource(strX.c_str(), indivN);

		string strY = "$IndividualsTotalGraph/DataGroupOne/DataGroup"
			+ to_string(generN) + "/YEntryPoint";
		SetResource(strY.c_str(), (*pIndividualsTotSortedVal)[indivN].first);
	}
	Update();
}


void CivInterface::plotAggregates()
{
	if (!OutputDataValid)
		return;

	int nIndividuals = CivData::pCivData->pGeneration->nIndividuals;
	int nTimesteps = CivData::pCivData->pGeneration->nTimesteps;

	CGenerationData& generationData = *CivData::pCivData->pCurrentGenerationData;

	vector<double> maxCurvesValue;
	GoodValue maxVal = 0;
	vector< vector<double>* > AggregateCurves;

	// GDP and Unemployment

	vector<double> GDP(nTimesteps, 0);

	GDP[0] = (*generationData.pAccumGDP)[0];
	for (int nn = 1; nn < nTimesteps; ++nn)
		if (nn % 12 != 0)
			GDP[nn] = GDP[nn - 1];
		else
			GDP[nn] = (*generationData.pAccumGDP)[nn]
			- (*generationData.pAccumGDP)[nn - 1];
	for (int nn = 1; nn < nTimesteps; ++nn)
		GDP[nn] /= (nIndividuals / 12.0);// yearly GDP

	AggregateCurves.push_back(&GDP);
	AggregateCurves.push_back(generationData.pUnemployment);
	std::vector<string> labels = { "GDPperCap", "UnemplMax" };

	// Find max for Y axis for each curve
	for (int n = 0; n < AggregateCurves.size(); ++n)
	{
		maxCurvesValue.push_back(*max_element(AggregateCurves[n]->begin(),
			AggregateCurves[n]->end()));
	}

	string str0, str1;
	char buff[100];
	int Ncurves = (int)AggregateCurves.size();
	SetResource("$AggregatesGraph/DataGroupOne/Factor", Ncurves);
	SetResource("$AggregatesGraph/DataGroupOne/DataGroup/Factor", nTimesteps);
	// Y axis
	SetResource("$AggregatesGraph/YLow", 0.0);
	SetResource("$AggregatesGraph/YHigh", 100.0);
	SetResource("$AggregatesGraph/YAxisLabel/String", " (%) ");
	SetResource("$AggregatesGraph/YLabelGroup/YLabel/Format", "%.0lf");
	// X axis
	SetResource("$AggregatesGraph/XLow", 0.0);
	SetResource("$AggregatesGraph/XHigh", nTimesteps);
	SetResource("$AggregatesGraph/XLabelGroup/Factor", 10);
	SetResource("$AggregatesGraph/XLabelGroup/MinorFactor", 0.);

	SetResource(
		"$AggregatesGraph/LegendObject/LegendGroup/Legend/LegendLabel/FontSize",
		fontSize);
	string strX = "$AggregatesGraph/DataGroupOne/DataGroup/Polygon/LineWidth";
	SetResource(strX.c_str(), _lineWidth);
	Update();
	int curveN = -1;
	for (int curveN = 0; curveN < AggregateCurves.size(); ++curveN)
	{
		str0 = "$AggregatesGraph/LegendObject/LegendGroup/Legend/Text"
			+ to_string(curveN);
		strX = labels.at(curveN) + "= %-.1E";
		std::sprintf(buff, strX.c_str(), maxCurvesValue[curveN]);

		SetResource(str0.c_str(), buff);
	}
	Update();

	double WriteButton = 0.0;
	GetResource("AggregatesWriteButton/OnState", &WriteButton);

	ofstream indivOutf;
	if (WriteButton)
	{
		indivOutf.open("_Aggregates.c");
	}

	curveN = -1;
	for (int curveN = 0; curveN < AggregateCurves.size(); ++curveN)
	{
		if (maxCurvesValue[curveN] == 0)
			continue;

		if (WriteButton)
			indivOutf << endl << labels.at(curveN) << ":\n";

		for (int timestep = 0; timestep < (*AggregateCurves[curveN]).size(); ++timestep)
		{
			if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
				&& timestep != nTimesteps - 1)
				continue;

			string strX = "$AggregatesGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/XEntryPoint";
			SetResource(strX.c_str(), timestep + 1);

			string strY = "$AggregatesGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/YEntryPoint";

			SetResource(strY.c_str(), (*AggregateCurves[curveN])[timestep]
				* 100.0 / maxCurvesValue[curveN]);

			if (WriteButton)
				indivOutf << timestep + 1 << " "
				<< (*AggregateCurves[curveN])[timestep] << endl;
		}
		Update();
	}
}

void CivInterface::plotMarketPrices()
{
	if (!OutputDataValid)
		return;

	int MaxNcurves = CivData::pCivData->at(CivData::kMaxNplotCurves);
	// plot up to maxNplotCurves curves with non zero maxCurvesValues
	int nTimesteps = CivData::pCivData->at(CivData::kYears)
		* CivData::pCivData->stepsPerYear;
	int nGoodIDs = CivData::pCivData->NGoodIDs;
	int initID = 0;
	const auto& marketPrice = CivData::pCivData->pCurrentGenerationData->MarketPrices;

	// Find max Y axis for each goodID
	map<GoodID, double> maxPrice;
	for (int gID = initID; gID < nGoodIDs; ++gID)
	{
		double maxGoodVal =
			*max_element(marketPrice[gID].begin(), marketPrice[gID].end());
		if (maxGoodVal > 0)
			maxPrice[gID] = maxGoodVal;
		else
			continue;

		if (maxPrice.size() >= MaxNcurves)
			break;
	}

	int curveN = -1;
	string str0, str1;
	int Ncurves = (int)maxPrice.size();
	SetResource("$MarketPricesGraph/DataGroupOne/Factor", Ncurves);// N curves, reset curves
	SetResource("$MarketPricesGraph/DataGroupOne/DataGroup/Factor", nTimesteps); // N data points
	// Y axis
	SetResource("$MarketPricesGraph/YLow", 0.0);
	SetResource("$MarketPricesGraph/YHigh", 100.0);
	SetResource("$MarketPricesGraph/YAxisLabel/String", " (%) ");
	SetResource("$MarketPricesGraph/YLabelGroup/YLabel/Format", "%.0lf");
	// X axis
	SetResource("$MarketPricesGraph/XLow", 0.0);
	SetResource("$MarketPricesGraph/XHigh", nTimesteps);
	SetResource("$MarketPricesGraph/XLabelGroup/Factor", 10);
	SetResource("$MarketPricesGraph/XLabelGroup/MinorFactor", 0.);
	curveN = -1;
	char buff[100];
	SetResource("$MarketPricesGraph/LegendObject/LegendGroup/Legend/LegendLabel/FontSize",
		fontSize);
	for (auto curvePair : maxPrice)
	{
		GoodID gID = curvePair.first;
		if (maxPrice.find(gID) == maxPrice.end())
			continue;

		++curveN;
		str0 = "$MarketPricesGraph/LegendObject/LegendGroup/Legend/Text" + to_string(curveN);
		sprintf(buff, " %-.1E ", maxPrice[gID]);
		str1 = buff + CivData::pCivData->GoodID2Name[gID];
		SetResource(str0.c_str(), str1.c_str());

		Update();

		string strX = "$MarketPricesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/Polygon/LineWidth";
		SetResource(strX.c_str(), _lineWidth);

		for (int timestep = 1; timestep < nTimesteps; ++timestep)
		{
			if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
				&& timestep != nTimesteps - 1)
				continue;

			// select curve and timestep
			string strX = "$MarketPricesGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/XEntryPoint";
			SetResource(strX.c_str(), timestep + 1);

			string strY = "$MarketPricesGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/YEntryPoint";
			SetResource(strY.c_str(), 100.0 * marketPrice[gID][timestep] / maxPrice[gID]);
		}
	}
	Update();
}

void CivInterface::plotTotalHomeGoods()
{
	if (!OutputDataValid)
		return;

	int nTimesteps = CivData::pCivData->at(CivData::kYears)
		* CivData::pCivData->stepsPerYear;
	CGenerationData* pGenDat = CivData::pCivData->pCurrentGenerationData;

	int nIndividuals = (int)pGenDat->pIndivData->size();
	int maxNplotCurves = CivData::pCivData->at(CivData::kMaxNplotCurves);
	// plot up to maxNplotCurves curves with non zero maxCurvesValues

	// Add all individuals Goods vs. timestep curves
	map<GoodID, TimeValueCurve* >  mTotalGoodCurves;

	for (int currIndivN = 0; currIndivN < nIndividuals; ++currIndivN)
	{
		auto mGoodsIhaveVal = pGenDat->pIndivData->at(currIndivN)->mGoodsIhave;
		for (auto curvePair : mGoodsIhaveVal)
		{
			GoodID gID = curvePair.first;
			if (gID >= CivData::pCivData->first_producerType) // skip producers
				continue;

			if (mTotalGoodCurves.find(gID) == mTotalGoodCurves.end())
				mTotalGoodCurves[gID] = new TimeValueCurve(nTimesteps, 0.0);
			vector<double>& values = *curvePair.second;

			for (int tstep = 0; tstep < values.size(); ++tstep)
				(*mTotalGoodCurves[gID])[tstep] += values[tstep];
		}
	}

	// Find each goodID max for Y axis
	map<GoodID, GoodValue> maxGoodValue;
	TimeValueCurve* pValues = nullptr;
	GoodValue maxGoodVal = 0;
	for (auto curvePair : mTotalGoodCurves)
	{
		GoodID gID = curvePair.first;
		pValues = curvePair.second;
		maxGoodVal = *max_element(pValues->begin(), pValues->end());
		if (maxGoodVal > 0)
			maxGoodValue[gID] = maxGoodVal;

		if (maxGoodValue.size() >= maxNplotCurves)
			break;
	}

	//-------  Legend  ----------------------------------------------------

	string str0, str1;
	/*int curveN = -1;
	SetResource("$TotalGoodsGraph/LegendObject/LegendGroup/Legend/LegendLabel/FontSize",
		fontSize);
	for (auto curvePair : maxGoodValue)
	{
		GoodID gID = curvePair.first;
		++curveN;

		str0 = "$TotalGoodsGraph/LegendObject/LegendGroup/Legend/Text"
			+ to_string(curveN);
		str1 = CivData::pCivData->GoodID2Name[gID] + "= "
			+ to_string(maxGoodValue[gID]);
		SetResource(str0.c_str(), str1.c_str());
	}*/
	//---------------------------------------------------------------------

	int Ncurves = (int)maxGoodValue.size();
	SetResource("$TotalGoodsGraph/DataGroupOne/Factor", Ncurves);// reset curves
	SetResource("$TotalGoodsGraph/DataGroupOne/DataGroup/Factor", nTimesteps); // N data points
	// Y axis
	SetResource("$TotalGoodsGraph/YLow", 0.0);
	SetResource("$TotalGoodsGraph/YHigh", 100.0);
	SetResource("$TotalGoodsGraph/YAxisLabel/String", " (%) ");
	SetResource("$TotalGoodsGraph/YLabelGroup/YLabel/Format", "%.0lf");
	// X axis
	SetResource("$TotalGoodsGraph/XLow", 0.0);
	SetResource("$TotalGoodsGraph/XHigh", nTimesteps);
	SetResource("$TotalGoodsGraph/XLabelGroup/Factor", 10);
	SetResource("$TotalGoodsGraph/XLabelGroup/MinorFactor", 0.);

	double WriteButton = 0.0;
	GetResource("TotalGoodsWriteButton/OnState", &WriteButton);

	ofstream indivOutf;
	if (WriteButton)
	{
		indivOutf.open("_TotalHomeGoods.c");
	}

	int curveN = -1;
	for (auto curvePair : maxGoodValue)
	{
		GoodID gID = curvePair.first;
		if (maxGoodValue.find(gID) == maxGoodValue.end())
			continue;

		if (WriteButton)
			indivOutf << endl << CivData::pCivData->GoodID2Name[gID] << ":\n";

		++curveN;
		str0 = "$TotalGoodsGraph/LegendObject/LegendGroup/Legend/Text" + to_string(curveN);
		str1 = to_string(maxGoodValue[gID]) + " " + CivData::pCivData->GoodID2Name[gID];

		SetResource(str0.c_str(), str1.c_str());
		Update();

		string strX = "$TotalGoodsGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/Polygon/LineWidth";
		SetResource(strX.c_str(), _lineWidth);

		pValues = mTotalGoodCurves[gID];

		for (int timestep = 0; timestep < nTimesteps; ++timestep)
		{
			if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
				&& timestep != nTimesteps - 1)
				continue;

			string strX = "$TotalGoodsGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/XEntryPoint";
			SetResource(strX.c_str(), timestep + 1);

			string strY = "$TotalGoodsGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/YEntryPoint";

			if (maxGoodValue[gID] > 0)
			{
				SetResource(strY.c_str(), (*pValues)[timestep]
					* 100.0 / maxGoodValue[gID]);
				if (WriteButton)
					indivOutf << timestep + 1 << " " << (*pValues)[timestep] << endl;
			}
		}
	}
	Update();
}


void CivInterface::plotCentralBankValues()
{
	if (!OutputDataValid || CivData::pCentralBank == nullptr)
		return;

	CGenerationData& GenDat = *CivData::pCivData->pCurrentGenerationData;

	int nTimesteps = CivData::pCivData->pGeneration->nTimesteps;

	vector< vector<double>* > BankCurves;
	BankCurves.push_back(GenDat.pCentralBankData->_pTotalBullion);
	BankCurves.push_back(GenDat.pCentralBankData->pColectedInterests);
	BankCurves.push_back(GenDat.pCentralBankData->pCash);
	BankCurves.push_back(GenDat.pCentralBankData->pTotalDeposits);
	BankCurves.push_back(GenDat.pCentralBankData->pTotalLoans);

	// Find max and min for Y axis for each curve

	vector<double> maxCurvesValues;
	vector<double> minCurvesValues;
	for (int n = 0; n < BankCurves.size(); ++n)
	{
		maxCurvesValues.push_back(*max_element(BankCurves[n]->begin(),
			BankCurves[n]->end()));
		minCurvesValues.push_back(*min_element(BankCurves[n]->begin(),
			BankCurves[n]->end()));
	}

	std::vector<string> labels =
	{ " Reserves", " Interests", " Cash", " Deposits", " Loans" };

	GoodValue maxValue = *max_element(maxCurvesValues.begin(),
		maxCurvesValues.end());
	GoodValue minValue = *min_element(minCurvesValues.begin(),
		minCurvesValues.end());

	string title;
	title = "Central Bank";
	SetResource("$CentralBankValuesGraph/Title/String", title.c_str());

	string str0, str1;
	char buff[100];
	int Ncurves = (int)BankCurves.size();
	SetResource("$CentralBankValuesGraph/DataGroupOne/Factor", Ncurves);// reset curves
	SetResource("$CentralBankValuesGraph/DataGroupOne/DataGroup/Factor", nTimesteps); // N data points
	// Y axis
	double YHigh = 1.0 * maxValue;
	double YLow = minValue;
	SetResource("$CentralBankValuesGraph/YLow", YLow);
	SetResource("$CentralBankValuesGraph/YHigh", YHigh);
	SetResource("$CentralBankValuesGraph/YLabelGroup/Factor", 10);
	SetResource("$CentralBankValuesGraph/YAxisLabel/String", " M.U. ");
	SetResource("$CentralBankValuesGraph/YLabelGroup/YLabel/Format", "%.1E");
	// X axis
	SetResource("$CentralBankValuesGraph/XLow", 0.0);
	SetResource("$CentralBankValuesGraph/XHigh", nTimesteps);
	SetResource("$CentralBankValuesGraph/XLabelGroup/Factor", 10);
	SetResource("$CentralBankValuesGraph/XLabelGroup/MinorFactor", 0.);
	SetResource("$CentralBankValuesGraph/DataGroupOne/DataGroup/DrawLines", 1.);
	SetResource("$CentralBankValuesGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);

	SetResource("$CentralBankValuesGraph/LegendObject/LegendGroup/Legend/LegendLabel/FontSize", fontSize);
	string strX = "$CentralBankValuesGraph/DataGroupOne/DataGroup/Polygon/LineWidth";
	SetResource(strX.c_str(), _lineWidth);
	Update();
	int curveN = -1;
	for (int curveN = 0; curveN < Ncurves; ++curveN)
	{
		str0 = "$CentralBankValuesGraph/LegendObject/LegendGroup/Legend/Text"
			+ to_string(curveN);
		strX = labels.at(curveN);// + "= %-.1E";
		std::sprintf(buff, strX.c_str(), maxCurvesValues[curveN]);

		SetResource(str0.c_str(), buff);
	}
	Update();

	curveN = -1;
	for (int curveN = 0; curveN < BankCurves.size(); ++curveN)
	{
		if (curveN == 0)
		{
			string str = "$CentralBankValuesGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/DrawMarkers";
			SetResource(str.c_str(), 1.);
		}
		Update();
		for (int timestep = 0; timestep < nTimesteps; ++timestep)
		{
			if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
				&& timestep != nTimesteps - 1)
				continue;

			string strX = "$CentralBankValuesGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/XEntryPoint";
			SetResource(strX.c_str(), timestep + 1);

			string strY = "$CentralBankValuesGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/YEntryPoint";

			SetResource(strY.c_str(), (*BankCurves[curveN])[timestep]);
		}
		Update();
	}
}

void CivInterface::plotTotalCash()
{
	if (!OutputDataValid || CivData::pCentralBank == nullptr)
		return;

	CGenerationData& GenDat = *CivData::pCivData->pCurrentGenerationData;

	int nTimesteps = CivData::pCivData->pGeneration->nTimesteps;

	vector< vector<double>* > CashCurves;
	CashCurves.push_back(GenDat.pCentralBankData->pCash);
	CashCurves.push_back(GenDat.pTotalBanksCash);
	CashCurves.push_back(GenDat.pIndivsCash);
	CashCurves.push_back(GenDat.pProdsCash);
	std::vector<string> labels = { " CBCash", " BanksCash", " IndivsCash", " ProdsCash" };

	// Find max and min for Y axis for each curve

	vector<double> maxCurvesValues;
	vector<double> minCurvesValues;
	for (int n = 0; n < CashCurves.size(); ++n)
	{
		maxCurvesValues.push_back(*max_element(CashCurves[n]->begin(),
			CashCurves[n]->end()));
		minCurvesValues.push_back(*min_element(CashCurves[n]->begin(),
			CashCurves[n]->end()));
	}

	GoodValue maxValue = *max_element(maxCurvesValues.begin(),
		maxCurvesValues.end());
	GoodValue minValue = *min_element(minCurvesValues.begin(),
		minCurvesValues.end());

	string title;
	title = "Total Cash";
	SetResource("$CashGraph/Title/String", title.c_str());

	string str0, str1;
	char buff[100];
	int Ncurves = (int)CashCurves.size();
	SetResource("$CashGraph/DataGroupOne/Factor", Ncurves);// reset curves
	SetResource("$CashGraph/DataGroupOne/DataGroup/Factor", nTimesteps); // N data points
	// Y axis
	double YHigh = 1.0 * maxValue;
	double YLow = minValue;
	SetResource("$CashGraph/YLow", YLow);
	SetResource("$CashGraph/YHigh", YHigh);
	SetResource("$CashGraph/YLabelGroup/Factor", 10);
	SetResource("$CashGraph/YAxisLabel/String", " M.U. ");
	SetResource("$CashGraph/YLabelGroup/YLabel/Format", "%.1E");
	// X axis
	SetResource("$CashGraph/XLow", 0.0);
	SetResource("$CashGraph/XHigh", nTimesteps);
	SetResource("$CashGraph/XLabelGroup/Factor", 10);
	SetResource("$CashGraph/XLabelGroup/MinorFactor", 0.);
	SetResource("$CashGraph/DataGroupOne/DataGroup/DrawLines", 1.);
	SetResource("$CashGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);

	SetResource("$CashGraph/LegendObject/LegendGroup/Legend/LegendLabel/FontSize",
		fontSize);
	string strX = "$CashGraph/DataGroupOne/DataGroup/Polygon/LineWidth";
	SetResource(strX.c_str(), _lineWidth);
	Update();
	int curveN = -1;
	for (int curveN = 0; curveN < Ncurves; ++curveN)
	{
		str0 = "$CashGraph/LegendObject/LegendGroup/Legend/Text"
			+ to_string(curveN);
		strX = labels.at(curveN);// +"= %-.1E";
		std::sprintf(buff, strX.c_str(), maxCurvesValues[curveN]);

		SetResource(str0.c_str(), buff);
	}
	Update();

	curveN = -1;
	for (int curveN = 0; curveN < CashCurves.size(); ++curveN)
	{
		for (int timestep = 0; timestep < nTimesteps; ++timestep)
		{
			if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
				&& timestep != nTimesteps - 1)
				continue;

			string strX = "$CashGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/XEntryPoint";
			SetResource(strX.c_str(), timestep + 1);

			string strY = "$CashGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/YEntryPoint";

			SetResource(strY.c_str(), (*CashCurves[curveN])[timestep]);
		}
		Update();
	}
}

void CivInterface::plotTheStateValues()
{
	if (!OutputDataValid)
		return;

	int nTimesteps = CivData::pCivData->at(CivData::kYears)
		* CivData::pCivData->stepsPerYear;
	int indivN = CivData::pCivData->currentIndividualN;

	CGenerationData* pGenDat = CivData::pCivData->pCurrentGenerationData;
	CTheStateData* pTheStateDat = pGenDat->pTheStateData;

	int Ncurves = 0;

	/**/vector<double>* pTheStateTotVal = pTheStateDat->pTotalValue;
	double maxTheStateTot = *max_element(pTheStateTotVal->begin(), pTheStateTotVal->end());
	double minTheStateTot = *min_element(pTheStateTotVal->begin(), pTheStateTotVal->end());
	Ncurves++;

	vector<GoodValue>* pTheStateCash = pTheStateDat->pCash;
	double maxTheStateMoney = *max_element(pTheStateCash->begin(), pTheStateCash->end());
	double minTheStateMoney = *min_element(pTheStateCash->begin(), pTheStateCash->end());
	Ncurves++;

	vector<GoodValue>* pTheStateAnnualTax = pTheStateDat->pAnnualTax;
	double maxTheStateAnnualTax =
		*max_element(pTheStateAnnualTax->begin(), pTheStateAnnualTax->end());
	double minTheStateAnnualTax =
		*min_element(pTheStateAnnualTax->begin(), pTheStateAnnualTax->end());
	Ncurves++;

	vector<GoodValue>* pTheStateAnnualVAT = pTheStateDat->pAnnualVAT;
	double maxTheStateAnnualVAT =
		*max_element(pTheStateAnnualVAT->begin(), pTheStateAnnualVAT->end());
	double minTheStateAnnualVAT =
		*min_element(pTheStateAnnualVAT->begin(), pTheStateAnnualVAT->end());
	Ncurves++;

	vector<GoodValue>* pTheStateAnnUnempl = pTheStateDat->pAnnUnempl;
	double maxTheStateAnnUnempl =
		*max_element(pTheStateAnnUnempl->begin(), pTheStateAnnUnempl->end());
	double minTheStateAnnUnempl =
		*min_element(pTheStateAnnUnempl->begin(), pTheStateAnnUnempl->end());
	Ncurves++;

	/**/vector<GoodValue>* pTheStateLoan = pTheStateDat->pLoan;// plotted as Savings = -pLoan
	double maxTheStateLoan = -*min_element(pTheStateLoan->begin(), pTheStateLoan->end());
	double minTheStateLoan = -*max_element(pTheStateLoan->begin(), pTheStateLoan->end());
	Ncurves++;

	double YHigh = 1.0 * max<double>({
		maxTheStateTot, maxTheStateMoney, maxTheStateAnnualTax, maxTheStateAnnualVAT,
		maxTheStateAnnUnempl, maxTheStateLoan });
	double YLow = 1.0 * min<double>({ 0,
		minTheStateTot, minTheStateMoney, minTheStateAnnualTax, minTheStateAnnualVAT,
		minTheStateAnnUnempl, minTheStateLoan });

	//--------------------------------------------------------

	string title;
	title = " TheState Values";
	SetResource("$TheStateValuesGraph/Title/String", title.c_str());

	SetResource("$TheStateValuesGraph/DataGroupOne/Factor", Ncurves);
	SetResource("$TheStateValuesGraph/DataGroupOne/DataGroup/Factor",
		nTimesteps);

	string str0, str1;
	string strX, strY;

	//-----  Legend  ------------------------------------------

	SetResource(
		"$TheStateValuesGraph/LegendObject/LegendGroup/Legend/LegendLabel/FontSize",
		fontSize);

	int curveN = 0;
	str0 = "$TheStateValuesGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	SetResource(str0.c_str(), " Total");

	++curveN;
	str0 = "$TheStateValuesGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	SetResource(str0.c_str(), " Cash");

	++curveN;
	str0 = "$TheStateValuesGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	SetResource(str0.c_str(), " TaxInfo");

	++curveN;
	str0 = "$TheStateValuesGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	SetResource(str0.c_str(), " VATInfo");

	++curveN;
	str0 = "$TheStateValuesGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	SetResource(str0.c_str(), " AccUnempInf");

	++curveN;
	str0 = "$TheStateValuesGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	SetResource(str0.c_str(), " Savings");

	Update();

	//--------------------------------------------------------

	double LockButton = 0.0;
	GetResource("TheStateValuesLockButton/OnState", &LockButton);
	if (LockButton != 0.0)
		return;

	//------  Plot curves  -----------------------------

	// Y axis
	SetResource("$TheStateValuesGraph/YLow", YLow);
	SetResource("$TheStateValuesGraph/YHigh", YHigh);// 110.0);
	//SetResource("$TheStateValuesGraph/YAxisLabel/String", " (%) ");
	SetResource("$TheStateValuesGraph/YLabelGroup/YLabel/Format", "%.1E");
	// X axis
	SetResource("$TheStateValuesGraph/XLow", 0.0);
	SetResource("$TheStateValuesGraph/XHigh", nTimesteps);
	SetResource("$TheStateValuesGraph/XLabelGroup/Factor", 10);
	SetResource("$TheStateValuesGraph/XLabelGroup/MinorFactor", 0.);
	strX = "$TheStateValuesGraph/DataGroupOne/DataGroup"
		+ to_string(curveN) + "/LineWidth";
	SetResource(strX.c_str(), _lineWidth);

	curveN = 0;
	strX = "$TheStateValuesGraph/DataGroupOne/DataGroup"
		+ to_string(curveN) + "/DrawMarkers";
	SetResource(strX.c_str(), 1.);
	Update();

	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		strX = "$TheStateValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep);

		strY = "$TheStateValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		SetResource(strY.c_str(), (*pTheStateTotVal)[timestep]
		);
	}
	Update();

	++curveN;
	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		strX = "$TheStateValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep);

		strY = "$TheStateValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		SetResource(strY.c_str(), (*pTheStateCash)[timestep]);
	}
	Update();

	++curveN;
	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		strX = "$TheStateValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep);

		strY = "$TheStateValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		SetResource(strY.c_str(), (*pTheStateAnnualTax)[timestep]);
	}
	Update();

	++curveN;
	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		strX = "$TheStateValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep);

		strY = "$TheStateValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		SetResource(strY.c_str(), (*pTheStateAnnualVAT)[timestep]);
	}
	Update();

	++curveN;
	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		strX = "$TheStateValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep);

		strY = "$TheStateValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		SetResource(strY.c_str(), (*pTheStateAnnUnempl)[timestep]);
	}
	Update();

	++curveN; // Savings
	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		strX = "$TheStateValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep);

		strY = "$TheStateValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		SetResource(strY.c_str(), -(*pTheStateLoan)[timestep]);
	}

	Update();
}

void CivInterface::plotTheStateGoods()
{
	if (!OutputDataValid)
		return;

	int nTimesteps = CivData::pCivData->at(CivData::kYears)
		* CivData::pCivData->stepsPerYear;

	CGenerationData* pGenDat = CivData::pCivData->pCurrentGenerationData;

	int maxNplotCurves = CivData::pCivData->at(CivData::kMaxNplotCurves);
	// plot up to maxNplotCurves curves with non zero maxCurvesValues
	int Ncurves = 0;// 1+: Cash

	/*
	vector<GoodValue>& moneyCurve = *pGenDat->pTheStateData->pCash;
	GoodValue maxMoney = *max_element(moneyCurve.begin(), moneyCurve.end());
	++Ncurves;
	*/

	auto mGoodsIhaveVal = pGenDat->pTheStateData->mGoodsIhave;
	// Find max for Y axis for each goodID
	map<GoodID, GoodValue> maxGoodValue;
	for (auto curvePair : mGoodsIhaveVal)
	{
		GoodID gID = curvePair.first;
		if (gID >= CivData::pCivData->first_producerType)
			continue;

		GoodValue maxGoodVal = *max_element(curvePair.second->begin(),
			curvePair.second->end());

		if (maxGoodVal > 0)
		{
			maxGoodValue[gID] = maxGoodVal;
			++Ncurves;
		}
		if (Ncurves >= maxNplotCurves)
			break;
	}

	SetResource("$TheStateGoodsGraph/DataGroupOne/Factor", Ncurves);
	SetResource("$TheStateGoodsGraph/DataGroupOne/DataGroup/Factor", nTimesteps);
	string title;
	title = " TheState Goods ";
	SetResource("$TheStateGoodsGraph/Title/String", title.c_str());

	// ----- Legend  -----------------------------------------------------

	int curveN = -1;
	string str0, str1;
	SetResource("$TheStateGoodsGraph/LegendObject/Legend\
Group/Legend/LegendLabel/FontSize", fontSize);

	str0 = "$TheStateGoodsGraph/DataGroupOne/DataGroup/DrawMarkers";
	SetResource(str0.c_str(), 0.);

	double WriteButton = 0.0;
	GetResource("TheStateGoodsWriteButton/OnState", &WriteButton);
	ofstream indivOutf;
	if (WriteButton)
	{
		indivOutf.open("_TheStateGoods.c");
		indivOutf << "Cash:\n";
	}

	/*
	++curveN;// Cash
	str0 = "$TheStateGoodsGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	char buffer[100];
	std::sprintf(buffer, "Cash= %.2G", (double)maxMoney);
	str1 = buffer;
	SetResource(str0.c_str(), str1.c_str());
	*/

	for (auto curvePair : maxGoodValue)
	{
		GoodID gID = curvePair.first;
		if (maxGoodValue.find(gID) == maxGoodValue.end())
			continue;

		if (WriteButton)
			indivOutf << endl << CivData::pCivData->GoodID2Name[gID] << ":\n";

		++curveN;
		str0 = "$TheStateGoodsGraph/LegendObject/LegendGroup/Legend/Text"
			+ to_string(curveN);
		char buffer[100];
		std::sprintf(buffer, "%.2G", (double)maxGoodValue[gID]);
		str1 = CivData::pCivData->GoodID2Name[gID] + "= " + buffer;
		SetResource(str0.c_str(), str1.c_str());
	}
	Update();

	//-----------------------------------------------------------------------

	double LockButton = 0.0;
	GetResource("TheStateGoodsLockButton/OnState", &LockButton);
	if (LockButton != 0.0)
		return;

	//-----------------------------------------------------------------------

	// Y axis
	SetResource("$TheStateGoodsGraph/YLow", 0.0);
	SetResource("$TheStateGoodsGraph/YHigh", 100.0);
	SetResource("$TheStateGoodsGraph/YAxisLabel/String", " (%) ");
	SetResource("$TheStateGoodsGraph/YLabelGroup/YLabel/Format", "%.0lf");
	// X axis
	SetResource("$TheStateGoodsGraph/XLow", 0.0);
	SetResource("$TheStateGoodsGraph/XHigh", nTimesteps);
	SetResource("$TheStateGoodsGraph/XLabelGroup/Factor", 10);
	SetResource("$TheStateGoodsGraph/XLabelGroup/MinorFactor", 0.);

	curveN = -1;

	string strX = "$TheStateGoodsGraph/DataGroupOne/DataGroup/Polygon/LineWidth";
	SetResource(strX.c_str(), _lineWidth);

	Update();

	/*
	++curveN;// Cash
	auto& values = moneyCurve;
	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		string strX = "$TheStateGoodsGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep + 1);

		string strY = "$TheStateGoodsGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		if (maxMoney > 0)
		{
			double val = values[timestep] * 100.0 / maxMoney;
			SetResource(strY.c_str(), val);
			if (WriteButton)
				indivOutf << timestep + 1 << " " << values[timestep] << endl;
		}
	}
	*/
	for (auto curvePair : mGoodsIhaveVal)
	{
		GoodID gID = curvePair.first;
		if (maxGoodValue.find(gID) == maxGoodValue.end())
			continue;

		if (WriteButton)
			indivOutf << endl << CivData::pCivData->GoodID2Name[gID] << ":\n";

		++curveN;
		auto& values = *curvePair.second;
		for (int timestep = 0; timestep < nTimesteps; ++timestep)
		{
			if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
				&& timestep != nTimesteps - 1)
				continue;

			string strX = "$TheStateGoodsGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/XEntryPoint";
			SetResource(strX.c_str(), timestep + 1);

			string strY = "$TheStateGoodsGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/YEntryPoint";

			if (maxGoodValue[gID] > 0)
			{
				SetResource(strY.c_str(), values[timestep]
					* 100.0 / maxGoodValue[gID]);
				if (WriteButton)
					indivOutf << timestep + 1 << " " << values[timestep] << endl;
			}
		}
	}
	Update();
	if (WriteButton)
		indivOutf.close();
}


void CivInterface::plotBankValues()
{
	if (!OutputDataValid
		|| CivData::pCivData->pCurrentGenerationData->mBankData.size() == 0)
		return;

	int selectedBankID = -1;
	CGenerationData& GenDat = *CivData::pCivData->pCurrentGenerationData;
	if (GenDat.selectedBankN >= 0)
		selectedBankID = GenDat.pBanksIDs->at(GenDat.selectedBankN);

	if (selectedBankID != CivData::pCivData->currentIndividualN)
	{
		string title;
		title = "Bank of Indiv. -- ";// +to_string(CentralBankID);
		SetResource("$BankValuesGraph/Title/String", title.c_str());
		SetResource("$BankValuesGraph/DataGroupOne/Factor", 0.); // Clear Graph
		return;
	}

	int nIndividuals = CivData::pCivData->pGeneration->nIndividuals;
	int nTimesteps = CivData::pCivData->at(CivData::kYears)
		* CivData::pCivData->stepsPerYear;

	vector< vector<double>* > BankCurves;
	BankCurves.push_back(GenDat.mBankData[selectedBankID]->_pTotalBullion);
	BankCurves.push_back(GenDat.mBankData[selectedBankID]->pColectedInterests);
	BankCurves.push_back(GenDat.mBankData[selectedBankID]->pMyLoan);
	BankCurves.push_back(GenDat.mBankData[selectedBankID]->pCash);
	BankCurves.push_back(GenDat.mBankData[selectedBankID]->pTotalDeposits);
	BankCurves.push_back(GenDat.mBankData[selectedBankID]->pTotalLoans);

	std::vector<string> labels =
	{ " Reserves", " Interests", " CBLoan", " Cash", " Deposits", " Loans" };

	// Find max and min for Y axis for each curve

	vector<double> maxCurvesValues;
	vector<double> minCurvesValues;
	for (int n = 0; n < BankCurves.size(); ++n)
	{
		maxCurvesValues.push_back(*max_element(BankCurves[n]->begin(),
			BankCurves[n]->end()));
		minCurvesValues.push_back(*min_element(BankCurves[n]->begin(),
			BankCurves[n]->end()));
	}

	GoodValue maxValue = *max_element(maxCurvesValues.begin(),
		maxCurvesValues.end());
	GoodValue minValue = *min_element(minCurvesValues.begin(),
		minCurvesValues.end());

	string title;
	title = "Bank of Indiv. " + to_string(selectedBankID);
	SetResource("$BankValuesGraph/Title/String", title.c_str());

	string str0, str1;
	char buff[100];
	int Ncurves = (int)BankCurves.size();
	SetResource("$BankValuesGraph/DataGroupOne/Factor", Ncurves);// reset curves
	SetResource("$BankValuesGraph/DataGroupOne/DataGroup/Factor", nTimesteps); // N data points
	// Y axis
	double YHigh = 1.0 * maxValue;
	double YLow = minValue;
	SetResource("$BankValuesGraph/YLow", YLow);
	SetResource("$BankValuesGraph/YHigh", YHigh);
	SetResource("$BankValuesGraph/YLabelGroup/Factor", 10);
	SetResource("$BankValuesGraph/YAxisLabel/String", " M.U. ");
	SetResource("$BankValuesGraph/YLabelGroup/YLabel/Format", "%.1E");
	// X axis
	SetResource("$BankValuesGraph/XLow", 0.0);
	SetResource("$BankValuesGraph/XHigh", nTimesteps);
	SetResource("$BankValuesGraph/XLabelGroup/Factor", 10);
	SetResource("$BankValuesGraph/XLabelGroup/MinorFactor", 0.);
	SetResource("$BankValuesGraph/DataGroupOne/DataGroup/DrawLines", 1.);
	SetResource("$BankValuesGraph/DataGroupOne/DataGroup/DrawMarkers", 0.);

	SetResource("$BankValuesGraph/LegendObject/LegendGroup/Legend/LegendLabel/FontSize",
		fontSize);
	string strX = "$BankValuesGraph/DataGroupOne/DataGroup/Polygon/LineWidth";
	SetResource(strX.c_str(), _lineWidth);
	Update();
	int curveN = -1;
	for (int curveN = 0; curveN < Ncurves; ++curveN)
	{
		str0 = "$BankValuesGraph/LegendObject/LegendGroup/Legend/Text"
			+ to_string(curveN);
		strX = labels.at(curveN);// +"= %-.1E";
		std::sprintf(buff, strX.c_str(), maxCurvesValues[curveN]);

		SetResource(str0.c_str(), buff);
	}
	Update();

	double LockButton = 0.0;
	GetResource("BankValuesLockButton/OnState", &LockButton);
	if (LockButton != 0.0)
		return;

	curveN = -1;
	for (int curveN = 0; curveN < Ncurves; ++curveN)
	{
		if (curveN == 0)
		{
			string str = "$BankValuesGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/DrawMarkers";
			SetResource(str.c_str(), 1.);
		}
		Update();
		for (int timestep = 0; timestep < nTimesteps; ++timestep)
		{
			if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
				&& timestep != nTimesteps - 1)
				continue;

			string strX = "$BankValuesGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/XEntryPoint";
			SetResource(strX.c_str(), timestep + 1);

			string strY = "$BankValuesGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/YEntryPoint";

			SetResource(strY.c_str(), (*BankCurves[curveN])[timestep]);
		}
		Update();
	}
}

void CivInterface::plotProducerValues()
{
	if (!OutputDataValid)
		return;

	int nTimesteps = CivData::pCivData->at(CivData::kYears)
		* CivData::pCivData->stepsPerYear;
	int indivN = CivData::pCivData->currentIndividualN;

	CGenerationData* pGenDat = CivData::pCivData->pCurrentGenerationData;
	CIndividualData* pIndivDat = pGenDat->pIndivData->at(indivN);
	CProducerData* pProdDat = pGenDat->pProducerData->at(indivN);

	// -----  Producer ID curves  ----------------------------------

	map< GoodID, TimeValueCurve* > mProducerIDcurves;
	for (auto gPair : pIndivDat->mGoodsIhave)
	{
		GoodID producerID = gPair.first;

		if (producerID < CivData::pCivData->first_producerType)
			continue;
		else
		{
			bool hasWorked = false;
			for (int timestep = 0; timestep < nTimesteps; ++timestep)
			{
				if ((gPair.second->at(timestep) *
					pProdDat->_HasWorkedCurrentMonth->at(timestep)) != 0)
				{
					hasWorked = true;
					break;
				}
			}

			if (hasWorked)
				mProducerIDcurves[producerID] = gPair.second;
		}
	}

	int Ncurves = (int)mProducerIDcurves.size();

	vector<double>* pProdTotVal = pProdDat->pTotalValue;
	double maxProdTotVal = 1 + *max_element(pProdTotVal->begin(), pProdTotVal->end());
	double minProdTotVal = 1 + *min_element(pProdTotVal->begin(), pProdTotVal->end());
	Ncurves++;

	vector<double>* pProdImmobVal = pProdDat->pImmobGoodsValue;
	double maxProdImmobVal = *max_element(pProdImmobVal->begin(),
		pProdImmobVal->end());
	double minProdImmobVal = *min_element(pProdImmobVal->begin(),
		pProdImmobVal->end());
	Ncurves++;

	vector<GoodValue>* pProdCash = pProdDat->pCash;
	double maxProdCash = *max_element(pProdCash->begin(), pProdCash->end());
	double minProdCash = *min_element(pProdCash->begin(), pProdCash->end());
	Ncurves++;

	vector<GoodValue>* pProdLoan = pProdDat->pLoan;
	double maxProdLoan = -*min_element(pProdLoan->begin(), pProdLoan->end());
	double minProdLoan = -*max_element(pProdLoan->begin(), pProdLoan->end());
	Ncurves++;

	double YHigh = 1.0 * max<double>({ maxProdTotVal, maxProdImmobVal,
		maxProdCash, maxProdLoan });
	double YLow = 1.0 * min<double>({ 0, minProdTotVal, minProdImmobVal,
		minProdCash, minProdLoan });

	//--------------------------------------------------------

	string title;
	title = "Producer Values Indiv. " + to_string(indivN);
	SetResource("$ProducerValuesGraph/Title/String", title.c_str());

	SetResource("$ProducerValuesGraph/DataGroupOne/Factor", Ncurves);
	SetResource("$ProducerValuesGraph/DataGroupOne/DataGroup/Factor",
		nTimesteps);//points

	string str0, str1;
	string strX, strY;
	char buffer[100];

	//-----  Legend  ------------------------------------------
	SetResource("$ProducerValuesGraph/LegendObject/LegendGroup/Factor", Ncurves);
	SetResource(
		"$ProducerValuesGraph/LegendObject/LegendGroup/Legend/LegendLabel/FontSize",
		fontSize);
	Update();

	int curveN = -1;
	TimeValueCurve* pCurve = nullptr;

	curveN = -1;
	for (auto nn : mProducerIDcurves)
	{
		++curveN;

		str0 = "$ProducerValuesGraph/LegendObject/LegendGroup/Legend/Text"
			+ to_string(curveN);
		std::sprintf(buffer, " %s",
			CivData::pCivData->GoodID2Name[nn.first].c_str());
		str1 = buffer;
		SetResource(str0.c_str(), str1.c_str());
	}

	++curveN;
	str0 = "$ProducerValuesGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	SetResource(str0.c_str(), " Total");

	++curveN;
	str0 = "$ProducerValuesGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	SetResource(str0.c_str(), " Immob");

	++curveN;
	str0 = "$ProducerValuesGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	SetResource(str0.c_str(), " Cash");

	++curveN;
	str0 = "$ProducerValuesGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	SetResource(str0.c_str(), " Savings");
	Update();

	//--------------------------------------------------------

	double LockButton = 0.0;
	GetResource("ProducerValuesLockButton/OnState", &LockButton);
	if (LockButton != 0.0)
		return;

	//------  Plot curves  -----------------------------

	// Y axis
	SetResource("$ProducerValuesGraph/YLow", YLow);
	SetResource("$ProducerValuesGraph/YHigh", YHigh);
	//SetResource("$ProducerValuesGraph/YAxisLabel/String", " (%) ");
	SetResource("$ProducerValuesGraph/YLabelGroup/Factor", 10);
	SetResource("$ProducerValuesGraph/YLabelGroup/YLabel/Format", "%.1E");
	// X axis
	SetResource("$ProducerValuesGraph/XLow", 0.0);
	SetResource("$ProducerValuesGraph/XHigh", nTimesteps);
	SetResource("$ProducerValuesGraph/XLabelGroup/Factor", 10);
	SetResource("$ProducerValuesGraph/XLabelGroup/MinorFactor", 0.);

	double SymbButton = 0.0;
	GetResource("ProducerValuesSymbButton/OnState", &SymbButton);

	double WriteButton = 0.0;
	GetResource("ProducerValuesWriteButton/OnState", &WriteButton);
	ofstream indivOutf;
	if (WriteButton)
	{
		indivOutf.open("_ProducersOfIndiv" + to_string(indivN) + "_Values.c");
	}

	curveN = -1;
	pCurve = nullptr;
	for (auto nn : mProducerIDcurves)
	{
		++curveN;
		strX = "$ProducerValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/Polygon/LineWidth";
		SetResource(strX.c_str(), _lineWidth);

		strX = "$ProducerValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/DrawMarkers";// select curve
		SetResource(strX.c_str(), SymbButton);
		Update();

		if (WriteButton)
			indivOutf << endl << CivData::pCivData->GoodID2Name[nn.first] << ":\n";

		// Producer ID curves

		pCurve = nn.second;
		for (int timestep = 0; timestep < nTimesteps; ++timestep)
		{
			if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
				&& timestep != nTimesteps - 1)
				continue;

			if (pCurve->at(timestep) <= 0)
				continue;// don't plot 0's

			strX = "$ProducerValuesGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/XEntryPoint";
			SetResource(strX.c_str(), timestep + 1);

			strY = "$ProducerValuesGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/YEntryPoint";

			double val = YLow +
				(YHigh - YLow) * (0.80 + 0.03 + (pCurve->at(timestep)
					* 0.07 * pProdDat->_HasWorkedCurrentMonth->at(timestep)));
			SetResource(strY.c_str(), val);
			if (WriteButton)
				indivOutf << timestep + 1 << " " << val << endl;
		}
		Update();
	}

	++curveN;
	strX = "$ProducerValuesGraph/DataGroupOne/DataGroup"
		+ to_string(curveN) + "/Polygon/LineWidth";
	SetResource(strX.c_str(), _lineWidth);

	strX = "$ProducerValuesGraph/DataGroupOne/DataGroup"
		+ to_string(curveN) + "/DrawMarkers";
	SetResource(strX.c_str(), SymbButton);
	Update();

	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		strX = "$ProducerValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep + 1);

		strY = "$ProducerValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		SetResource(strY.c_str(), (*pProdTotVal)[timestep]);
	}
	Update();

	++curveN;
	strX = "$ProducerValuesGraph/DataGroupOne/DataGroup"
		+ to_string(curveN) + "/Polygon/LineWidth";
	SetResource(strX.c_str(), _lineWidth);

	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		strX = "$ProducerValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep + 1);

		strY = "$ProducerValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		SetResource(strY.c_str(), (*pProdImmobVal)[timestep]);
	}
	Update();

	++curveN;
	strX = "$ProducerValuesGraph/DataGroupOne/DataGroup"
		+ to_string(curveN) + "/Polygon/LineWidth";
	SetResource(strX.c_str(), _lineWidth);

	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		strX = "$ProducerValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep + 1);

		strY = "$ProducerValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		SetResource(strY.c_str(), (*pProdCash)[timestep]);
	}
	Update();

	++curveN;
	strX = "$ProducerValuesGraph/DataGroupOne/DataGroup"
		+ to_string(curveN) + "/Polygon/LineWidth";
	SetResource(strX.c_str(), _lineWidth);

	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		strX = "$ProducerValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep + 1);

		strY = "$ProducerValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		SetResource(strY.c_str(), -(*pProdLoan)[timestep]);
	}

	Update();
	if (WriteButton)
		indivOutf.close();
}

void CivInterface::plotIndividualValues()
{
	if (!OutputDataValid)
		return;

	int nTimesteps = CivData::pCivData->at(CivData::kYears)
		* CivData::pCivData->stepsPerYear;
	int indivN = CivData::pCivData->currentIndividualN;

	CGenerationData* pGenDat = CivData::pCivData->pCurrentGenerationData;
	CIndividualData* pIndivDat = pGenDat->pIndivData->at(indivN);

	int Ncurves = 0;

	vector<int>* pIndivHasWorked = pIndivDat->_HasWorkedCurrentMonth;
	Ncurves++;

	vector<double>* pIndivTotVal = pIndivDat->pTotalValue;
	double maxIndivTot = *max_element(pIndivTotVal->begin(), pIndivTotVal->end());
	double minIndivTot = *min_element(pIndivTotVal->begin(), pIndivTotVal->end());
	Ncurves++;

	vector<GoodValue>* pIndivCash = pIndivDat->pCash;
	double maxIndivMoney = *max_element(pIndivCash->begin(), pIndivCash->end());
	double minIndivMoney = *min_element(pIndivCash->begin(), pIndivCash->end());
	Ncurves++;

	vector<GoodValue>* pIndivLoan = pIndivDat->pLoan;// plotted as Savings = -pLoan
	double maxIndivLoan = -*min_element(pIndivLoan->begin(), pIndivLoan->end());
	double minIndivLoan = -*max_element(pIndivLoan->begin(), pIndivLoan->end());
	Ncurves++;

	double YHigh = 1.0 * max<double>({ maxIndivTot, maxIndivMoney,maxIndivLoan });
	double YLow = 1.0 * min<double>({ 0, minIndivTot, minIndivMoney, minIndivLoan });

	//--------------------------------------------------------

	string title;
	title = "Individual Values Indiv. " + to_string(indivN);
	SetResource("$IndividualValuesGraph/Title/String", title.c_str());

	SetResource("$IndividualValuesGraph/DataGroupOne/Factor", Ncurves);
	SetResource("$IndividualValuesGraph/DataGroupOne/DataGroup/Factor",
		nTimesteps);
	Update();

	string str0, str1;
	string strX, strY;

	//-----  Legend  ------------------------------------------

	SetResource(
		"$IndividualValuesGraph/LegendObject/LegendGroup/Legend/LegendLabel/FontSize",
		fontSize);

	int curveN = 0;
	str0 = "$IndividualValuesGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	SetResource(str0.c_str(), " Working");

	++curveN;
	str0 = "$IndividualValuesGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	SetResource(str0.c_str(), " Total");

	++curveN;
	str0 = "$IndividualValuesGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	SetResource(str0.c_str(), " Cash");

	++curveN;
	str0 = "$IndividualValuesGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	SetResource(str0.c_str(), " Savings");

	Update();

	//--------------------------------------------------------

	double LockButton = 0.0;
	GetResource("IndividualValuesLockButton/OnState", &LockButton);
	if (LockButton != 0.0)
		return;

	//------  Plot curves  -----------------------------

	// Y axis
	SetResource("$IndividualValuesGraph/YLow", YLow);
	SetResource("$IndividualValuesGraph/YHigh", YHigh);// 110.0);
	//SetResource("$IndividualValuesGraph/YAxisLabel/String", " (%) ");
	SetResource("$IndividualValuesGraph/YLabelGroup/YLabel/Format", "%.1E");
	// X axis
	SetResource("$IndividualValuesGraph/XLow", 0.0);
	SetResource("$IndividualValuesGraph/XHigh", nTimesteps);
	SetResource("$IndividualValuesGraph/XLabelGroup/Factor", 10);
	SetResource("$IndividualValuesGraph/XLabelGroup/MinorFactor", 0.);

	double SymbButton = 0.0;
	GetResource("IndividualValuesSymbButton/OnState", &SymbButton);


	strX = "$IndividualValuesGraph/DataGroupOne/DataGroup"
		+ to_string(curveN) + "/LineWidth";
	SetResource(strX.c_str(), _lineWidth);

	curveN = 0; // IndivHasWorked
	strX = "$IndividualValuesGraph/DataGroupOne/DataGroup"
		+ to_string(curveN) + "/DrawMarkers";
	SetResource(strX.c_str(), SymbButton);
	Update();
	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		strX = "$IndividualValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep);

		strY = "$IndividualValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		SetResource(strY.c_str(), (YLow + (YHigh - YLow) *
			(0.8 + 0.03 + 0.07 * pIndivDat->_HasWorkedCurrentMonth->at(timestep))));
	}

	++curveN; // IndivTotal
	strX = "$IndividualValuesGraph/DataGroupOne/DataGroup"
		+ to_string(curveN) + "/DrawMarkers";
	SetResource(strX.c_str(), SymbButton);
	Update();
	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		strX = "$IndividualValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep);

		strY = "$IndividualValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		SetResource(strY.c_str(), (*pIndivTotVal)[timestep]
		);
	}
	Update();

	++curveN; // Cash
	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		strX = "$IndividualValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep);

		strY = "$IndividualValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		SetResource(strY.c_str(), (*pIndivCash)[timestep]);
	}
	Update();

	++curveN; // Savings
	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		strX = "$IndividualValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep);

		strY = "$IndividualValuesGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		SetResource(strY.c_str(), -(*pIndivLoan)[timestep]);
	}
	Update();
}

void CivInterface::plotIndivHomeGoods()
{
	if (!OutputDataValid)
		return;

	int nTimesteps = CivData::pCivData->at(CivData::kYears)
		* CivData::pCivData->stepsPerYear;

	CGenerationData* pGenDat = CivData::pCivData->pCurrentGenerationData;

	int maxNplotCurves = CivData::pCivData->at(CivData::kMaxNplotCurves);
	// plot up to maxNplotCurves curves with non zero maxCurvesValues
	int Ncurves = 0;// 1+: Cash
	int indivN = CivData::pCivData->currentIndividualN;

	vector<GoodValue>& moneyCurve = *pGenDat->pIndivData->
		at(indivN)->pCash;
	GoodValue maxMoney = *max_element(moneyCurve.begin(), moneyCurve.end());
	++Ncurves;

	auto mGoodsIhaveVal = pGenDat->pIndivData->at(indivN)->mGoodsIhave;
	// Find max for Y axis for each goodID
	map<GoodID, GoodValue> maxGoodValue;
	for (auto curvePair : mGoodsIhaveVal)
	{
		GoodID gID = curvePair.first;
		if (gID >= CivData::pCivData->first_producerType)
			continue;

		GoodValue maxGoodVal = *max_element(curvePair.second->begin(),
			curvePair.second->end());

		if (maxGoodVal > 0)
		{
			maxGoodValue[gID] = maxGoodVal;
			++Ncurves;
		}
		if (Ncurves >= maxNplotCurves)
			break;
	}

	SetResource("$IndividualGoodsGraph/DataGroupOne/Factor", Ncurves);
	SetResource("$IndividualGoodsGraph/DataGroupOne/DataGroup/Factor", nTimesteps);
	string title;
	title = "Home Goods of Indiv. " + to_string(indivN);
	SetResource("$IndividualGoodsGraph/Title/String", title.c_str());

	// ----- Legend  -----------------------------------------------------

	int curveN = -1;
	string str0, str1;
	SetResource("$IndividualGoodsGraph/LegendObject/Legend\
Group/Legend/LegendLabel/FontSize", fontSize);

	++curveN;// Cash
	str0 = "$IndividualGoodsGraph/LegendObject/LegendGroup/Legend/Text"
		+ to_string(curveN);
	char buffer[100];
	std::sprintf(buffer, "Cash= %.2G", (double)maxMoney);
	str1 = buffer;
	SetResource(str0.c_str(), str1.c_str());

	for (auto curvePair : maxGoodValue)
	{
		GoodID gID = curvePair.first;
		if (maxGoodValue.find(gID) == maxGoodValue.end())
			continue;

		++curveN;
		str0 = "$IndividualGoodsGraph/LegendObject/LegendGroup/Legend/Text"
			+ to_string(curveN);
		char buffer[100];
		std::sprintf(buffer, " %.2G ", (double)maxGoodValue[gID]);
		str1 = buffer + CivData::pCivData->GoodID2Name[gID];
		SetResource(str0.c_str(), str1.c_str());
	}
	Update();

	//-----------------------------------------------------------------------

	double LockButton = 0.0;
	GetResource("IndividualGoodsLockButton/OnState", &LockButton);
	if (LockButton != 0.0)
		return;

	//-----------------------------------------------------------------------

	// Y axis
	SetResource("$IndividualGoodsGraph/YLow", 0.0);
	SetResource("$IndividualGoodsGraph/YHigh", 100.0);
	SetResource("$IndividualGoodsGraph/YAxisLabel/String", " (%) ");
	SetResource("$IndividualGoodsGraph/YLabelGroup/YLabel/Format", "%.0lf");
	// X axis

	SetResource("$IndividualGoodsGraph/XAxisLabel/String", "Month");
	SetResource("$IndividualGoodsGraph/XLow", 0.0);
	SetResource("$IndividualGoodsGraph/XHigh", nTimesteps);
	SetResource("$IndividualGoodsGraph/XLabelGroup/Factor", 10);
	SetResource("$IndividualGoodsGraph/XLabelGroup/MinorFactor", 0.);

	curveN = -1;

	string strX = "$IndividualGoodsGraph/DataGroupOne/DataGroup/Polygon/LineWidth";
	SetResource(strX.c_str(), _lineWidth);

	Update();

	double WriteButton = 0.0;
	GetResource("IndividualGoodsWriteButton/OnState", &WriteButton);

	ofstream indivOutf;
	if (WriteButton)
	{
		indivOutf.open("_Indiv" + to_string(indivN) + "_Goods.c");
		indivOutf << "Cash:\n";
	}


	++curveN;// Cash
	auto& values = moneyCurve;
	for (int timestep = 0; timestep < nTimesteps; ++timestep)
	{
		if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
			&& timestep != nTimesteps - 1)
			continue;

		string strX = "$IndividualGoodsGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/XEntryPoint";
		SetResource(strX.c_str(), timestep + 1);

		string strY = "$IndividualGoodsGraph/DataGroupOne/DataGroup"
			+ to_string(curveN) + "/YEntryPoint";

		if (maxMoney > 0)
		{
			double val = values[timestep] * 100.0 / maxMoney;
			SetResource(strY.c_str(), val);
			if (WriteButton)
				indivOutf << timestep + 1 << " " << values[timestep] << endl;
		}
	}

	for (auto curvePair : mGoodsIhaveVal)
	{
		GoodID gID = curvePair.first;
		if (maxGoodValue.find(gID) == maxGoodValue.end())
			continue;

		if (WriteButton)
			indivOutf << endl << CivData::pCivData->GoodID2Name[gID] << ":\n";

		++curveN;
		auto& values = *curvePair.second;
		for (int timestep = 0; timestep < nTimesteps; ++timestep)
		{
			if (timestep % CivData::pCivData->at(CivData::kPlotEveryNsteps) != 0
				&& timestep != nTimesteps - 1)
				continue;

			string strX = "$IndividualGoodsGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/XEntryPoint";
			SetResource(strX.c_str(), timestep + 1);

			string strY = "$IndividualGoodsGraph/DataGroupOne/DataGroup"
				+ to_string(curveN) + "/YEntryPoint";

			if (maxGoodValue[gID] > 0)
			{
				SetResource(strY.c_str(), values[timestep]
					* 100.0 / maxGoodValue[gID]);
				if (WriteButton)
					indivOutf << timestep + 1 << " " << values[timestep] << endl;
			}
		}
	}
	Update();
	if (WriteButton)
		indivOutf.close();
}

void CivInterface::plotCurrentIndividual()
{
	if (!OutputDataValid)
		return;

	SetResource("SpinnerSelectIndividual/Value",
		CivData::pCivData->currentIndividualN);
	Update();

	int bankN;
	auto pBanksIDs = CivData::pCivData->pCurrentGenerationData->pBanksIDs;
	for (bankN = 0; bankN < pBanksIDs->size(); ++bankN)
	{
		if (pBanksIDs->at(bankN) == CivData::pCivData->currentIndividualN)
		{
			break;
		}
	}

	if (bankN < pBanksIDs->size()) // has a Bank
	{
		CivData::pCivData->pCurrentGenerationData->selectedBankN = bankN;

		plotBanksFinalTotalValues();
	}
	else // doesn't have a Bank, deselect previous if selectedBankN >= 0
	{
		if (CivData::pCivData->pCurrentGenerationData->selectedBankN >= 0)
		{
			CivData::pCivData->pCurrentGenerationData->selectedBankN = -1;
			plotBanksFinalTotalValues();
		}
		CivData::pCivData->pCurrentGenerationData->selectedBankN = -1;
	}

	plotBankValues();
	plotProducerValues();
	plotIndividualValues();
	plotIndivHomeGoods();
}


CivInterface::CivInterface()
	: OutputDataValid(false), pCivilization(0)
{
	_lineWidth = 3;
}

CivInterface::~CivInterface(void)
{
}

void CivInterface::SetSize(GlgLong x, GlgLong y, GlgLong width, GlgLong height)
{ // Set viewport size in screen coordinates. 
	SetResource("Point1", 0., 0., 0.);
	SetResource("Point2", 0., 0., 0.);

	SetResource("Screen/XHint", (double)x);
	SetResource("Screen/YHint", (double)y);
	SetResource("Screen/WidthHint", (double)width);
	SetResource("Screen/HeightHint", (double)height);
}
