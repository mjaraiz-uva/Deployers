// RandomGenerator.h: interface for the RandomGenerator class.
//

#if !defined(_RANDOMGENERATOR_H_)
#define _RANDOMGENERATOR_H_

#include "Vector3D.h"

class RandomGenerator  
{
public:
   RandomGenerator(unsigned int seed1=4455, unsigned int seed2=5566);
   void ChangeSeed(unsigned int seed1, unsigned int seed2);
   float Rand();
   unsigned int RandInt(int);
   ExtVector RandVector();
private:
   double u[98];
   double c, cd, cm;
   unsigned int i97, j97;
   const double sqrt1_2;
};

#endif // !defined(_RANDOMGENERATOR_H_)
