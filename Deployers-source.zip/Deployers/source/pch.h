
//   pch.h

// "Deployers: 
//  The Spontaneous Rise and Development of Economic Systems"


// pch.h

// "Deployers: 
//  The Spontaneous Rise and Deployment of Economic Systems"
/*
Ludwig von Mises: "For the purpose of [human] science we must start
from the action of the individual because this is the only thing of
which we can have direct cognition. The idea of a society that could
operate or manifest itself apart from the action of individuals is
absurd. Everything social must in some way be recognizable in the
action of the individual.... Every form of society is operative in
the actions of individuals aiming at definite ends...."
*/


#ifndef PCH_H
#define PCH_H

#include <cassert>
#include <iostream>
#include <array>
#include <set>
#include <map>
#include <string>
#include <vector>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <random>

#include <stdio.h>
#include <math.h>

#include "ga.h"
#include "GAArray.h"
#include "GAAllele.h"
#include "GARealGenome.h"

using namespace std;

// Example of printout to output file:
// (*CivData::pCivData->pOutf) << "home_n = 1" << endl;

class CivInterface;
class CBankEntry;
class CBank;
class CTrader;
class CProductData;
class CProducer;
class CIndividual;
class CGeneration;
class CTheState;
class CCentralBank;

enum class MarketOperation { buy, sell };

//========= Good types: see CivData::readInputFile ==========

typedef int GoodID;
typedef long long int GoodValue;
typedef pair<GoodID, GoodValue> GoodPair;
typedef pair<double, GoodID> GoodValuePair;// max(,) uses .first 

const GoodID TheStateID = -1;
const GoodID CentralBankID = -2;

// Trader types
const GoodID Individual = 0;
const GoodID Producer = 1;
const GoodID Bank = 2;
const GoodID TheState = 3;
const GoodID CentralBank = 4;

const GoodID workers_n = 0;
const GoodID food_kg = 1;

//====================  CGood  ================================================

class CGood
{
public:
	GoodID _ID;
	string _name;
	GoodValue _quantity;

	CGood(GoodID gID, GoodValue q);
	CGood(string nam, GoodValue q);
	CGood(const CGood& cg);

	const GoodValue quantity() const;

	CGood& operator=(const CGood& g);
	CGood& operator+=(const CGood& g);
	CGood& operator-=(const CGood& g);

	CGood& operator+(const CGood& g) const;
	CGood& operator-(const CGood& g) const;

	bool operator==(const CGood& g) const;
	bool operator!=(const CGood& g) const;
	bool operator>(const CGood& g) const;
	bool operator<(const CGood& g) const;
	bool operator>=(const CGood& g) const;
	bool operator<=(const CGood& g) const;

	CGood& operator=(GoodValue d);
	CGood& operator+=(GoodValue d);
	CGood& operator-=(GoodValue d);
	CGood& operator*=(double d);
	CGood& operator/=(double d);

	CGood& operator*(double d) const;
	CGood& operator/(double d) const;
	CGood& operator+(GoodValue d) const;
	CGood& operator-(GoodValue d) const;

	bool operator==(GoodValue d) const;
	bool operator!=(GoodValue d) const;
	bool operator>(GoodValue d) const;
	bool operator<(GoodValue d) const;
	bool operator>=(GoodValue d) const;
	bool operator<=(GoodValue d) const;
};

class CGoods : public map< GoodID, CGood >
{

public:
	CGoods();
	~CGoods();
	CGood& operator[](GoodID gID);
	GoodValue operator()(GoodID gID);
	CGoods& operator=(const CGoods& cgds);
	CGoods& operator+(const CGoods& cgds) const;
	CGoods& operator+=(const CGoods& cgds);
	CGoods& operator+=(const CGood& cgd);
	CGoods& operator-(const CGoods& cgds) const;
	CGoods& operator-=(const CGoods& cgds);
};


//======================  CAccounting  ===================================

class CAccountEntry
{
public:
	int _month;
	GoodValue _units;
	GoodValue _money;
	GoodID gID;
	GoodID neighID;

	CAccountEntry(int step, GoodValue val, GoodID gId, GoodID neighborId, GoodValue qtty);
	~CAccountEntry();

	friend ofstream& operator<<(ofstream& ofstrm, const CAccountEntry& ent);
};

ofstream& operator<<(ofstream& ofstrm, const CAccountEntry& ent);


class CAccounting
{
public:
	vector<CAccountEntry> _Entries;

	CAccounting();
	~CAccounting();
};

class CBankEntry
{
public:
	CTrader* _pTrader;
	GoodValue _value;
	GoodValue _previousInterests;
	int _initStep, _endStep;
	bool _operationOK;

	CBankEntry(CTrader* pTrader, GoodValue value,
		int initStep, int endStep, bool ok);
	CBankEntry();
	~CBankEntry();

	void clear();
};


//======================  CTrader  ===================================

class CTrader
{
	GoodValue _Cash;

public:
	static vector< pair<unsigned int, CTrader*> > _InteractingTraders;
	static vector< pair<unsigned int, CTrader*> > _InteractingWorkers;

	CGeneration* const _pGeneration;

	const GoodID _traderType;
	GoodID _ID; // MaxPopulation + _ManagerID for Producers

	CTrader* _Manager; // Employer for Individuals, owner Indiv. for Producers

	map<GoodID, CProducer*> _mProducers;// GoodID: _producerType
	CBank* _pOwnedBank;

	CBank* _pUsedBank;
	CBankEntry _myBankAccountStatus;

	GoodValue _MinCash;
	GoodValue _TotalAssetsPreviousYear;

	//-----------------------------------------------------

	// Activity variables

	bool _HasWorkedCurrentMonth;

	CGoods _ListOfGoods_I_wish_to_have;// Individuals: preferences,TODO??: Producers: tobeproduced
	CGoods _Goods_I_have;

	CGoods _ListOfGoods_to_buy;
	CGoods _Goods_to_sell; // Individuals: goods from dismantled Producers

	map<GoodID, double> _myPrice;
	double _myPriceAdapt;

	CAccounting _Account;

	//-----------------------------------------------------


	CTrader(GoodID traderType, GoodID id, CGeneration* _myGenerat);
	~CTrader();

	bool IsIndividual();

	GoodValue& Cash();
	void setMyPriceOf(GoodID gID, double price);
	double myCurrentPriceOf(GoodID gID, double sellerPrice = 0);
	bool canBeEmployed();
	bool isEmployed();
	bool HasActiveProducer();

	void MakeListOfGoodsToBuy();

	GoodValue GetTotalAssets();
	void PayAnnualTax();
	void PaySellerVAT(GoodValue moneyTraded);
	void ReturnLoansToMyBank();
	void BuyGoods();
	GoodValue TradeGoodWithNeighbor(CTrader& neighbor,
		const CGood& good, MarketOperation marketOp);
	void WriteTransaction(CTrader* pFromTrader, CTrader* pToTrader,
		string concept);
	bool PayThroughBankTransfer(CTrader* pFromTrader,
		CTrader* pToTrader, GoodValue value, string concept);
	bool PayInCash(CTrader* pFromTrader, CTrader* pToTrader,
		GoodValue value, string concept);
	GoodValue GetCashFromBank(GoodValue cashNeeded);
	double AgreePriceWithNeighbor(CTrader* THIS, CTrader* neighbor,
		const CGood& good, MarketOperation marketOp);

	CProducer* getMyProducerOfProductID(GoodID productID);
	GoodValue MaxPurchaseQuantity(GoodID gID,
		double priceAgreed, CTrader& seller);
	GoodValue MaxSellQuantity(GoodID gID, GoodValue buyerQuantity = 0);

	void MakeListOfInteractingIndivsAndProducers();
	void Make_List_of_interactingWorkers();
};


//======================  CBank  ===================================

class CBank : public CTrader
{
public:
	double _liabilityRate;
	double _assetRate;
	CTrader* _pBankManager;

	GoodValue _TotalBullion;
	double _ReserveRatio;
	GoodValue _InterestsColectedFromClients;
	GoodValue _ClientsDeposits;
	GoodValue _ClientsLoans;

	// Loans to Traders (or Banks if this is the CentralBank)

	map<CTrader*, CBankEntry> _ClientsAccounts;// <TraderOrBankManager*, entry>


	CBank(GoodID traderType, // 'Bank' or 'CentralBank'
		CTrader* pBankManager);
	~CBank();

	void MonthlyActivity();

	void ColectInterests();
	void ReturnExcessCashToCB();
	GoodValue ClientCurrentBalance(CTrader* pClient);

	CBankEntry ClientCashOperation(CTrader* pClient, GoodValue deposit, int nMonths = 0);
	void AddValToAccount(CBankEntry& account, GoodValue value);
	bool GetReserveForWithdrawal(GoodValue withdraw);

	GoodValue ClientsLoansMax();

	// CentralBank only:

	int MaxNBanks;

	map<GoodID, CBank*> _Banks; // BankID, pBank

	CBank* BankFoundationRequest(CIndividual* pIndivManager, GoodValue initBullionRes);
	CBank* getRandomBank();
	bool CheckBalance();
	void TransferProfitToManager();
};

//======================  CProducer  ===================================

class CProducer : public CTrader
{
public:
	const GoodID _producerType;

	vector<CTrader*> _vEmployees;
	GoodValue _TotalRetainedWorkers;

	bool _NoFirstDemandYet;
	GoodValue _InitCapital;
	map<GoodID, GoodValue> immobilizedMinimums;
	CGoods _ImmobilizedGoods;

	map<GoodID, CProductData*> myProductsData;

	CGoods _Goods_to_be_produced;

	int _LastUsedTimestep;

	//-----------------------------------------------------

	CProducer(GoodID gId, GoodID id, CGeneration* pGenerat,
		CTrader* manager);
	CProducer(const CProducer& prototy);
	~CProducer();

	double StartupProducerPrice(CTrader* pManager) const;

	GoodValue clearVariablesOfProductID(GoodID _productID);
	double initialPriceOfProductID(GoodID _productID);

	bool IsActiveProducer();

	void MonthlyActivity();
	GoodValue TransferProfitToManager();
	void MakeListOfDemandsForMyProducts();
	void MakeListOfGoodsToBuy();

	bool TryToHireNeighbor(CTrader& neighbor);
	CTrader* ReleaseLastEmployee();
	bool ReleaseThisEmployee(CTrader& employee);

	void RunProducer();

	GoodValue Query(const GoodID productID, GoodValue& desiredProductUnits,
		const CGoods& availableInputGoods, CGoods& extraNeededInputGoods) const;

	GoodValue MinimumProductUnits(const GoodID productID) const;

	GoodValue Produce(const GoodID productID, GoodValue desiredProductUnits,
		const CGoods& availableInputGoods, CGoods& extraNeededInputGoods,
		CGoods& gDeltaRet);

	void SellMyProductsToInteractingNeighbors();
};


//====================  CivData  =====================================

typedef vector<double> TimeValueCurve;

class CProductData
{
public:

	bool active;

	const GoodID _productID;
	int availableAtStep, initMonth, delayMonths, totalWorkPerUnit;
	int lifetimeSteps;
	map<GoodID, double> nonConsumedPerUnit;
	map<GoodID, double> consumedPerUnit;
	map<GoodID, double> consumedCostFraction;

	GoodValue delayedProductQuantity;
	int productDeliveryTimestep;

	GoodValue RetainedEmployees, AccumulatedWork;

	double ProductionPrice;

	CProductData(GoodID ID);
	~CProductData();
};

class CIndividualData
{
public:
	vector<double>* pTotalValue;// [nTimesteps]
	vector<GoodValue>* pCash;// [nTimesteps]
	vector<GoodValue>* pLoan;// [nTimesteps]
	double maxTotalValue;
	double finalTotalValue;

	map<GoodID, TimeValueCurve* > mGoodsIhave;// [gID][nTimesteps]

	vector<int>* _HasWorkedCurrentMonth;// [nTimesteps]

	CIndividualData(int nMonths);
	~CIndividualData();
};

class CProducerData
{
public:
	GoodID _ID;

	vector<int>* _HasWorkedCurrentMonth;// [nTimesteps]
	vector<GoodValue>* pCash;// [nTimesteps]
	vector<GoodValue>* pLoan;// [nTimesteps]
	TimeValueCurve* pImmobGoodsValue;// [nTimesteps]
	vector<double>* pTotalValue;// [nTimesteps]
	double maxTotalValue;
	double finalTotalValue;

	CProducerData(int nMonths);
	~CProducerData();
};

class CTheStateData
{
public:
	vector<double>* pTotalValue;// [nTimesteps]
	vector<GoodValue>* pCash;// [nTimesteps]
	vector<GoodValue>* pAnnualTax;// [nTimesteps]
	vector<GoodValue>* pAnnualVAT;// [nTimesteps]
	vector<GoodValue>* pAnnUnempl;// [nTimesteps]
	vector<GoodValue>* pLoan;// [nTimesteps]
	double maxTotalValue;
	double finalTotalValue;

	map<GoodID, TimeValueCurve* > mGoodsIhave;// [gID][nTimesteps]

	vector<int>* _HasWorkedCurrentMonth;// [nTimesteps]

	CTheStateData(int nMonths);
	~CTheStateData();
};

class CBankData
{
public:
	GoodID _ID;

	vector<double>* _pTotalBullion;// [nTimesteps]
	vector<double>* pMyLoan;// [nTimesteps]
	vector<double>* pCash;// [nTimesteps]
	vector<double>* pColectedInterests;// [nTimesteps]
	vector<double>* pTotalDeposits;// [nTimesteps]
	vector<double>* pTotalLoans;// [nTimesteps]

	CBankData(int nMonths);
	~CBankData();
};

class CGenerationData
{
public:
	const int nIndividuals, nTimesteps;

	vector < vector < double > > MarketPrices;// [NGoodIDs][nTimesteps]

	CTheStateData* pTheStateData;
	CBankData* pCentralBankData;

	vector<double>* pTotalBanksCash;// [nTimesteps]
	vector<double>* pIndivsCash;// [nTimesteps]
	vector<double>* pProdsCash;// [nTimesteps]
	vector<double>* pTotalInterestsFromClients;// [nTimesteps]
	vector<double>* pUnemployment;// [nTimesteps]
	vector<double>* pAccumGDP;// [nTimesteps]

	vector< CIndividualData* >* pIndivData;// [nIndividuals]
	vector< CProducerData* >* pProducerData;// [nIndividuals]
	map< GoodID, CBankData* > mBankData;// nBanks
	GoodID selectedBankN;
	map< GoodID, GoodValue >* pBanksNetFinal;
	vector<GoodID>* pBanksIDs;

	vector< pair<double, GoodID> >* pIndividualsTotSortedVal;// [nIndividuals]
	vector< pair<double, GoodID> >* pProducersTotSortedVal;// [nIndividuals]
	vector< pair<double, GoodID> >* pIndivPlusProdPlusBankFinalSortedVal;// [nIndividuals]

	CGenerationData(int nIndiv, int nTsteps);
	~CGenerationData();
};

class CCivilizationData : public vector<CGenerationData*>
{
};

class CGoodsIwish
{
public:
	int _year, _month, _indivN;
	CGoods _Goods_I_wish;
};

class CivData : public map<string, GoodValue>
{
public:

	static CivData* pCivData;
	static CTheState* pTheState;
	static CBank* pCentralBank;

	mt19937 myRandomEngine;

	string InputFileName;
	string OutputFileName;
	ofstream* pOutf;

	CGeneration* pGeneration;
	CivInterface* pInterface;
	CCivilizationData* pCivilizationData;
	CGenerationData* pCurrentGenerationData;

	vector< CGoodsIwish > _GoodsIwish;
	vector<string> GoodID2Name;
	map< string, int > GoodName2ID;
	GoodID first_producerType;
	map< GoodID, CProducer* > ProducerPrototypes;
	map< GoodID, GoodID > ProducerType_of_this_productID;

	int currentGenerationN, currentIndividualN, currentYearN, currentMonthN,
		currentTimestep;
	int NGoodIDs;
	bool bRobotsColony;
	bool bSingleRobot;
	int stepsPerYear;

	GoodValue minSalary, maxSalary;
	double maxPriceFactor;

	// input keywords:
	static string

		kYears,
		kIndividuals,

		kGoodsDecay,
		kUseMoney,
		kFixedPrices,

		kWriteCurves,
		kWriteTransactions,
		kWriteIndivN,

		kMaxNBanks,
		kMonetaryBasePerCapita,
		kLiabilityRatePer1000,
		kAssetRatePer1000,
		kBanksInitCapital,
		kBanksRateFactor,
		kReserveRatioPer100,

		kVATPer100,
		kTaxPer100,
		kPayUnemplPer100,

		kMinFoodStockYears,

		kScoreGoodID,
		kScoreGoodQuantity,


		kPlotEveryNsteps,
		kLineWidth,
		kMaxNplotCurves,
		kMaxNplotIndividuals,

		kMaxUnusedTimestps,
		kMaxInteractingNeighbors,
		kAssignPrototypes,
		kProducerAssignmentPer1000,

		kPriceProfitPer100,
		kPriceAdaptDefaultPer100,

		kTradeProducers,
		kMutationPER1000,
		kGenerations;


	CivData(int nG = 9, int nY = 5, int nM = 12, int nI = 11);
	~CivData();

	void LoadParameters();

	CivData& readInputFile();
	void setupRobotsColony();
	void setupSingleRobot();
	//CivData& writeFile(string outfilename);
	double getRandom01();
};


//===================  Individual  ======================================

class CIndividual : public CTrader
{
public:
	const static GoodValue MonthlyFood;
	const static GoodValue MinFood;

	bool _Alive, _NoFood;

	CIndividual(CGeneration* _myGenerat, int indivID);
	~CIndividual();

	bool HasActiveProducer();

	void MonthlyActivity();
	void MonthlyFeed();

	void ProductsDecay();

	void TryToFoundCommercialBank();

	void RemoveUnusedProducers();
	void TryToStartupNewProducer();
	CProducer* StartupNewProducer(GoodID producerType);
	CProducer* TryToDismantleProducer(CProducer* pProd);
	void SellGoodsFromDismantledProducers();

	double getScore();
};

//==================  TheSTATE  ==========================

class CTheState : public CIndividual
{
public:

	// Input variables
	GoodValue BanksInitCapital;

	// Output variables
	GoodValue _AnnualTaxInfo;
	GoodValue _AnnualVATInfo;
	GoodValue _AnnUnemplInfo;

	CTheState();
	~CTheState();

	void MonthlyActivity();
	void ReturnExcessCashToCB();
	void PayUnemployment(vector<unsigned int>& randomListAliveIndivs);
	void ChargeAnnualTaxFromTrader(CTrader* pTrader);
	void ChargeVATtoTrader(CTrader* pTrader, GoodValue moneyTraded);
};

//==================  Generation  ==========================

class CGeneration
{
private:

public:
	int nIndividuals;
	vector<CIndividual*> vpIndividuals;

	GoodID MaxPopulation;
	int nYearsPerGeneration;
	int nTimesteps;
	int GenerationN, CurrentYear, CurrentMonth, CurrentTimestep;
	bool evaluated;
	int nMaxInteractingNeighbors;
	vector<double> thisTimestepTradedPrices;
	vector<int> thisTimestepNtrades;

	CGeneration();
	~CGeneration();

	GoodValue initSalary();

	void initializePopulation();
	void MonthlyUpdatePopulationStatus(vector<unsigned int>& randomListAliveIndivs);
	void runGeneration();
	bool CheckGenerationBalance();
	void ProcessIndividualDataFromCurrentMonthlyActivity();

	vector<unsigned int> getRandomListOfIndividual_IDs(int maxN);
};

//=====================  Civilization  ====================================

class CCivilization
{
public:
	CGeneration* pCurrentGeneration;
	//static ofstream outfile;

	CCivilization(CivInterface* pInterf);
	~CCivilization();
	void runCivilization();
};

//===================  Globals  ===============================

void showCurrentYearNumber();
//=========================================================

#endif //PCH_H
