
// Civilization.h

// "Evolved Civilizations: 
//  The Spontaneous Birth and Development of Economic Systems"

#pragma once
#include <stdio.h>
#include <math.h>

#include "ga.h"
#include "GAArray.h"
#include "GAAllele.h"
#include "GARealGenome.h"
#include "Generation.h"

class CivInterface;
class CCivilization
{
public:
	CGeneration currentGeneration;
	static ofstream outfile;
	CInParam* pInParam;
	CivInterface* pCivInterface;

	CCivilization(CInParam* pInPar);
	~CCivilization();
	double runCivilization();
};
