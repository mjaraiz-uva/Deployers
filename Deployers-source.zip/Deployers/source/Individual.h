// Individual.h

// "Evolved Civilizations: 
//  The Spontaneous Birth and Development of Economic Systems"

#pragma once
#include "Producers.h"
#include "Genes.h"
#include "CInParam.h"


//=========================================================

class CIndividual
{
	friend class CGeneration;

	static double UWantFactor;
	static double MarketPrice[NGoodTypes];
	static const double DailyFood;

	CGenes myGenes;
	CGoods myGoods;
	CProducers mypProducers;

public:

	CIndividual();
	~CIndividual();
	void initialize();
	void monthlyProduction();
	void tradeWith(CIndividual& neighbor, const CInParam*pInParam);
	double Want(GoodType gty);
	double EstimatedPrice(GoodType gty);
	void setGoods(CGoods g);
	const CGoods & getGoods();
	double getValue();
	double getValue(GoodType gty);
	static int PrintLevel;
};

