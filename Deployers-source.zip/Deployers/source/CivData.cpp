
//  CivData.cpp

#include "pch.h"

CivData* CivData::pCivData = nullptr;
CTheState* CivData::pTheState = nullptr;
CBank* CivData::pCentralBank = nullptr;

string
CivData::kYears = "nYears",
CivData::kIndividuals = "nIndividuals",

CivData::kGoodsDecay = "bGoodsDecay",
CivData::kUseMoney = "bUseMoney",
CivData::kFixedPrices = "bFixedPrices",

CivData::kWriteTransactions = "bWriteTransactions",
CivData::kWriteIndivN = "WriteIndivN",

CivData::kMaxNBanks = "MaxNBanks",
CivData::kMonetaryBasePerCapita = "MonetaryBasePerCapita",
CivData::kLiabilityRatePer1000 = "LiabilityRatePer1000",
CivData::kAssetRatePer1000 = "AssetRatePer1000",
CivData::kBanksInitCapital = "BanksInitCapital",
CivData::kBanksRateFactor = "BanksRateFactor",
CivData::kReserveRatioPer100 = "ReserveRatioPer100",

CivData::kVATPer100 = "VATPer100",
CivData::kTaxPer100 = "TaxPer100",
CivData::kPayUnemplPer100 = "PayUnemplPer100",

CivData::kMinFoodStockYears = "MinFoodStockYears",

CivData::kScoreGoodID = "ScoreGoodID",
CivData::kScoreGoodQuantity = "ScoreGoodQuantity",

CivData::kPlotEveryNsteps = "PlotEveryNsteps",
CivData::kLineWidth = "LineWidth",
CivData::kMaxNplotCurves = "MaxNplotCurves",
CivData::kMaxNplotIndividuals = "MaxNplotIndividuals",

CivData::kMaxUnusedTimestps = "MaxUnusedTimestps",
CivData::kMaxInteractingNeighbors = "nMaxInteractingNeighbors",
CivData::kAssignPrototypes = "bAssignPrototypes",
CivData::kProducerAssignmentPer1000 = "ProducerAssignmentPer1000",

CivData::kPriceProfitPer100 = "PriceProfitPer100",
CivData::kPriceAdaptDefaultPer100 = "PriceAdaptDefaultPer100",

CivData::kWriteCurves = "bWriteCurves",
CivData::kTradeProducers = "TradeProducers",
CivData::kMutationPER1000 = "MutationPER1000",
CivData::kGenerations = "nGenerations";


CivData::CivData(int nGe, int nYe, int nStp, int nIn)
	: pCivilizationData(0)
{
	InputFileName = "DeployersInput.txt";
	OutputFileName = "_DeployersOutput.txt";

	currentGenerationN = 0;
	currentIndividualN = 0;
	currentYearN = 0;
	currentMonthN = 0;
	currentTimestep = 0;
	pInterface = 0;

	bSingleRobot = false;
	stepsPerYear = 12;

	minSalary = 500;
	maxSalary = 5000;
	maxPriceFactor = 4;

	(*this)[kYears] = 40;
	(*this)[kIndividuals] = 500;

	(*this)[kGoodsDecay] = 1;
	(*this)[kUseMoney] = 1;
	(*this)[kFixedPrices] = 0;

	(*this)[kMaxNBanks] = 10;
	(*this)[kMonetaryBasePerCapita] = 500000;
	(*this)[kBanksInitCapital] = 100000;
	(*this)[kLiabilityRatePer1000] = 1;
	(*this)[kAssetRatePer1000] = 3;
	(*this)[kBanksRateFactor] = 5;
	(*this)[kReserveRatioPer100] = 100;

	(*this)[kScoreGoodID] = -3;
	(*this)[kScoreGoodQuantity] = 1;

	(*this)[kVATPer100] = 15;
	(*this)[kTaxPer100] = 1;
	(*this)[kPayUnemplPer100] = 10;

	(*this)[kWriteCurves] = 0;
	(*this)[kWriteTransactions] = 1;
	(*this)[kWriteIndivN] = 0;

	(*this)[kPlotEveryNsteps] = 2;
	(*this)[kLineWidth] = 3;
	(*this)[kMaxNplotCurves] = 7;
	(*this)[kMaxNplotIndividuals] = 200;

	(*this)[kMinFoodStockYears] = 4;

	(*this)[kMaxUnusedTimestps] = 48;
	(*this)[kMaxInteractingNeighbors] = 40;
	(*this)[kAssignPrototypes] = 0;
	(*this)[kProducerAssignmentPer1000] = 1000;

	(*this)[kPriceProfitPer100] = 120;
	(*this)[kPriceAdaptDefaultPer100] = 120;

	(*this)[kTradeProducers] = 1;
	(*this)[kMutationPER1000] = 10;
	(*this)[kGenerations] = 1;

	pOutf = new ofstream;

	NGoodIDs = 0;
	first_producerType = -99;

	pGeneration = nullptr;
	pCurrentGenerationData = nullptr;
}

CivData::~CivData()
{
	delete pCurrentGenerationData;
	delete pOutf;
	delete pCivilizationData;
}


void CivData::LoadParameters()
{
	CivData::pCivData->readInputFile();
}

CivData& CivData::readInputFile() {
	ifstream infile;
	infile.open(InputFileName);
	if (infile.fail())
		return (*this);
	ofstream& Outf = *pOutf;
	Outf.close();
	Outf.open(OutputFileName);

	string name, equals, units, word, taskname;
	double value;
	bRobotsColony = false;
	bSingleRobot = false;
	stepsPerYear = 12;
	first_producerType = 0;
	ProducerPrototypes.clear();
	string task_I_wish;
	CProductData* pProduct = nullptr;
	GoodID _productID = -1;
	// Read Control variables, list of Goods and definition of Producers
	while (!infile.eof())
	{
		infile >> name;
		if (name == "CONTROL_VARIABLES")
		{
			infile >> name;// "{"
			while (infile >> name, name != "}")
			{
				value = atof(name.c_str());
				infile >> name;

				if (name == "bRobotsColony")
				{
					bRobotsColony = (int)value;
				}
				else if (name == "bSingleRobot")
				{
					bSingleRobot = (int)value;
				}
				else if (name == "maxSteps")
				{
					stepsPerYear = 1;
					name = "nYears";
					at(name) = value;
				}
				else
					at(name) = value;
			}
		}
		else if (name == "GOODS")
		{
			infile >> name; // "{"
			GoodID2Name.clear();
			GoodName2ID.clear();
			NGoodIDs = 0;

			name = "workers_n";
			GoodID2Name.push_back(name);
			GoodName2ID[name] = NGoodIDs++;
			name = "food_kg";
			GoodID2Name.push_back(name);
			GoodName2ID[name] = NGoodIDs++;

			while (infile >> name, name != "}")
			{
				GoodID2Name.push_back(name);
				GoodName2ID[name] = NGoodIDs++;
				assert(NGoodIDs == (int)GoodID2Name.size());
			}
		}
		else if (name == "GOODS_I_WISH")
		{
			_GoodsIwish.clear();
			CGoodsIwish gIwish;
			infile >> name; // "{"
			while (infile >> name, name != "}")
			{
				if (name == "year")
				{
					infile >> equals >> gIwish._year;
					infile >> name >> equals >> gIwish._month;
					infile >> name >> equals >> gIwish._indivN;
					infile >> name; // "{"
					while (infile >> name, name != "}")
					{
						infile >> equals >> value;
						gIwish._Goods_I_wish[GoodName2ID[name]] = value;
					}
					_GoodsIwish.push_back(gIwish);
				}
			}
		}
		else if (name == "PRODUCERS")
		{
			infile >> name; // "{"
			while (infile >> name, name != "}")
			{
				infile >> word;// word:"{"
				Outf << name << ", "; Outf.flush();
				if (GoodName2ID.find(name) != GoodName2ID.end())
				{
					Outf << "Error in input file: Producer name " << name
						<< " already used in GOODS" << endl;
					assert(false);
					std::exit(0);
				}

				GoodID2Name.push_back(name); // Performer name
				GoodID _producerType = NGoodIDs;
				GoodName2ID[name] = _producerType;
				if (first_producerType == 0)
					first_producerType = _producerType;

				NGoodIDs++;
				CProducer* pProducer =
					new CProducer(_producerType, -1, pCivData->pGeneration, nullptr);

				while (infile >> word, word != "}")
				{
					if (word == "immobilizedMinimums")
					{
						infile >> word; // word:"{"
						while (infile >> name, name != "}")
						{
							if (GoodName2ID.find(name) == GoodName2ID.end())
							{
								Outf << "Error in input file: " << name
									<< "    is not listed in GOODS" << endl;
								assert(false);
								std::exit(0);
							}

							infile >> word >> value; // word: "="

							pProducer->immobilizedMinimums[GoodName2ID[name]] = value;
							pProducer->_ImmobilizedGoods[GoodName2ID[name]] = 0;
						}
					}
					else if (word == "products_data")
					{
						infile >> word;// word:"{"
						string productname;
						while (infile >> productname, productname != "}")
						{
							infile >> word; // word: "{"
							if (GoodName2ID.find(productname) == GoodName2ID.end())
							{
								Outf << "\nError in input file: " << productname
									<< "    is not listed in GOODS" << endl;
								assert(false);
								std::exit(0);
							}
							GoodID _productID = GoodName2ID[productname];
							CProductData* pProduct = new CProductData(_productID);
							while (infile >> word, word != "}")
							{
								if (word == "lifetimeSteps")
								{
									infile >> word >> value; // word: "="
									pProduct->lifetimeSteps = value;
								}
								else if (word == "afterStep")
								{
									infile >> word >> value; // word: "="
									pProduct->availableAtStep = value;
								}
								else if (word == "availableAtStep")
								{
									infile >> word >> value; // word: "="
									pProduct->availableAtStep = value;
								}
								else if (word == "initMonth")
								{
									infile >> word >> value; // word: "="
									pProduct->initMonth = value;
								}
								else if (word == "delayMonths")
								{
									infile >> word >> value; // word: "="
									pProduct->delayMonths = value;
								}
								else if (word == "totalWorkPerUnit")
								{
									infile >> word >> value; // word: "="
									pProduct->totalWorkPerUnit = value;
								}
								else if (word == "nonConsumedPerUnit")
								{
									infile >> word; // word:"{"
									string inputName;
									while (infile >> inputName, inputName != "}")
									{
										if (GoodName2ID.find(inputName) == GoodName2ID.end())
										{
											Outf << "Error in input file: " << inputName
												<< "    is not listed in GOODS" << endl;
											assert(false);
											std::exit(0);
										}
										GoodID inputID = GoodName2ID[inputName];
										infile >> word >> value; // word: "="
										pProduct->nonConsumedPerUnit[inputID] = value;
									}
								}
								else if (word == "ConsumedPerUnit")
								{
									infile >> word; // word:"{"
									string inputName;
									while (infile >> inputName, inputName != "}")
									{
										if (GoodName2ID.find(inputName) == GoodName2ID.end())
										{
											Outf << "Error in input file: " << inputName
												<< "    is not listed in GOODS" << endl;
											assert(false);
											std::exit(0);
										}
										GoodID inputID = GoodName2ID[inputName];
										infile >> word >> value; // word: "="
										pProduct->consumedPerUnit[inputID] = value;
									}
								}
								else if (word == "consumedCostFraction")
								{
									infile >> word; // word:"{"
									string inputName;
									while (infile >> inputName, inputName != "}")
									{
										if (GoodName2ID.find(inputName) == GoodName2ID.end())
										{
											Outf << "Error in input file: " << inputName
												<< "    is not listed in GOODS" << endl;
											assert(false);
											std::exit(0);
										}
										GoodID inputID = GoodName2ID[inputName];
										infile >> word >> value; // word: "="
										pProduct->consumedCostFraction[inputID] = value;
									}
								}
								else
								{
									Outf << "\nError in input file: " << word
										<< "    unknown/unexpected" << endl;
									assert(false);
									std::exit(0);
								}
							}
							pProducer->myProductsData[_productID] = pProduct;
						}
					}
					else
					{
						Outf << "\nError in input file: " << word
							<< "    unknown/unexpected" << endl;
						assert(false);
						std::exit(0);
					}

					ProducerPrototypes[pProducer->_producerType] = pProducer;
					// CProducer* myClone = new CProducer(*pProducer);
				}
			}
		}
		else if (name == "TASK_I_WISH")
		{
			infile >> word >> task_I_wish >> word; // "{ task_I_wish }"
		}
		else if (name == "TASKS")
		{
			infile >> name; // "{"
			GoodID2Name.clear();
			GoodName2ID.clear();
			NGoodIDs = 0;

			name = "workers_n";
			GoodID2Name.push_back(name);
			GoodName2ID[name] = NGoodIDs++;

			name = "food_kg";
			GoodID2Name.push_back(name);
			GoodName2ID[name] = NGoodIDs++;

			// First pass: make list of task names

			while (infile >> name, name != "}")
			{
				GoodID2Name.push_back(name);
				GoodName2ID[name] = NGoodIDs++;
				int n = 0;
				do {
					infile >> name;
					if (name == "{") n++;
					else if (name == "}") n--;
				} while (n > 0);
			}
			infile.close();
			infile.open(InputFileName);
			while (infile >> name, name != "TASKS");
			infile >> name; // "{"

			// Second pass: read Task definitions (Performers)

			while (infile >> name, name != "}")
			{
				assert(NGoodIDs == (int)GoodID2Name.size());
				infile >> word;// word:"{"

				// Performer name: each Task in a separate Performer
				if (GoodName2ID.find(name) == GoodName2ID.end()) // already defined
				{
					Outf << "Error in input file: Task name " << name
						<< " already defined" << endl;
					assert(false);
					std::exit(0);
				}

				taskname = name;
				_productID = GoodName2ID[taskname];
				pProduct = new CProductData(_productID);
				name = "P_" + name;

				pProduct->delayMonths = 1;

				GoodID2Name.push_back(name); // Performer name
				GoodID _producerType = NGoodIDs;
				GoodName2ID[name] = _producerType;
				if (first_producerType == 0)
					first_producerType = _producerType;

				NGoodIDs++;
				CProducer* pProducer =
					new CProducer(_producerType, -1, pCivData->pGeneration, nullptr);

				while (infile >> word, word != "}")
				{
					if (word == "immobilizedMinimums" || word == "executeFirst")
					{
						infile >> word; // word:"{"
						while (infile >> name, name != "}")
						{
							if (GoodName2ID.find(name) == GoodName2ID.end())
							{
								Outf << "Error in input file: " << name
									<< "    is not listed in GOODS" << endl;
								assert(false);
								std::exit(0);
							}
							value = 0;
							pProducer->immobilizedMinimums[GoodName2ID[name]] = value;
							pProducer->_ImmobilizedGoods[GoodName2ID[name]] = 0;
						}
					}
					else if (word == "afterStep")
					{
						infile >> word >> value; // word: "="
						pProduct->availableAtStep = value;
					}
					else if (word == "delayMonths" || word == "delaySteps")
					{
						infile >> word >> value; // word: "="
						pProduct->delayMonths = value;
					}
					else if (word == "nonConsumedPerUnit")
					{
						infile >> word; // word:"{"
						string inputName;
						while (infile >> inputName, inputName != "}")
						{
							if (GoodName2ID.find(inputName) == GoodName2ID.end())
							{
								Outf << "Error in input file: " << inputName
									<< "    is not listed in GOODS" << endl;
								assert(false);
								std::exit(0);
							}
							GoodID inputID = GoodName2ID[inputName];
							infile >> word >> value; // word: "="
							pProduct->nonConsumedPerUnit[inputID] = value;
						}
					}
					else if (word == "preExecuteTasks")
					{
						infile >> word; // word:"{"
						string inputName;
						while (infile >> inputName, inputName != "}")
						{
							if (GoodName2ID.find(inputName) == GoodName2ID.end())
							{
								*pOutf << "Error in input file: " << inputName
									<< "    is not listed in GOODS" << endl;
								assert(false);
								std::exit(0);
							}
							GoodID inputID = GoodName2ID[inputName];
							infile >> word >> value; // word: "="
							pProduct->nonConsumedPerUnit[inputID] = value;
							//pProduct->consumedPerUnit[inputID] = value;
						}
					}
					else
						assert(false);
				}
				pProducer->myProductsData[_productID] = pProduct;
				ProducerPrototypes[pProducer->_producerType] = pProducer;
			}
		}
	}

	if (this->at(kScoreGoodID) <= 0 || this->at(kScoreGoodID) >= NGoodIDs)
		this->at(kScoreGoodID) = -1;

	// set up Producers

	ProducerType_of_this_productID.clear();
	for (auto producerPair : ProducerPrototypes)
	{
		CProducer* pPrototype = producerPair.second;
		GoodID productID, producergID;
		producergID = pPrototype->_producerType;

		pPrototype->_LastUsedTimestep = 0;

		GoodValue InitSalary = 1000;
		pPrototype->setMyPriceOf(workers_n, InitSalary);
		pPrototype->_myPriceAdapt =
			CivData::pCivData->at(CivData::kPriceAdaptDefaultPer100) / 100.0; // 1.2

		for (auto productPair : pPrototype->myProductsData)
		{
			productID = productPair.second->_productID;
			ProducerType_of_this_productID[productID] = producergID;

			// activate production of productID: prepare buy and sell lists

			pPrototype->_Goods_to_be_produced[productID];
			pPrototype->_Goods_to_sell[productID];
			if (bSingleRobot)
				productPair.second->delayMonths = 0;


			for (auto inputID : productPair.second->nonConsumedPerUnit)
			{
				pPrototype->_ListOfGoods_to_buy[inputID.first];
				pPrototype->_Goods_I_have[inputID.first];
			}

			for (auto inputID : productPair.second->consumedPerUnit)
			{
				pPrototype->_ListOfGoods_to_buy[inputID.first];
				pPrototype->_Goods_I_have[inputID.first];
			}

			pPrototype->setMyPriceOf(productID,
				pPrototype->initialPriceOfProductID(productID));
		}
	};

	// verify that we have producers for all goods

	for (auto gPair : GoodName2ID)
	{
		GoodID productID = gPair.second;
		if (productID <= 1 || productID >= first_producerType)
			continue;

		if (ProducerType_of_this_productID.find(productID)
			== ProducerType_of_this_productID.end())
		{
			Outf << "Error in input file: " << GoodID2Name[productID]
				<< "    has no Producer listed in PRODUCERS" << endl;
			assert(false);
			std::exit(0);
		}
	}

	if (bRobotsColony)
		setupRobotsColony();

	// single robot

	if (bSingleRobot)
		setupSingleRobot();

	Outf.flush();

	infile.close();

	return (*this);
}

void CivData::setupRobotsColony()
{
	at(kFixedPrices) = 1;
	at(kMonetaryBasePerCapita) = 1e6;

	at(kPriceProfitPer100) = 100;
	at(kPriceAdaptDefaultPer100) = 100;

	at(kMaxNBanks) = 0;

	at(kVATPer100) = 0;
	at(kTaxPer100) = 0;
	at(kPayUnemplPer100) = 0;
}

void CivData::setupSingleRobot()
{
	int nIndiv = (int)ProducerPrototypes.size();
	at("nIndividuals") = nIndiv;
	at(kMaxInteractingNeighbors) = 3 * nIndiv;

	at(kAssignPrototypes) = 1;
	at(kMaxUnusedTimestps) = 99999999;
	bRobotsColony = true;
	setupRobotsColony();
}

double CivData::getRandom01()
{
	uniform_real_distribution<> myRand01(0, 1);

	double rnd = myRand01(myRandomEngine);
	return rnd;
}


//-------------------------CProducerData-----------------------------------

CProducerData::CProducerData(int nMonths)
{
	_ID = -1;
	maxTotalValue = 0;
	finalTotalValue = 0;
	pTotalValue = new vector<double>(nMonths, 0);
	pCash = new vector< GoodValue >(nMonths, 0);
	pLoan = new vector< GoodValue >(nMonths, 0);
	pImmobGoodsValue = new TimeValueCurve(nMonths, 0);
	_HasWorkedCurrentMonth = new vector<int>(nMonths);
}

CProducerData::~CProducerData()
{
	delete _HasWorkedCurrentMonth;
	delete pImmobGoodsValue;
	delete pLoan;
	delete pCash;
	delete pTotalValue;
}


//-------------------------CBankData-----------------------------------

CBankData::CBankData(int nMonths)
{
	_ID = -1;
	_pTotalBullion = new vector<double>(nMonths, 0);
	pMyLoan = new vector< double >(nMonths, 0);
	pCash = new vector< double >(nMonths, 0);
	pTotalDeposits = new vector< double >(nMonths, 0);
	pTotalLoans = new vector< double >(nMonths, 0);
	pColectedInterests = new vector< double >(nMonths, 0);
}

CBankData::~CBankData()
{
	delete pColectedInterests;
	delete pTotalDeposits;
	delete pTotalLoans;
	delete pCash;
	delete pMyLoan;
	delete _pTotalBullion;
}


//-------------------------CTheStateData-----------------------------------

CTheStateData::CTheStateData(int nMonths)
{
	maxTotalValue = 0;
	finalTotalValue = 0;
	pTotalValue = new vector<double>(nMonths, 0);
	pCash = new vector< GoodValue >(nMonths, 0);
	pAnnualTax = new vector< GoodValue >(nMonths, 0);
	pAnnualVAT = new vector< GoodValue >(nMonths, 0);
	pAnnUnempl = new vector< GoodValue >(nMonths, 0);
	pLoan = new vector< GoodValue >(nMonths, 0);
	_HasWorkedCurrentMonth = new vector<int>(nMonths);
}

CTheStateData::~CTheStateData()
{
	delete pLoan;
	delete pCash;
	delete pAnnualTax;
	delete pAnnualVAT;
	delete pAnnUnempl;
	delete pTotalValue;
	delete _HasWorkedCurrentMonth;
}


//-------------------------CIndividualData-----------------------------------

CIndividualData::CIndividualData(int nMonths)
{
	maxTotalValue = 0;
	finalTotalValue = 0;
	pTotalValue = new vector<double>(nMonths, 0);
	pCash = new vector< GoodValue >(nMonths, 0);
	pLoan = new vector< GoodValue >(nMonths, 0);
	_HasWorkedCurrentMonth = new vector<int>(nMonths);
}

CIndividualData::~CIndividualData()
{
	delete pLoan;
	delete pCash;
	delete pTotalValue;
	delete _HasWorkedCurrentMonth;
}


//-----------------------CGenerationData-------------------------------------

CGenerationData::CGenerationData(int nIndiv, int nTsteps)
	: nIndividuals(nIndiv), nTimesteps(nTsteps)
{
	int nGoodIDs = CivData::pCivData->NGoodIDs;
	MarketPrices.resize(nGoodIDs, vector<double>(nTsteps, 0));

	pBanksIDs = new vector<GoodID>;

	pTotalBanksCash = new vector<double>(nTsteps, 0);
	pIndivsCash = new vector<double>(nTsteps, 0);
	pProdsCash = new vector<double>(nTsteps, 0);
	pTotalInterestsFromClients = new vector<double>(nTsteps, 0);
	pUnemployment = new vector<double>(nTsteps, 0);
	pAccumGDP = new vector<double>(nTsteps, 0);

	pIndivData = new vector< CIndividualData* >;
	for (int nn = 0; nn < nIndiv; ++nn)
		pIndivData->push_back(new CIndividualData(nTsteps));

	pProducerData = new vector< CProducerData* >;
	for (int nn = 0; nn < nIndiv; ++nn)
		pProducerData->push_back(new CProducerData(nTsteps));

	pTheStateData = new CTheStateData(nTsteps);
	pCentralBankData = new CBankData(nTsteps);

	pBanksNetFinal = new map< GoodID, GoodValue >;

	pIndividualsTotSortedVal = new vector< pair<double, GoodID> >(nIndiv);
	pProducersTotSortedVal = new vector< pair<double, GoodID> >(nIndiv);
	pIndivPlusProdPlusBankFinalSortedVal =
		new vector< pair<double, GoodID> >(nIndiv);
}

CGenerationData::~CGenerationData()
{
	delete pTotalBanksCash;
	delete pIndivsCash;
	delete pProdsCash;
	delete pTotalInterestsFromClients;
	delete pUnemployment;
	delete pAccumGDP;

	if (pIndivData)
	{
		for (auto pdat : *pIndivData)
		{
			delete pdat;
			pdat = nullptr;
		}

		delete pIndivData;
		pIndivData = nullptr;
	}

	if (pProducerData)
	{
		for (auto pdat : *pProducerData)
		{
			delete pdat;
			pdat = nullptr;
		}

		delete pProducerData;
		pProducerData = nullptr;
	}

	delete pTheStateData;
	pTheStateData = nullptr;

	delete pCentralBankData;
	pCentralBankData = nullptr;

	delete pBanksNetFinal;
	pBanksNetFinal = nullptr;
	const auto copy = mBankData;
	for (auto elem : copy)
	{
		delete mBankData.at(elem.first);
		mBankData.erase(elem.first);
	}

	delete pIndividualsTotSortedVal;
	delete pProducersTotSortedVal;
	delete pIndivPlusProdPlusBankFinalSortedVal;
}

// CivData& CivData::writeFile(string outfilename)
/*{
	assert(false);
	return (*this);

	ofstream outfile;
	outfile.open(outfilename);

	outfile << "    Deployers\n";
	outfile << "--- ------------------------------\n";

	// Keywords
	outfile << "\n     _CONTROL_VARIABLES_\n\n";
	for (auto k : (*this))
	{
		if (k.first != "Genes" && k.first != "Goods"
			&& k.first != "Producers")
			outfile << k.second << "  " << k.first << endl;
	}
	outfile << "--- ------------------------------\n";

	// Goods
	outfile << "\n     _GOODS_AND_PRODUCERS_\n\n";
	for (auto productName : GoodID2Name)
	{
		GoodID _productID = GoodName2ID[productName];
		outfile << "good: " << productName << "   units: " << endl;
		if (productName == "workers_n")
		{
			outfile << "---\n\n";
			continue;
		}

		// Producers
		outfile << "PRODUCER:\n";
		/*CGenericProducer* pGenericProducer = 0;
		pGenericProducer = new CGenericProducer(productName);
		if (InitMonth[_productID] != -1)
			outfile << "InitMonth  " << InitMonth[_productID] << endl;
		if (ProductionDelayMonths[_productID] != 0)
			outfile << "ProductionDelayMonths  " << ProductionDelayMonths[_productID]
			<< endl;
		outfile <<
			"Inputs		InputPERproductUnit\n";
		for (auto gInID : pGenericProducer->myInputIDs())
		{
			outfile << GoodID2Name[gInID] << "\t\t"
				<< InputPERproductUnit[_productID][gInID]
				<< " ";
			outfile << InputGoodAssigment[_productID][gInID] << endl;
		}
		outfile << "---\n\n";
	}
	outfile << "--- ------------------------------\n";

	// Population
	outfile << "\n     _POPULATION_\n";
	int groupN = 0;
	for (auto indivGroup : CivData::pCivData->GroupsOfGoodsAndProducers)
	{
		outfile << "\nIndividuals group " << groupN++ << endl;
		outfile << "\nGoods:\n";
		for (auto good : indivGroup[0]) // Goods
			outfile << CivData::pCivData->GoodID2Name[good.first] << "\t"
			<< good.second._quantity << endl;
		outfile << "---\n";

		outfile << "Producers:\n";
		for (auto good : indivGroup[1]) // Producers
			outfile << CivData::pCivData->GoodID2Name[good.first] << endl;
		outfile << "---\n";
		outfile << "---\n";
	}
	outfile << "--- ------------------------------\n";

	// Genes
	outfile << "\n--- Genes ---";
	outfile << "\nPriceadapt:\n";
	for (int gID = 0; gID < v_GoodNames.size(); ++gID)
		outfile << v_GoodNames[gID] << " "
		<< GenesMin[priceadapt][gID] << " " << GenesMax[priceadapt][gID] << "\n";
	outfile << "-------------\n\n";* /

	outfile.close();

	return (*this);
}
*/
