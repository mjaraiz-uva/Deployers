
// Generation.cpp

// "Deployers: 
//  The Spontaneous Rise and Development of Economic Systems"

#include "pch.h"

CGeneration::CGeneration()
	: nIndividuals(0), nYearsPerGeneration(0), evaluated(false)
{
	MaxPopulation = 1000000;
	nYearsPerGeneration = (unsigned int)CivData::pCivData->at(CivData::kYears);
	evaluated = false;

	nTimesteps = (CivData::pCivData->at(CivData::kYears))
		* CivData::pCivData->stepsPerYear;

	CurrentMonth = 0;
	CurrentTimestep = 0;
	CurrentYear = 0;
	GenerationN = -1;
	nMaxInteractingNeighbors = 20;
	thisTimestepTradedPrices.resize(CivData::pCivData->NGoodIDs, 0);
	thisTimestepNtrades.resize(CivData::pCivData->NGoodIDs, 0);

	CivData::pCivData->pGeneration = this;
	nIndividuals = (unsigned int)CivData::pCivData->at(CivData::kIndividuals);

	// Create new Individuals
	for (int indivID = 0; indivID < nIndividuals; ++indivID)
	{
		CIndividual* pIndiv = new CIndividual(this, indivID);

		vpIndividuals.push_back(pIndiv);
	}

	// -------------  TheState and its CentralBank  ----------------------------

	CivData::pTheState = new CTheState();
	CivData::pCentralBank = new CBank(CentralBank, CivData::pTheState);
}

CGeneration::~CGeneration()
{
	delete CivData::pCivData->pCurrentGenerationData;
	CivData::pCivData->pCurrentGenerationData = nullptr;

	delete CivData::pCentralBank;
	CivData::pCentralBank = nullptr;

	delete CivData::pTheState;
	CivData::pTheState = nullptr;

	while (vpIndividuals.size() > 0)
	{
		delete vpIndividuals.back();

		vpIndividuals.pop_back();
	}
};

GoodValue CGeneration::initSalary()
{
	return CivData::pCivData->minSalary +
		(CivData::pCivData->maxSalary - CivData::pCivData->minSalary)
		* CivData::pCivData->getRandom01();
};

void CGeneration::initializePopulation()
{
	if (nIndividuals > MaxPopulation)
	{
		(*(CivData::pCivData->pOutf)) << "Error: nIndividuals > MaxPopulation = "
			<< MaxPopulation << endl;
		(*(CivData::pCivData->pOutf)).flush();
		exit(0);
	}

	// Initialize Population: 

	nMaxInteractingNeighbors =
		CivData::pCivData->at(CivData::kMaxInteractingNeighbors);

	nYearsPerGeneration =
		(unsigned int)CivData::pCivData->at(CivData::kYears);
	double priceAdaptDefault =
		CivData::pCivData->at(CivData::kPriceAdaptDefaultPer100) / 100.0; // 1.20

	if(CivData::pCivData->bRobotsColony)
		(*CivData::pCivData->pCurrentGenerationData).MarketPrices[workers_n][0] = 1000;
	else
		(*CivData::pCivData->pCurrentGenerationData).MarketPrices[workers_n][0] = initSalary();

	double minFoodStock
		= CivData::pCivData->at(CivData::kMinFoodStockYears)
		* CivData::pCivData->stepsPerYear * CIndividual::MonthlyFood;
	double scoredGoodID = CivData::pCivData->at(CivData::kScoreGoodID);

	CivData::pTheState->setMyPriceOf(workers_n, initSalary());
	CivData::pTheState->_myPriceAdapt = priceAdaptDefault;
	CivData::pTheState->_MinCash = 1 * // keep some years salary
		12 * CivData::pTheState->_myPrice[workers_n];

	for (auto pIndiv : vpIndividuals)
	{
		pIndiv->_Manager = nullptr;
		pIndiv->_pUsedBank = CivData::pCentralBank;// initially
		pIndiv->_myPriceAdapt = priceAdaptDefault;

		pIndiv->setMyPriceOf(workers_n, initSalary());

		// Initialize the three basic goods: money, labour and food

		pIndiv->Cash() = 0;
		pIndiv->_MinCash = 1 * CivData::pCivData->stepsPerYear
			* pIndiv->_myPrice[workers_n];// keep some years salary

		pIndiv->_ListOfGoods_I_wish_to_have[food_kg] = 0;// minFoodStock;
		pIndiv->_Goods_I_have[food_kg] = 0;

		// Score ID from input file

		if (CivData::pCivData->at(CivData::kScoreGoodID) > 0 &&
			CivData::pCivData->at(CivData::kScoreGoodQuantity) > 0)
			pIndiv->_ListOfGoods_I_wish_to_have[CivData::pCivData->
			at(CivData::kScoreGoodID)]
			= CivData::pCivData->at(CivData::kScoreGoodQuantity);
	}
};

void CGeneration::MonthlyUpdatePopulationStatus(
	vector<unsigned int>& randomListAliveIndivs)
{
	CivData::pTheState->_HasWorkedCurrentMonth = false;
	CivData::pCentralBank->_HasWorkedCurrentMonth = false;
	randomListAliveIndivs = getRandomListOfIndividual_IDs(nIndividuals);

	for (int indivID = 0; indivID < randomListAliveIndivs.size(); ++indivID)
	{
		CIndividual* pIndiv = vpIndividuals[randomListAliveIndivs[indivID]];

		pIndiv->_HasWorkedCurrentMonth = false;
		for (auto gPair : pIndiv->_mProducers)
			gPair.second->_HasWorkedCurrentMonth = false;
	}

	const auto& GoodsIwish = CivData::pCivData->_GoodsIwish;

	for (auto item : GoodsIwish)
	{
		if (item._year == CurrentYear && item._month == CurrentMonth)
		{
			if (item._indivN == -1) // theState
			{
				CivData::pTheState->_ListOfGoods_I_wish_to_have.clear();
				CivData::pTheState->_ListOfGoods_I_wish_to_have
					= item._Goods_I_wish;
			}
			else if (item._indivN == -9)
			{
				for (int nn = 0; nn < randomListAliveIndivs.size(); ++nn)
				{
					CIndividual* pIndiv = vpIndividuals[randomListAliveIndivs[nn]];
					pIndiv->_ListOfGoods_I_wish_to_have.clear();
					pIndiv->_ListOfGoods_I_wish_to_have
						= item._Goods_I_wish;
				}
			}
			else if (item._indivN >= 0 && item._indivN < nIndividuals)
			{
				vpIndividuals[item._indivN]->_ListOfGoods_I_wish_to_have.clear();
				vpIndividuals[item._indivN]->_ListOfGoods_I_wish_to_have
					= item._Goods_I_wish;
			}
		}
	}
}

void CGeneration::runGeneration()
{

	int nIndividuals = (*CivData::pCivData)[CivData::kIndividuals];
	int nTimesteps = (CivData::pCivData->at(CivData::kYears))
		* CivData::pCivData->stepsPerYear;

	delete (*CivData::pCivData).pCurrentGenerationData;
	(*CivData::pCivData).pCurrentGenerationData =
		new CGenerationData(nIndividuals, nTimesteps);

	int seed = 1 + (1 + GenerationN);
	CivData::pCivData->myRandomEngine.seed(seed);

	initializePopulation();

	// Run this Generation's Lifetime
	int currGeneration = CivData::pCivData->currentGenerationN;
	int indivN = -1;

	vector<unsigned int> randomListAliveIndivs;
	vector<unsigned int> randomListAliveNeighbors;
	CivData::pCivData->currentTimestep = CurrentTimestep = -1;
	for (CurrentYear = 0; CurrentYear < nYearsPerGeneration; CurrentYear++)
	{
		CivData::pCivData->currentYearN = CurrentYear;

		for (CurrentMonth = 0; CurrentMonth < CivData::pCivData->stepsPerYear;
			CurrentMonth++)
		{
			CivData::pCivData->currentMonthN = CurrentMonth;
			CivData::pCivData->currentTimestep = ++CurrentTimestep;
			thisTimestepTradedPrices.resize(CivData::pCivData->NGoodIDs, 0);
			thisTimestepNtrades.resize(CivData::pCivData->NGoodIDs, 0);

			// Population changes CurrentYear, CurrentMonth
			MonthlyUpdatePopulationStatus(randomListAliveIndivs);

			// TheState and CentralBank monthly activity

			CivData::pTheState->MonthlyActivity();
			CivData::pCentralBank->MonthlyActivity();

			auto CopyOfrandomListAliveIndivs = randomListAliveIndivs;

			// process random-ordered Population
			while (randomListAliveIndivs.size() > 0)
			{
				unsigned int indivN = randomListAliveIndivs.back();
				randomListAliveIndivs.pop_back();

				CIndividual* pIndiv = vpIndividuals[indivN];

				pIndiv->MonthlyActivity();
			}

			CivData::pTheState->PayUnemployment(CopyOfrandomListAliveIndivs);

			ProcessIndividualDataFromCurrentMonthlyActivity();
		} // CurrentMonth

		showCurrentYearNumber();
	} // CurrentYear

	CivData::pCivData->pCivilizationData->
		push_back(CivData::pCivData->pCurrentGenerationData);

	evaluated = true;
}

bool CGeneration::CheckGenerationBalance()
{
	if (CurrentTimestep < 99999)	return true;

	if (CurrentTimestep == 0)
		return true;

	CGenerationData* pGenDat = CivData::pCivData->pCurrentGenerationData;
	auto pCBData = pGenDat->pCentralBankData;

	// CENTRALBANK & BANKS  ======================================================

	// CentralBank

	pCBData->_pTotalBullion->at(CurrentTimestep) = 0;
	pCBData->pCash->at(CurrentTimestep) = 0;
	pCBData->pColectedInterests->at(CurrentTimestep) = 0;
	pCBData->pMyLoan->at(CurrentTimestep) = 0;
	pCBData->pTotalDeposits->at(CurrentTimestep) = 0;
	pCBData->pTotalLoans->at(CurrentTimestep) = 0;

	pCBData->_pTotalBullion->at(CurrentTimestep)
		= CivData::pCentralBank->_TotalBullion;

	if (CurrentTimestep == 0)
		pCBData->pCash->at(CurrentTimestep) =
		CivData::pCentralBank->_TotalBullion;
	else
		pCBData->pCash->at(CurrentTimestep) =
		CivData::pCentralBank->Cash();

	pCBData->pColectedInterests->at(CurrentTimestep)
		= CivData::pCentralBank->_InterestsColectedFromClients;

	for (auto pair : CivData::pCentralBank->_ClientsAccounts)
	{
		if (pair.second._value > 0)
			pCBData->pTotalDeposits->at(CurrentTimestep)
			+= pair.second._value;
		else
			pCBData->pTotalLoans->at(CurrentTimestep)
			+= -pair.second._value;
	}

	if (CurrentTimestep > 0)// Check balance
	{
		GoodValue error =
			CivData::pCentralBank->_TotalBullion // constant = initial value
			+ pCBData->pColectedInterests->at(CurrentTimestep)
			+ (pCBData->pTotalDeposits->at(CurrentTimestep)
				- pCBData->pTotalLoans->at(CurrentTimestep))

			- pCBData->pCash->at(CurrentTimestep);

		if (error != 0)
		{
			assert(false);
			return false;
		}
	}

	// Commercial Banks

	pGenDat->pTotalBanksCash->at(CurrentTimestep) = 0;
	pGenDat->pTotalInterestsFromClients->at(CurrentTimestep) = 0;
	int bankN = -1;
	for (auto pair : CivData::pCentralBank->_Banks)
	{
		++bankN;
		GoodID bankID = pair.first;
		CBank* pBank = pair.second;

		pGenDat->pTotalBanksCash->at(CurrentTimestep) += pBank->Cash();
		pGenDat->pTotalInterestsFromClients->at(CurrentTimestep)
			+= pBank->_InterestsColectedFromClients;

		if (CurrentTimestep > 0)// Check balance
		{
			GoodValue error =
				pBank->_TotalBullion
				+ pBank->_InterestsColectedFromClients
				+ (pBank->_ClientsDeposits - pBank->_ClientsLoans)
				- pBank->Cash();

			if (error != 0)
			{
				assert(false);
				return false;
			}
		}
	}

	// Individuals and Producers

	pGenDat->pIndivsCash->at(CurrentTimestep) = 0;
	pGenDat->pProdsCash->at(CurrentTimestep) = 0;
	for (auto pIndiv : vpIndividuals)
	{
		pGenDat->pIndivsCash->at(CurrentTimestep) += pIndiv->Cash();

		for (auto gPair : pIndiv->_mProducers)
		{
			CProducer* pMyProducer = gPair.second;
			pGenDat->pProdsCash->at(CurrentTimestep) += pMyProducer->Cash();
		}
	}

	// Check Total Cash  ======================================================

	GoodValue totalCash = CivData::pTheState->Cash()
		+ pGenDat->pIndivsCash->at(CurrentTimestep)
		+ pGenDat->pProdsCash->at(CurrentTimestep)

		+ pCBData->pCash->at(CurrentTimestep)

		+ pGenDat->pTotalBanksCash->at(CurrentTimestep);

	GoodValue mismatch = totalCash
		//- pCBData->pColectedInterests->at(CurrentTimestep)
		- pCBData->_pTotalBullion->at(CurrentTimestep);

	if (CurrentTimestep > 0)
	{
		if (mismatch == 0)
			return true;
		else
		{
			assert(false);

			pCBData->_pTotalBullion->at(CurrentTimestep) = 0;
			pCBData->pCash->at(CurrentTimestep) = 0;
			pCBData->pColectedInterests->at(CurrentTimestep) = 0;
			pCBData->pMyLoan->at(CurrentTimestep) = 0;
			pCBData->pTotalDeposits->at(CurrentTimestep) = 0;
			pCBData->pTotalLoans->at(CurrentTimestep) = 0;
			return false;
		}
	}
	else
	{
		return true;

		pCBData->_pTotalBullion->at(CurrentTimestep) = 0;
		pCBData->pCash->at(CurrentTimestep) = 0;
		pCBData->pColectedInterests->at(CurrentTimestep) = 0;
		pCBData->pMyLoan->at(CurrentTimestep) = 0;
		pCBData->pTotalDeposits->at(CurrentTimestep) = 0;
		pCBData->pTotalLoans->at(CurrentTimestep) = 0;
	}
}

void CGeneration::ProcessIndividualDataFromCurrentMonthlyActivity()
{
	CGenerationData* pGenDat = CivData::pCivData->pCurrentGenerationData;
	auto pCBData = pGenDat->pCentralBankData;
	int nGoodIDs = CivData::pCivData->NGoodIDs;

	pGenDat->pTheStateData->pTotalValue->at(CurrentTimestep) = 0;
	pGenDat->pTheStateData->pCash->at(CurrentTimestep) = 0;
	pGenDat->pTheStateData->pAnnualTax->at(CurrentTimestep) = 0;
	pGenDat->pTheStateData->pAnnualVAT->at(CurrentTimestep) = 0;
	pGenDat->pTheStateData->pAnnUnempl->at(CurrentTimestep) = 0;
	pGenDat->pTheStateData->pLoan->at(CurrentTimestep) = 0;

	pCBData->_pTotalBullion->at(CurrentTimestep) = 0;
	pCBData->pCash->at(CurrentTimestep) = 0;
	pCBData->pColectedInterests->at(CurrentTimestep) = 0;
	pCBData->pMyLoan->at(CurrentTimestep) = 0;
	pCBData->pTotalDeposits->at(CurrentTimestep) = 0;
	pCBData->pTotalLoans->at(CurrentTimestep) = 0;

	pGenDat->pTotalBanksCash->at(CurrentTimestep) = 0;
	pGenDat->pIndivsCash->at(CurrentTimestep) = 0;
	pGenDat->pProdsCash->at(CurrentTimestep) = 0;

	// MARKET PRICES  ======================================================

	auto& marketPrices = CivData::pCivData->pCurrentGenerationData->MarketPrices;
	marketPrices.resize(nGoodIDs, vector<double>(nTimesteps, 0.0));
	for (int gID = 0; gID < nGoodIDs; ++gID)
	{
		if (thisTimestepNtrades[gID] > 0)
			marketPrices[gID][CurrentTimestep] =
			thisTimestepTradedPrices[gID] / thisTimestepNtrades[gID];
	}

	// PRODUCERS  ======================================================

	for (auto pIndiv : vpIndividuals)
	{
		CProducerData* pProducerDat = pGenDat->pProducerData->at(pIndiv->_ID);

		pProducerDat->pCash->at(CurrentTimestep) = 0;
		pProducerDat->pLoan->at(CurrentTimestep) = 0;
		pProducerDat->pImmobGoodsValue->at(CurrentTimestep) = 0;
		pProducerDat->pTotalValue->at(CurrentTimestep) = 0;
		for (auto gPair : pIndiv->_mProducers)
		{
			CProducer* pMyProducer = gPair.second;

			if (pMyProducer->_HasWorkedCurrentMonth)
				pProducerDat->_HasWorkedCurrentMonth->at(CurrentTimestep) = 1;

			// 1. Cash & Loan ---------------------------------------------------

			(*pProducerDat->pCash)[CurrentTimestep] += pMyProducer->Cash();
			pGenDat->pProdsCash->at(CurrentTimestep)
				+= pMyProducer->Cash();
			(*pProducerDat->pLoan)[CurrentTimestep]
				+= -pMyProducer->_pUsedBank->ClientCurrentBalance(pMyProducer);

			// Current Producer TotalValue

			// Initialize producerTotalVal
			double producerTotalVal =
				pMyProducer->Cash()
				+ pMyProducer->_pUsedBank->ClientCurrentBalance(pMyProducer);

			for (auto gPair : pMyProducer->_ImmobilizedGoods)
			{
				double value = gPair.second.quantity()
					* marketPrices[gPair.first][CurrentTimestep];

				producerTotalVal += value;
				(*pProducerDat->pImmobGoodsValue)[CurrentTimestep] += value;
			}

			for (auto gPair : pMyProducer->_Goods_I_have)
			{
				if (gPair.first == workers_n)
					continue;
				producerTotalVal +=
					gPair.second.quantity() * marketPrices[gPair.first][CurrentTimestep];
			}

			for (auto gPair : pMyProducer->_Goods_to_sell)
				producerTotalVal +=
				gPair.second.quantity() * marketPrices[gPair.first][CurrentTimestep];

			pProducerDat->pTotalValue->at(CurrentTimestep) += producerTotalVal;
		}
	}

	// INDIVIDUALS  ======================================================

	for (auto pIndiv : vpIndividuals)
	{
		CIndividualData* pIndivDat = pGenDat->pIndivData->at(pIndiv->_ID);

		if (pIndiv->_HasWorkedCurrentMonth)
			pIndivDat->_HasWorkedCurrentMonth->at(CurrentTimestep) = 1;

		// 1. Cash & Loan ---------------------------------------------------

		pIndivDat->pCash->at(CurrentTimestep) = pIndiv->Cash();
		pGenDat->pIndivsCash->at(CurrentTimestep)
			+= pIndiv->Cash();
		pIndivDat->pLoan->at(CurrentTimestep) =
			-pIndiv->_pUsedBank->ClientCurrentBalance(pIndiv);

		// 2. GoodsValues & TotalValue ----------------------------------------
		// _Goods_I_have includes number of workers and Producers (ID's)

			// Initialize producerTotalVal
		pIndivDat->pTotalValue->at(CurrentTimestep) =
			pIndiv->Cash() + pIndiv->_pUsedBank->ClientCurrentBalance(pIndiv);

		for (auto& gPair : pIndiv->_Goods_I_have)
		{
			GoodID gID = gPair.first;
			if (pIndivDat->mGoodsIhave.find(gID) == pIndivDat->mGoodsIhave.end())
				pIndivDat->mGoodsIhave[gID] = new TimeValueCurve(nTimesteps, 0);

			double qtty = gPair.second.quantity();
			double value = gPair.second.quantity();// Producers: 1
			if (gID < CivData::pCivData->first_producerType)
				value *= marketPrices[gID][CurrentTimestep];

			pIndivDat->mGoodsIhave[gID]->at(CurrentTimestep) += qtty;

			pIndivDat->pTotalValue->at(CurrentTimestep) += value;
		}

		for (auto& gPair : pIndiv->_Goods_to_sell)
		{
			GoodID gID = gPair.first;
			if (pIndivDat->mGoodsIhave.find(gID) == pIndivDat->mGoodsIhave.end())
				pIndivDat->mGoodsIhave[gID] = new TimeValueCurve(nTimesteps, 0);

			double qtty = gPair.second.quantity();
			double value = gPair.second.quantity();// Producers: 1
			if (gID < CivData::pCivData->first_producerType)
				value *= marketPrices[gID][CurrentTimestep];

			pIndivDat->mGoodsIhave[gID]->at(CurrentTimestep) += qtty;

			pIndivDat->pTotalValue->at(CurrentTimestep) += value;
		}
	}


	// TheState  ======================================================

	pGenDat->pTheStateData->pCash->at(CurrentTimestep) =
		CivData::pTheState->Cash();

	pGenDat->pTheStateData->pAnnualTax->at(CurrentTimestep) =
		CivData::pTheState->_AnnualTaxInfo;

	pGenDat->pTheStateData->pAnnUnempl->at(CurrentTimestep) =
		CivData::pTheState->_AnnUnemplInfo;

	pGenDat->pTheStateData->pAnnualVAT->at(CurrentTimestep) =
		CivData::pTheState->_AnnualVATInfo;

	pGenDat->pTheStateData->pLoan->at(CurrentTimestep) =
		-(CivData::pTheState->_myBankAccountStatus._value
			+ CivData::pTheState->_myBankAccountStatus._previousInterests);

	pGenDat->pTheStateData->pTotalValue->at(CurrentTimestep) =
		CivData::pTheState->Cash() - pGenDat->pTheStateData->pLoan->at(CurrentTimestep);

	for (auto& gPair : CivData::pTheState->_Goods_I_have)
	{
		GoodID gID = gPair.first;
		if (pGenDat->pTheStateData->mGoodsIhave.find(gID) ==
			pGenDat->pTheStateData->mGoodsIhave.end())
			pGenDat->pTheStateData->mGoodsIhave[gID] =
			new TimeValueCurve(nTimesteps, 0);

		double qtty = gPair.second.quantity();
		double value = gPair.second.quantity();// Producers: 1
		if (gID < CivData::pCivData->first_producerType)
			value *= marketPrices[gID][CurrentTimestep];

		pGenDat->pTheStateData->mGoodsIhave[gID]->at(CurrentTimestep) += qtty;

		pGenDat->pTheStateData->pTotalValue->at(CurrentTimestep) += value;
	}


	// CENTRALBANK & BANKS  ======================================================

	// CentralBank

	pCBData->_pTotalBullion->at(CurrentTimestep)
		= CivData::pCentralBank->_TotalBullion;

	if (CurrentTimestep == 0)
		pCBData->pCash->at(CurrentTimestep) =
		CivData::pCentralBank->_TotalBullion;
	else
		pCBData->pCash->at(CurrentTimestep) =
		CivData::pCentralBank->Cash();

	pCBData->pColectedInterests->at(CurrentTimestep)
		= CivData::pCentralBank->_InterestsColectedFromClients;

	for (auto pair : CivData::pCentralBank->_ClientsAccounts)
		if (pair.second._value > 0)
			pCBData->pTotalDeposits->at(CurrentTimestep)
			+= pair.second._value;
		else
			pCBData->pTotalLoans->at(CurrentTimestep)
			+= -pair.second._value;

	if (CurrentTimestep > 0)// Check balance
	{
		GoodValue error =
			(CivData::pCentralBank->_TotalBullion
				+ pCBData->pColectedInterests->at(CurrentTimestep)
				+ (pCBData->pTotalDeposits->at(CurrentTimestep)
					- pCBData->pTotalLoans->at(CurrentTimestep))
				- pCBData->pCash->at(CurrentTimestep));

		if (error != 0)
			assert(false);
	}

	// Commercial Banks
	int bankN = -1;
	for (auto pair : CivData::pCentralBank->_Banks)
	{
		++bankN;
		GoodID bankID = pair.first;
		CBank* pBank = pair.second;

		pGenDat->pTotalBanksCash->at(CurrentTimestep) += pBank->Cash();
		pGenDat->pTotalInterestsFromClients->at(CurrentTimestep)
			+= pBank->_InterestsColectedFromClients;

		if (pGenDat->mBankData.find(bankID) == pGenDat->mBankData.end())
			pGenDat->mBankData[bankID] = new CBankData(nTimesteps);

		pGenDat->mBankData[bankID]->_pTotalBullion->at(CurrentTimestep)
			= pBank->_TotalBullion;

		pGenDat->mBankData[bankID]->pMyLoan->at(CurrentTimestep)
			= -pBank->_myBankAccountStatus._value;

		pGenDat->mBankData[bankID]->pCash->at(CurrentTimestep)
			= pBank->Cash();

		pGenDat->mBankData[bankID]->pColectedInterests->at(CurrentTimestep)
			= pBank->_InterestsColectedFromClients;

		for (auto pair : pBank->_ClientsAccounts)
		{
			auto deposit = pair.second;
			if (deposit._value > 0)
				pGenDat->mBankData[bankID]->pTotalDeposits->at(CurrentTimestep)
				+= deposit._value;
			else
				pGenDat->mBankData[bankID]->pTotalLoans->at(CurrentTimestep)
				+= -deposit._value;
		}

		if (CurrentTimestep > 0)// Check balance
		{
			GoodValue error =
				(pGenDat->mBankData[bankID]->_pTotalBullion->at(CurrentTimestep)
					+ pGenDat->mBankData[bankID]->pColectedInterests->at(CurrentTimestep)
					+ (pGenDat->mBankData[bankID]->pTotalDeposits->at(CurrentTimestep)
						- pGenDat->mBankData[bankID]->pTotalLoans->at(CurrentTimestep))
					- pGenDat->mBankData[bankID]->pCash->at(CurrentTimestep));

			if (error != 0)
				assert(false);
		}
	}

	// Check Total Cash  ======================================================

	GoodValue totalCash = CivData::pTheState->Cash()
		+ pGenDat->pIndivsCash->at(CurrentTimestep)
		+ pGenDat->pProdsCash->at(CurrentTimestep)
		+ pCBData->pCash->at(CurrentTimestep)
		+ pGenDat->pTotalBanksCash->at(CurrentTimestep);
	if (CurrentTimestep > 0)
		assert(totalCash == pCBData->_pTotalBullion->at(CurrentTimestep));

	// GDP  ======================================================

	if (CurrentTimestep == 0)
		pGenDat->pAccumGDP->at(CurrentTimestep) = 0;
	else // && (CurrentTimestep % 12 != 0))
		pGenDat->pAccumGDP->at(CurrentTimestep)
		+= pGenDat->pAccumGDP->at(CurrentTimestep - 1);

	// UNEMPLOYMENT  ======================================================

	for (auto pIndiv : vpIndividuals)
		if (pIndiv->canBeEmployed())
			pGenDat->pUnemployment->at(CurrentTimestep)++;


	// LAST Timestep: Sorted Total Values  ==========================================

	if (CurrentTimestep == nTimesteps - 1)
	{
		(*(*pGenDat).pBanksIDs).resize(0);

		for (auto pair : CivData::pCentralBank->_Banks)
		{
			GoodID bankID = pair.first;
			CBank* pBank = pair.second;
			(*(*pGenDat).pBanksIDs).push_back(bankID);

			GoodValue totLoans = 0;
			for (auto pair : pBank->_ClientsAccounts)
				totLoans += pair.second._value;

			(*(*pGenDat).pBanksNetFinal)[bankID] =
				pBank->_InterestsColectedFromClients
				+ pBank->_myBankAccountStatus._value;

			if ((*pGenDat).mBankData.find(bankID) == (*pGenDat).mBankData.end())
				(*pGenDat).mBankData[bankID] = new CBankData(nTimesteps);
		}

		for (auto pIndiv : vpIndividuals)
		{
			CIndividualData* pIndivDat = pGenDat->pIndivData->at(pIndiv->_ID);

			pIndivDat->finalTotalValue = pIndivDat->pTotalValue->at(CurrentTimestep);

			pIndivDat->maxTotalValue = *max_element(pIndivDat->pTotalValue->begin(),
				pIndivDat->pTotalValue->end());

			pGenDat->pIndividualsTotSortedVal->at(pIndiv->_ID) = // to be sorted below
				pair<double, GoodID>(pIndivDat->maxTotalValue, pIndiv->_ID);


			CProducerData* pProducerDat = pGenDat->pProducerData->at(pIndiv->_ID);

			pProducerDat->finalTotalValue =
				pProducerDat->pTotalValue->at(CurrentTimestep);

			pProducerDat->maxTotalValue =
				*max_element(pProducerDat->pTotalValue->begin(),
					pProducerDat->pTotalValue->end());

			pGenDat->pProducersTotSortedVal->at(pIndiv->_ID) = // to be sorted below
				std::pair<double, GoodID>(pProducerDat->maxTotalValue, pIndiv->_ID);

			double finalTotVal = pIndivDat->finalTotalValue
				+ pProducerDat->finalTotalValue;

			// Add each Bank's final value to its Manager (same ID as Bank)

			if (pIndiv->_pUsedBank->_pBankManager == pIndiv)
			{
				if ((*pGenDat).mBankData.find(pIndiv->_ID) == (*pGenDat).mBankData.end())
					(*pGenDat).mBankData[pIndiv->_ID] = new CBankData(nTimesteps);

				finalTotVal += (*pGenDat).mBankData[pIndiv->_ID]->
					pColectedInterests->at(nTimesteps - 1);
			}

			pGenDat->pIndivPlusProdPlusBankFinalSortedVal->at(pIndiv->_ID) =
				std::pair<double, GoodID>(finalTotVal, pIndiv->_ID);
		}

		std::sort(pGenDat->pIndividualsTotSortedVal->begin(),
			pGenDat->pIndividualsTotSortedVal->end(),
			greater<pair<double, GoodID>>());

		int nIndivsToPlot = (*CivData::pCivData)[CivData::kMaxNplotIndividuals];
		int includeFirstN = -1;

		auto toPlot = vector<GoodValuePair>(0);
		for (int indivN = 0; indivN < nIndividuals; ++indivN)
		{
			if (nIndividuals <= nIndivsToPlot
				|| indivN % (int)(nIndividuals / nIndivsToPlot) == 0
				|| indivN <= includeFirstN)
				toPlot.push_back((*pGenDat->pIndividualsTotSortedVal)
					[indivN]);
		}
		pGenDat->pIndividualsTotSortedVal->resize(toPlot.size());
		for (int n = 0; n < pGenDat->pIndividualsTotSortedVal->size(); ++n)
			(*pGenDat->pIndividualsTotSortedVal)[n] = toPlot[n];

		std::sort(pGenDat->pProducersTotSortedVal->begin(),
			pGenDat->pProducersTotSortedVal->end(),
			greater< pair<double, GoodID> >());

		toPlot.clear();
		for (int indivN = 0; indivN < nIndividuals; ++indivN)
		{
			if (nIndividuals <= nIndivsToPlot
				|| indivN % (int)(nIndividuals / nIndivsToPlot) == 0
				|| indivN <= includeFirstN
				)
				toPlot.push_back((*pGenDat->pProducersTotSortedVal)
					[indivN]);
		}
		pGenDat->pProducersTotSortedVal->resize(toPlot.size());
		for (int n = 0; n < pGenDat->pProducersTotSortedVal->size(); ++n)
			(*pGenDat->pProducersTotSortedVal)[n] = toPlot[n];

		std::sort(pGenDat->pIndivPlusProdPlusBankFinalSortedVal->begin(),
			pGenDat->pIndivPlusProdPlusBankFinalSortedVal->end(),
			greater< pair<double, GoodID> >());

		toPlot.clear();
		for (int indivN = 0; indivN < nIndividuals; ++indivN)
		{
			if (nIndividuals <= nIndivsToPlot
				|| indivN % (int)(nIndividuals / nIndivsToPlot) == 0
				|| indivN <= includeFirstN)
				toPlot.push_back((*pGenDat->pIndivPlusProdPlusBankFinalSortedVal)
					[indivN]);
		}
		pGenDat->pIndivPlusProdPlusBankFinalSortedVal->resize(toPlot.size());
		for (int n = 0; n < pGenDat->pIndivPlusProdPlusBankFinalSortedVal->size(); ++n)
			(*pGenDat->pIndivPlusProdPlusBankFinalSortedVal)[n] = toPlot[n];
	}
}

vector<unsigned int> CGeneration::getRandomListOfIndividual_IDs(int maxN)
{
	vector<unsigned int> randomList;

	maxN = min(maxN, nIndividuals);
	unsigned int indivN = 9999999;
	if (maxN < nIndividuals / 2)
	{
		uniform_int_distribution<> myRandN(0, nIndividuals - 1);

		for (int n = 0; n < maxN; ++n)
		{
			indivN = myRandN(CivData::pCivData->myRandomEngine);
			if ((*vpIndividuals[indivN])._Alive)
				randomList.push_back(indivN);
		}

		/* //
		set<unsigned int> randset;

		while (randset.size() < maxN)
		{
			indivN = myRandN(CivData::pCivData->myRandomEngine);
			randset.insert(indivN);
			if (randset.size() > randomList.size())
				randomList.push_back(indivN);
		}
		*/
	}
	else
	{
		for (int indivN = 0; indivN < nIndividuals; indivN++)
			if ((*vpIndividuals[indivN])._Alive)
				randomList.push_back(indivN);

		std::shuffle(randomList.begin(), randomList.end(), CivData::pCivData->myRandomEngine);
		randomList.resize(maxN);
	}
	return randomList;
};

