// cl.exe /EHsc /nologo /W4 /MTd
#include <algorithm>
#include <array>
#include <iostream>
#include <random>
#include <string>
#include <vector>
#include <functional> // ref()

using namespace std;

template <typename C> void print(const C& c) {
	for (const auto& e : c) {
		cout << e << " ";
	}

	cout << endl;
}

template <class URNG>
void test(URNG& urng) {

	// Uniform distribution used with a vector
	// Distribution is [-5, 5] inclusive
	uniform_int_distribution<int> dist(-5, 5);
	vector<int> v;

	for (int i = 0; i < 20; ++i) {
		v.push_back(dist(urng));
	}

	cout << "Randomized vector: ";
	print(v);

	// Shuffle an array
	// (Notice that shuffle() takes a URNG, not a distribution)
	array<string, 26> arr = { { "H", "He", "Li", "Be", "B", "C", "N", "O", "F",
		"Ne", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca", "Sc",
		"Ti", "V", "Cr", "Mn", "Fe" } };

	shuffle(arr.begin(), arr.end(), urng);

	cout << "Randomized array: ";
	print(arr);
	cout << "--" << endl;
}

int main()
{
	// First run: non-seedable, non-deterministic URNG random_device
	// Slower but crypto-secure and non-repeatable.
	random_device rd;
	cout << "Using random_device URNG:" << endl;
	test(rd);

	// Second run: simple integer seed, repeatable results
	cout << "Using constant-seed mersenne twister URNG:" << endl;
	mt19937 engine1(12345);
	test(engine1);

	// Third run: random_device as a seed, different each run
	// (Desirable for most purposes)
	cout << "Using non-deterministic-seed mersenne twister URNG:" << endl;
	mt19937 engine2(rd());
	test(engine2);

	// Fourth run: "warm-up" sequence as a seed, different each run
	// (Advanced uses, allows more than 32 bits of randomness)
	cout << "Using non-deterministic-seed \"warm-up\" sequence mersenne twister URNG:" << endl;
	array<unsigned int, mt19937::state_size> seed_data;
	generate_n(seed_data.begin(), seed_data.size(), ref(rd));
	seed_seq seq(begin(seed_data), end(seed_data));
	mt19937 engine3(seq);
	test(engine3);
}