
// Bank.cpp

// "Deployers: 
//  The Spontaneous Rise and Development of Economic Systems"

#include "pch.h"

//==================  The STATE  ==========================

CTheState::CTheState()
	: CIndividual(CivData::pCivData->pGeneration, TheStateID)
{
	_Manager = nullptr;
	BanksInitCapital = CivData::pCivData->at(CivData::kBanksInitCapital);
	CivData::pTheState = this;
}

CTheState::~CTheState()
{
}

void CTheState::MonthlyActivity()
{
	MakeListOfInteractingIndivsAndProducers();

	MakeListOfGoodsToBuy();

	BuyGoods();

	ReturnExcessCashToCB();

	_HasWorkedCurrentMonth = true;
	assert(_pGeneration->CheckGenerationBalance());
}

void CTheState::ReturnExcessCashToCB()
{
	// Try to return excess loan

	GoodValue currentDebt = -_pUsedBank->ClientCurrentBalance(this);

	if (Cash() > 2 * _MinCash && currentDebt > 0)
	{
		GoodValue payed = Cash() - _MinCash;

		CBankEntry loanStatus = _pUsedBank->ClientCashOperation(this, payed);
		if (loanStatus._value != _myBankAccountStatus._value// request granted
			|| loanStatus._pTrader == nullptr) // balance = 0, account closed
			Cash() -= payed;
		_myBankAccountStatus = loanStatus;
	}
}

void CTheState::PayUnemployment(vector<unsigned int>& randomListAliveIndivs)
{
	if (!(*CivData::pCivData).at(CivData::kUseMoney))
		return;

	if (_pGeneration->CurrentTimestep < 1
		|| !(bool)(*CivData::pCivData)[CivData::kPayUnemplPer100])
		return;

	GoodValue unemployPayment = 0.01 * (*CivData::pCivData)[CivData::kPayUnemplPer100] *
		CivData::pCivData->pCurrentGenerationData->
		MarketPrices[workers_n][_pGeneration->CurrentTimestep - 1];

	for (auto indivN : randomListAliveIndivs)
	{
		CIndividual* pIndiv = _pGeneration->vpIndividuals[indivN];
		if (pIndiv->_HasWorkedCurrentMonth)
			continue;

		bool done = false;
		string concept = "";
		if ((*CivData::pCivData)[CivData::kWriteTransactions]
			&& pIndiv->_ID == (*CivData::pCivData)[CivData::kWriteIndivN])
			concept = " transfers unemployPayment= "
			+ to_string(unemployPayment) + " m.u. to ";

		done = _pUsedBank->PayThroughBankTransfer(this,
			pIndiv, unemployPayment, concept);
		if (done)
			_AnnUnemplInfo += unemployPayment;
		assert(done);
	}
}

void CTheState::ChargeAnnualTaxFromTrader(CTrader* pTrader)
{
	if ((*CivData::pCivData)[CivData::kTaxPer100] == 0)
		return;

	GoodValue TotalAssets = pTrader->GetTotalAssets();
	GoodValue tax = max<GoodValue>(0, TotalAssets - _TotalAssetsPreviousYear)
		* 0.01 * (*CivData::pCivData)[CivData::kTaxPer100]
		* TotalAssets / 2.0e7;

	bool done = false;

	string concept = "";
	if ((*CivData::pCivData)[CivData::kWriteTransactions]
		&& pTrader->_ID == (*CivData::pCivData)[CivData::kWriteIndivN]
		|| _ID == (*CivData::pCivData)[CivData::kWriteIndivN])
		concept = " transfers Tax= " + to_string(tax) + " m.u. to ";

	done = pTrader->_pUsedBank->PayThroughBankTransfer(pTrader,
		this, tax, concept);
	if (done)
		_AnnualTaxInfo += tax;
	assert(done);

	_TotalAssetsPreviousYear = TotalAssets;
}

void CTheState::ChargeVATtoTrader(CTrader* pTrader, GoodValue moneyTraded)
{
	if (moneyTraded == 0)
		return;

	GoodValue vat = moneyTraded * 0.01 * (*CivData::pCivData)[CivData::kVATPer100];

	bool done = false;
	string concept = "";
	if ((*CivData::pCivData)[CivData::kWriteTransactions]
		&& (pTrader->_ID == (*CivData::pCivData)[CivData::kWriteIndivN]
			|| _ID == (*CivData::pCivData)[CivData::kWriteIndivN]))
		concept = " transfers VAT= " + to_string(vat) + " m.u. to ";

	done = pTrader->_pUsedBank->PayThroughBankTransfer(pTrader,
		this, vat, concept);
	if (done)
		_AnnualVATInfo += vat;
	assert(done);
}

//======================  CBank  ===================================

/*
Banks intermediate in the financial markets by channelling savings from some
individuals or companies to others. This intermediation work consists of
two activities:

The first consists of attracting deposits, remunerated with
an interest rate to depositors. This attraction of
deposits is known as the liability transactions of the
banks. Depositors are remunerated with a
interest called liability interest but, in addition, they receive
a number of liquidity related services that
provide the accounts: payroll collection, direct debit
of receipts, possibility of payment by check or card, etc.

The second consists of lending (providing credit) to other
persons or companies with the funds obtained: these are
the asset operations. Those who receive the credits
must pay an asset rate of interest on them. The difference
between the asset and liability interest rate is
calls the brokerage margin and reflects the costs
of the operation of banks and their profits
*/

CBank::CBank(GoodID traderType, // Bank or CentralBank
	CTrader* pBankManager)
	: CTrader(traderType,
		pBankManager->_traderType == TheState ? CentralBankID : pBankManager->_ID,
		CivData::pCivData->pGeneration),
	_pBankManager(pBankManager)
{
	_ReserveRatio = 0.01 * CivData::pCivData->at(CivData::kReserveRatioPer100);
	_ClientsDeposits = 0;
	_ClientsLoans = 0;
	_InterestsColectedFromClients = 0;
	MaxNBanks = 0;
	_Manager = pBankManager;
	assert(pBankManager->_traderType == Individual
		|| pBankManager->_traderType == TheState);
	pBankManager->_pOwnedBank = this;

	if (_traderType == CentralBank)
	{
		if (pBankManager->_pUsedBank == nullptr)
			pBankManager->_pUsedBank = this;

		_pUsedBank = nullptr;
		MaxNBanks = CivData::pCivData->at(CivData::kMaxNBanks);
		_TotalBullion = _pGeneration->nIndividuals *
			CivData::pCivData->at(CivData::kMonetaryBasePerCapita);
		Cash() = _TotalBullion;
		_MinCash = 0.0;

		_liabilityRate = 0.001 * CivData::pCivData->at(CivData::kLiabilityRatePer1000);
		_assetRate = 0.001 * CivData::pCivData->at(CivData::kAssetRatePer1000);
	}
	else
	{
		assert(_traderType == Bank);

		_pUsedBank = CivData::pCentralBank;
		_TotalBullion = 0;
		Cash() = _TotalBullion;
		_MinCash = 0;

		double BanksRateFactor = CivData::pCivData->at(CivData::kBanksRateFactor);
		_liabilityRate = 5 * 0.001 * CivData::pCivData->at(CivData::kLiabilityRatePer1000);
		_assetRate = 5 * 0.001 * CivData::pCivData->at(CivData::kAssetRatePer1000);
	}
	assert(_assetRate >= _liabilityRate);
}

CBank::~CBank()
{
}

void CBank::MonthlyActivity()
{
	assert(CheckBalance());

	if (_pGeneration->CurrentMonth == 0) // yearly
		ColectInterests();

	if (_traderType == CentralBank)
	{
	}
	else
	{
		ReturnExcessCashToCB(); // decrease Loan or increase Deposit
	}

	TransferProfitToManager(); // The CentralBank owner/manager is TheState
}

bool CBank::CheckBalance()
{
	for (auto& pair : _ClientsAccounts)
		if (pair.second._value + pair.second._previousInterests == 0)
			assert(false);

	GoodValue mismatch = _TotalBullion + _ClientsDeposits - _ClientsLoans
		- Cash() + _InterestsColectedFromClients;

	if (Cash() >= 0 //(GoodValue)(_ClientsDeposits * _ReserveRatio)
		//&& _ClientsLoans <= ClientsLoansMax()
		&& mismatch == 0)
		return true;
	else
		return false;
}

void CBank::ColectInterests()
{
	assert(CheckBalance());
	assert(_pGeneration->CheckGenerationBalance());

	GoodValue colected = 0;
	for (auto& pair : _ClientsAccounts)
	{
		auto& account = pair.second;

		double rate = account._value > 0 ? _liabilityRate : _assetRate;
		GoodValue interests = account._value
			* rate * (CivData::pCivData->currentTimestep
				- account._initStep) / 12.0;
		account._previousInterests += interests;
		account._initStep = CivData::pCivData->currentTimestep;
		account._endStep = account._initStep;

		AddValToAccount(account, account._previousInterests);

		_InterestsColectedFromClients += -account._previousInterests;
		colected += -account._previousInterests;
		account._previousInterests = 0;

		if (account._value == 0) // Close this account and update the client's
		{
			assert(false);

			account._pTrader->_myBankAccountStatus = CBankEntry(nullptr, 0, 0, 0, true);
			_ClientsAccounts.erase(account._pTrader);
			assert(CheckBalance());
			return;
		}

		account._operationOK = true;

		account._pTrader->_myBankAccountStatus = account;

		assert(_ClientsAccounts[account._pTrader]._value
			== account._pTrader->_myBankAccountStatus._value);
	}
	assert(CheckBalance());
	assert(_pGeneration->CheckGenerationBalance());
}

void CBank::ReturnExcessCashToCB()
{
	assert(_traderType != CentralBank);

	if (Cash() > ((GoodValue)(_ClientsDeposits * _ReserveRatio)))
	{
		// Deposit in CentralBank (and decrease my TotalBullion reserve)

		GoodValue payed = Cash() - ((GoodValue)(_ClientsDeposits * _ReserveRatio));

		CBankEntry loanStatus = _pUsedBank->ClientCashOperation(this, payed);

		if (loanStatus._operationOK) // if balance = 0, account closed
		{
			Cash() -= payed;
			_TotalBullion -= payed;
		}

		_myBankAccountStatus = loanStatus;// smaller or null loan
		assert(CheckBalance());
	}
}

void CBank::TransferProfitToManager()
{
	if (_Manager->_traderType == TheState ||
		_pUsedBank->ClientCurrentBalance(this) < 0)// BullionReserve debt to CentralBank
		return;

	GoodValue keep = max(_MinCash,
		(GoodValue)(_ClientsDeposits * _ReserveRatio));
	GoodValue retProfit = min(Cash() - keep, _InterestsColectedFromClients);

	if (retProfit <= 0)
		return;

	_InterestsColectedFromClients -= retProfit;
	Cash() -= retProfit;

	_Manager->Cash() += retProfit;

	assert(CheckBalance());
	return;
}

GoodValue CBank::ClientCurrentBalance(CTrader* pClient)
{
	if (_ClientsAccounts.find(pClient) == _ClientsAccounts.end())
		return 0;

	auto& account = _ClientsAccounts[pClient];
	double rate = account._value > 0 ? _liabilityRate : _assetRate;

	GoodValue currentBalance = account._value + account._previousInterests
		+ (GoodValue)(account._value * rate * (CivData::pCivData->currentTimestep
			- account._initStep) / 12.0);

	return currentBalance;
}

CBankEntry CBank::ClientCashOperation(CTrader* pClient,
	GoodValue value, int nMonths)
{
	if (value == 0)
	{
		pClient->_myBankAccountStatus._operationOK = true;
		return pClient->_myBankAccountStatus;
	}

	assert(CheckBalance());
	//may not be a complete operation assert(_pGeneration->CheckGenerationBalance());
	// Returns the final account status of Client

	GoodValue withdraw = -value;

	if (withdraw > 0 && !GetReserveForWithdrawal(withdraw))
	{
		pClient->_myBankAccountStatus._operationOK = false;
		return pClient->_myBankAccountStatus;
	}

	// If this is the CentralBank and there are other Banks already
	// redirect new Client to a commercial Bank
	if (this->_traderType == CentralBank && _Banks.size() > 0
		&& _ClientsAccounts.find(pClient) == _ClientsAccounts.end() // new client
		&& pClient->_traderType != Bank)
	{
		pClient->_pUsedBank = getRandomBank();
		CBankEntry accountStatus =
			pClient->_pUsedBank->ClientCashOperation(pClient, value, nMonths);
		return accountStatus;
	}

	// Carry out the operation ------------------------------------------

	Cash() += value;

	if (_ClientsAccounts.find(pClient) == _ClientsAccounts.end()) // new client
	{
		CBankEntry& account = _ClientsAccounts[pClient];
		account._pTrader = pClient;
		account._previousInterests = 0;
		account._value = value;
		account._initStep = CivData::pCivData->currentTimestep;
		account._endStep = CivData::pCivData->currentTimestep + nMonths;
		account._operationOK = true;

		if (value > 0)
			_ClientsDeposits += value;
		else
			_ClientsLoans += (-value);

		assert(CheckBalance());
		return account;
	}
	else // old friend but this is like a new loan plus previous, pending interests
	{
		CBankEntry& account = _ClientsAccounts[pClient];

		assert(account._value == pClient->_myBankAccountStatus._value);

		double rate = account._value > 0 ? _liabilityRate : _assetRate;
		GoodValue interests = account._value
			* rate * (CivData::pCivData->currentTimestep
				- account._initStep) / 12.0;
		account._previousInterests += interests;
		account._initStep = CivData::pCivData->currentTimestep;
		account._endStep = CivData::pCivData->currentTimestep + nMonths;

		AddValToAccount(account, value);

		if (account._value + account._previousInterests == 0) // Close this account
		{
			if (account._value > 0)
				_ClientsDeposits -= account._value;
			else
				_ClientsLoans -= -account._value;

			_InterestsColectedFromClients += -account._previousInterests;

			_ClientsAccounts.erase(pClient);
			assert(CheckBalance());
			return CBankEntry(nullptr, 0, 0, 0, true);
		}

		account._operationOK = true;

		assert(CheckBalance());
		//may not be a complete operation to assert(_pGeneration->CheckGenerationBalance());
		return account;
	}
}

void CBank::AddValToAccount(CBankEntry& account, GoodValue value)
{
	if (account._value >= 0) // it's a Deposit account
	{
		assert(_ClientsDeposits >= account._value);
		if (account._value + value >= 0) // 5 + (-3) = 2 > 0
		{
			account._value += value;
			_ClientsDeposits += value;
		}
		else // 5 + (-9) = -4 change to Loan account
		{
			_ClientsDeposits -= account._value;// remove from Deposits
			account._value += value; // now negative (Loan) acc.
			_ClientsLoans += -account._value;
		}
	}
	else // (account._value < 0)  it's a Loan account
	{
		assert(_ClientsLoans >= -account._value);
		if (account._value + value <= 0) // -5 + (+3) = -2 < 0
		{
			account._value += value;
			_ClientsLoans += -value;
		}
		else // -5 + (+9) = +4 change to Deposit account
		{
			_ClientsLoans -= -account._value;// up to 0
			account._value += value; // now positive (Deposit) acc.
			_ClientsDeposits += account._value;
		}
	}
}

bool CBank::GetReserveForWithdrawal(GoodValue withdraw)
{
	if (withdraw <= 0)
		return true;

	if (Cash() < (GoodValue)(_ClientsDeposits * _ReserveRatio) + withdraw)
	{
		if (this->_traderType == CentralBank)
			return false;// No CentralBank BullionReserve change  
		else // this is a commercial Bank
		{
			GoodValue bullResIncrement =
				(GoodValue)(_ClientsDeposits * _ReserveRatio) + withdraw
				- Cash();

			// this Bank asks the CentralBank for more bullion reserve

			CBankEntry loanStatus = CivData::pCentralBank->
				ClientCashOperation(this, -bullResIncrement,
					10 * CivData::pCivData->stepsPerYear);
			if (loanStatus._operationOK)
			{
				_TotalBullion += bullResIncrement;
				Cash() += bullResIncrement;
				_myBankAccountStatus = loanStatus;
				return true;
			}
			else
			{
				//assert(_pGeneration->CheckGenerationBalance());
				assert(_myBankAccountStatus._value == loanStatus._value);
				assert(CheckBalance());
				return false;// No change 
			}
		}
	}
	else
		return true;
}

GoodValue CBank::ClientsLoansMax()
{
	return _TotalBullion +
		_ClientsDeposits - (GoodValue)(_ClientsDeposits * _ReserveRatio);
}


// $$$$$$$$$$$$$$$    CentralBank only       $$$$$$$$$$$$$$$$$$$$

CBank* CBank::BankFoundationRequest(CIndividual* pIndivManager,
	GoodValue initBullionRes)
{
	assert(this->_ID == CentralBankID);
	if (_Banks.size() >= MaxNBanks
		|| initBullionRes < CivData::pTheState->BanksInitCapital)
		return nullptr;

	GoodID BankID = pIndivManager->_ID;
	// One Individual can only own 1 Bank
	assert(_Banks.find(BankID) == _Banks.end());
	CBank* pBank = new CBank(Bank, pIndivManager);
	_Banks[BankID] = pBank;

	return pBank;
}

CBank* CBank::getRandomBank()
{
	assert(_ID == CentralBankID);

	if (_Banks.size() == 0)
		return this;

	int bankN = _Banks.size() * CivData::pCivData->getRandom01();
	int nn = 0;
	for (auto pair : _Banks)
	{
		if (bankN == nn++)
			return _Banks[pair.first];
	}
	assert(false);
	return nullptr;
}


//======================  CBankEntry  ===================================

CBankEntry::CBankEntry(CTrader* pTrader, GoodValue value,
	int initStep, int endStep, bool ok)
{
	_pTrader = pTrader;
	_value = value;
	_previousInterests = 0;
	_initStep = initStep;
	_endStep = endStep;
	_operationOK = ok;
}

CBankEntry::CBankEntry()
{
	clear();
}

CBankEntry::~CBankEntry()
{
}

void CBankEntry::clear()
{
	_pTrader = nullptr;
	_value = 0;
	_previousInterests = 0;
	_initStep = 0;
	_endStep = 0;
}


//======================  CAccounting  ===================================

CAccountEntry::CAccountEntry(int mnth, GoodValue val, GoodID gId,
	GoodID neighborId, GoodValue qtty)
	: _month(mnth), _money(val), gID(gId), neighID(neighborId), _units(qtty) {};
CAccountEntry::~CAccountEntry() {};

ofstream& operator<<(ofstream& ofstrm, const CAccountEntry& ent)
{
	ofstrm
		<< "\t" << ent._month
		<< "\t" << ent._units
		<< "\t" << ent._money
		<< "\t" << ent.gID
		<< "\t" << ent.neighID;
	//	<< "\t" << CivData::pCivData->GoodID2Name[ent.gID]
	//	<< "\t" << CivData::pCivData->GoodID2Name[ent.neighID];

	return ofstrm;
}

CAccounting::CAccounting() {};
CAccounting::~CAccounting() {};
