
// Individual.cpp

// "Deployers: 
//  The Spontaneous Rise and Development of Economic Systems"

#include "pch.h"

const GoodValue CIndividual::MonthlyFood = 30;
const GoodValue CIndividual::MinFood = 200;

int minInitProductionUnits = 1;// Producers startup

CIndividual::CIndividual(CGeneration* _myGenerat, int indivID)
	: CTrader(indivID == TheStateID ? TheState : Individual, indivID, _myGenerat)
{
	_Alive = true;
	_NoFood = true;
	_HasWorkedCurrentMonth = false;
	_Manager = 0;
	_myPriceAdapt = 0;
	_pOwnedBank = nullptr;
}

CIndividual::~CIndividual()
{
}

// Producers  ---------------------------------------------------------

bool CIndividual::HasActiveProducer()
{
	for (auto gPair : _mProducers)
		if (gPair.second->IsActiveProducer())
			return true;

	return false;
}

// Activity  ---------------------------------------------------------

void CIndividual::MonthlyActivity()
{
	//assert(_pGeneration->CheckGenerationBalance());

	MonthlyFeed();

	ProductsDecay();// Products with lifetime, decay by use

	MakeListOfInteractingIndivsAndProducers();

	MakeListOfGoodsToBuy();

	BuyGoods();

	ReturnLoansToMyBank();// only loans, keep surplus Cash

	TryToFoundCommercialBank();// with surplus Cash

	// Deposit surplus Cash into a Bank
	if (_pUsedBank->ClientCurrentBalance(this) >= 0 && Cash() > 2 * _MinCash)
	{
		CBankEntry currStat =
			_pUsedBank->ClientCashOperation(this, (Cash() - _MinCash));
		GoodValue deposit = currStat._value - _myBankAccountStatus._value;
		Cash() -= deposit;
		_myBankAccountStatus = currStat;
	}

	SellGoodsFromDismantledProducers();

	RemoveUnusedProducers();

	TryToStartupNewProducer();

	// Run my Producers
	for (auto gPair : _mProducers)
	{
		CProducer& Producer = *gPair.second;

		Producer.MonthlyActivity();
		assert(Producer.Cash() >= 0);
	}

	if (_pOwnedBank != nullptr) _pOwnedBank->MonthlyActivity();

	if (_pGeneration->CurrentMonth == 11)
		PayAnnualTax();

	assert(_pGeneration->CheckGenerationBalance());
}

void CIndividual::MonthlyFeed()
{
	if (CivData::pCivData->at(CivData::kMinFoodStockYears) <= 0)
		return;

	_Goods_I_have[food_kg] -= MonthlyFood;

	if (_Goods_I_have[food_kg] > MinFood)
	{
		_NoFood = false;
	}
	else
	{
		_Goods_I_have[food_kg] = MinFood; // keep some seed
		_NoFood = true;

		// _Alive = false;
	}
}

void CIndividual::ProductsDecay()
{
	if (!(*CivData::pCivData).at(CivData::kGoodsDecay))
		return;

	// Products with lifetime, decay by use
	for (auto gPair : _Goods_I_have)
	{
		auto gID = gPair.first;
		if (gID >= CivData::pCivData->first_producerType)
			continue;

		assert(gID != workers_n);

		GoodID producerID = CivData::pCivData->ProducerType_of_this_productID[gID];
		CProducer* pProducer = CivData::pCivData->ProducerPrototypes[producerID];
		int lifetime = pProducer->myProductsData[gID]->lifetimeSteps;
		if (_Goods_I_have(gID) > 0 && lifetime > 0)
		{
			double thisRand = CivData::pCivData->getRandom01();
			if (thisRand * lifetime <= 1.0)
				_Goods_I_have[gID] *= 0.693;
		}
	}
}

void CIndividual::TryToFoundCommercialBank()
{
	GoodValue balance = _pUsedBank->ClientCurrentBalance(this);
	if (_pOwnedBank == nullptr
		&& balance >= 0
		&& Cash() + balance >= CivData::pTheState->BanksInitCapital + _MinCash)
	{
		_pOwnedBank = CivData::pCentralBank->BankFoundationRequest(this,
			CivData::pTheState->BanksInitCapital);

		if (_pOwnedBank != nullptr)
		{
			if (Cash() < CivData::pTheState->BanksInitCapital + _MinCash)
			{
				GoodValue request = CivData::pTheState->BanksInitCapital + _MinCash
					- Cash();
				CBankEntry accountStatus =
					_pUsedBank->ClientCashOperation(this, -request, 10 * CivData::pCivData->stepsPerYear);
				if (accountStatus._operationOK)// if balance = 0, account closed
					Cash() += request;
				_myBankAccountStatus = accountStatus;
			}

			if (Cash() >= CivData::pTheState->BanksInitCapital + _MinCash)
			{
				Cash() -= CivData::pTheState->BanksInitCapital;

				_pOwnedBank->_TotalBullion =
					CivData::pTheState->BanksInitCapital;
				_pOwnedBank->Cash() = _pOwnedBank->_TotalBullion;

				// Try to move my account to my new, owned Bank
				GoodValue currentBalance = _pUsedBank->ClientCurrentBalance(this);
				assert(currentBalance >= 0);
				if (currentBalance > 0)
				{
					CBankEntry accountStatus =
						_pUsedBank->ClientCashOperation(this, -currentBalance, 10 * CivData::pCivData->stepsPerYear);

					if (accountStatus._operationOK
						&& accountStatus._value != _myBankAccountStatus._value)
					{   // OK, nothing left behind
						_pUsedBank = _pOwnedBank; // deposit my currentBalance
						_myBankAccountStatus =
							_pUsedBank->ClientCashOperation(this, currentBalance);
						assert(_myBankAccountStatus._value == currentBalance);
					}
					else // operation failed
					{
						assert(accountStatus._pTrader == _myBankAccountStatus._pTrader);
					}
				}
			}
		}
	}
}

void CIndividual::RemoveUnusedProducers()
{
	// Remove unused Producers

	int MaxUnusedTimestps = CivData::pCivData->at(CivData::kMaxUnusedTimestps);
	auto const copy = _mProducers;
	for (auto gPair : copy)
	{
		CProducer* pProducer = gPair.second;
		if (!pProducer->IsActiveProducer() &&
			(_pGeneration->CurrentTimestep -
				gPair.second->_LastUsedTimestep) > MaxUnusedTimestps)
		{
			CProducer* pProd = TryToDismantleProducer(pProducer);
			if (pProd != nullptr)
				delete pProd;
		}
	}
}

CProducer* CIndividual::TryToDismantleProducer(CProducer* pProd)
{
	/*if (pProd->_producerType == 35)
		(*CivData::pCivData->pOutf) << "dismanteled producerType=" << pProd->_producerType
		<< ", ID= " << pProd->_ID << " at Timestep= " << _pGeneration->CurrentTimestep << endl;
	*/

	GoodValue balance = pProd->_pUsedBank->ClientCurrentBalance(pProd);
	if (balance != 0)
	{
		// close pProd's account: transfer balance to my account
		string concept = "";
		if ((*CivData::pCivData)[CivData::kWriteTransactions]
			&& (pProd->_ID == (*CivData::pCivData)[CivData::kWriteIndivN]
				|| _ID == (*CivData::pCivData)[CivData::kWriteIndivN])
			)
			concept = " transfers " + to_string(balance) + " m.u. to ";

		bool ok = pProd->_pUsedBank->PayThroughBankTransfer(pProd, this, balance, concept);
		if (!ok)
			return nullptr;// balance<0 and one Bank has not enough resources
	}

	if (pProd->Cash() > 0)
	{
		CBankEntry currStat = _pUsedBank->ClientCashOperation(this, pProd->Cash());
		assert(currStat._operationOK);
		_myBankAccountStatus = currStat;
		pProd->Cash() = 0;
	}

	// Set production to zero
	pProd->_Goods_to_be_produced -= pProd->_Goods_to_be_produced;

	// Retrieve Goods and Loans

	for (auto gPair : pProd->_ImmobilizedGoods)
	{
		GoodID gID = gPair.first;
		_Goods_to_sell[gID] += pProd->_ImmobilizedGoods[gID];
		pProd->_ImmobilizedGoods[gID] = 0;

		_myPrice[gID] = pProd->_myPrice[gID];
	}
	pProd->_ImmobilizedGoods.clear();

	for (auto gPair : pProd->_Goods_I_have)
	{
		GoodID gID = gPair.first;
		if (gID == 0)
			continue; // Employees will be released below

		_Goods_to_sell[gID] += pProd->_Goods_I_have[gID];
		pProd->_Goods_I_have[gID] = 0;
		_myPrice[gID] = pProd->_myPrice[gID];
	}
	pProd->_Goods_I_have.clear();

	while (pProd->_vEmployees.size() > 0)
	{
		pProd->_vEmployees.back()->_HasWorkedCurrentMonth = false;
		pProd->ReleaseLastEmployee();
	}

	for (auto product : pProd->myProductsData)
		pProd->clearVariablesOfProductID(product.first);

	pProd->_LastUsedTimestep = 0;
	pProd->_Manager = nullptr;

	_mProducers.erase(pProd->_producerType);

	_Goods_I_have[pProd->_producerType] -= 1;

	return pProd;
}

void CIndividual::TryToStartupNewProducer()
{
	double ProducerAssignmentPer1000 =
		0.001 * CivData::pCivData->at(CivData::kProducerAssignmentPer1000);
	int nProducerPrototypes = (int)CivData::pCivData->ProducerPrototypes.size();
	GoodID firstProducerID = CivData::pCivData->ProducerPrototypes.begin()->first;

	int maxNproducers = 1;

	GoodID producerType = -1;

	switch (CivData::pCivData->at(CivData::kAssignPrototypes))
	{
	case false:

		if (_mProducers.size() >= maxNproducers
			|| CivData::pCivData->getRandom01() > ProducerAssignmentPer1000)
			return;

		do
			producerType = firstProducerID + CivData::pCivData->getRandom01()
			* nProducerPrototypes;
		while (_mProducers.find(producerType) != _mProducers.end());

		break;

	case true:

		if (_mProducers.size() >= 1)
			return;

		producerType = firstProducerID + _ID % nProducerPrototypes;

		break;
	default:
		assert(false);
		break;
	}

	StartupNewProducer(producerType);
}

CProducer* CIndividual::StartupNewProducer(GoodID producerType)
{
	CProducer* pProd =
		new CProducer(*CivData::pCivData->ProducerPrototypes[producerType]);
	pProd->_ID = _pGeneration->MaxPopulation + this->_ID;
	pProd->_Manager = this;

	pProd->_InitCapital =
		minInitProductionUnits * pProd->StartupProducerPrice(this);

	pProd->_pUsedBank = CivData::pCentralBank->getRandomBank();
	pProd->_NoFirstDemandYet = true;
	pProd->_MinCash = 0;

	for (auto pair : pProd->myProductsData)
	{
		CProductData& prodDat = *pair.second;

		auto mNC = prodDat.nonConsumedPerUnit;
		for (auto gNC = mNC.begin(); gNC != mNC.end(); ++gNC)
		{
			GoodID gID = gNC->first;
			if (_Goods_to_sell.find(gID) != _Goods_to_sell.end()
				&& _Goods_to_sell[gID] > 0)
			{
				pProd->_Goods_I_have[gID] += _Goods_to_sell[gID];
				_Goods_to_sell[gID] = 0;
			}
		}

		auto mC = prodDat.consumedPerUnit;
		for (auto gNC = mC.begin(); gNC != mC.end(); ++gNC)
		{
			GoodID gID = gNC->first;
			if (_Goods_to_sell.find(gID) != _Goods_to_sell.end()
				&& _Goods_to_sell[gID] > 0)
			{
				pProd->_Goods_I_have[gID] += _Goods_to_sell[gID];
				_Goods_to_sell[gID] = 0;
			}
		}
	}

	// Start inactivity time counter
	pProd->_LastUsedTimestep = _pGeneration->CurrentTimestep;

	_mProducers[pProd->_producerType] = pProd;
	_Goods_I_have[pProd->_producerType] += 1;

	return pProd;
}

void CIndividual::SellGoodsFromDismantledProducers()
{
	for (auto goodPair : _Goods_to_sell)
	{
		CGood good = goodPair.second;
		if (good._ID == workers_n || good.quantity() <= 0)
			continue;
		for (auto nNei : _InteractingTraders)
		{
			auto& neighbor = *nNei.second;

			TradeGoodWithNeighbor(neighbor, good, MarketOperation::sell);
		}
	}
}

double CIndividual::getScore()
{
	if (!_Alive)
		return 0;

	GoodID scoredgty = GoodID((int)CivData::pCivData->at(CivData::kScoreGoodID));
	double myScore = this->_Goods_I_have(scoredgty);

	// GA scores cannot be negative
	myScore = myScore < 0 ? 0 : myScore;
	return myScore;
}

// =================================================================================
