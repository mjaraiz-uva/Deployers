#pragma once

#include "GlgClass.h"

class CCivilization;
class CivInterface : public GlgObjectC
{
	int previousSelectedIndiv;

public:
	int _lineWidth;

	CivInterface();
	virtual ~CivInterface(void);

	// Input callback.
	virtual void Input(GlgObjectC& callback_viewport, GlgObjectC& message);

	void LoadParametersButton();
	void ReadInputInterface();
	void RunButton();
	void InitializeDrawing(void);

	void Trace(GlgObjectC& callback_viewport, GlgTraceCBStruct* trace_data);

	void plotIndivPlusProdPlusBankFinalValues();
	void plotBanksFinalTotalValues();
	void plotProducersTotalValues();
	void plotIndividualsTotalValues();

	void plotAggregates();
    void plotMarketPrices();
	void plotTotalHomeGoods();

	void plotCentralBankValues();
	void plotTotalCash();

	void plotTheStateValues();
	void plotTheStateGoods();

	void plotBankValues();
	void plotProducerValues();
	void plotIndivHomeGoods();
	void plotCurrentIndividual();
	void plotIndividualValues();

	void SetSize(GlgLong x, GlgLong y, GlgLong width, GlgLong height);

	CCivilization* pCivilization;
	bool OutputDataValid;
};

