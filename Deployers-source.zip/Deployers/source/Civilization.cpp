
// Civilization.cpp

// "Deployers: 
//  The Spontaneous Rise and Development of Economic Systems"

#include "pch.h"
#include "GARealGenome.cpp"

//=========================================================

float myObjective(GAGenome& g)
{
	float generationValue = 0;
	GARealGenome& genome = (GARealGenome&)g;
	const GAPopulation& p = (genome.geneticAlgorithm()->Population());
	CGeneration** ppCurrentGeneration = (CGeneration**)genome.userData();

	// copy GA Genes to simulator
	for (int ii = 0; ii < (*ppCurrentGeneration)->nIndividuals; ii++)
	{
		unsigned int ngn = 0;
		for (int gID = 0; gID < CivData::pCivData->GoodID2Name.size(); ++gID)
		{
			float geneVal = ((GARealGenome&)p.individual(ii)).gene(ngn);
			/*(*ppCurrentGeneration)->at(ii).setGoods_I_wish(gID], geneVal);
			(*ppCurrentGeneration)->at(ii)._myPrice[gID] = geneVal;
			(*ppCurrentGeneration)->at(ii)._myPriceAdapt = geneVal;*/
			++ngn;
		}
	}

	// evaluate this Generation
	(*ppCurrentGeneration)->runGeneration();

	// copy Values to Scores for each individual:
	for (int indivN = 0; indivN < (*ppCurrentGeneration)->nIndividuals; indivN++)
	{
		float val = float(((*ppCurrentGeneration)->vpIndividuals)[indivN]->getScore());
		p.individual(indivN).score(val);//it also sets its Evaluated flag
		generationValue += val;
	}

	//float myWorst = p.worst().score();
	float myBest = p.best().score();
	//return generationValue;
	return myBest;
}

//=========================================================

CCivilization::CCivilization(CivInterface* pCivInterf)
	: pCurrentGeneration(0)
{
	CivData::pCivData->pInterface = pCivInterf;
}

CCivilization::~CCivilization()
{
	delete CivData::pCivData->pCivilizationData;
};

void CCivilization::runCivilization()
{
	int nIndividuals = (int)CivData::pCivData->at(CivData::kIndividuals);
	int nYears = (int)CivData::pCivData->at(CivData::kYears);
	int nMonths = 12;
	int nTimesteps = nYears * nMonths;

	string str;// copy input file to output file
	ifstream infile(CivData::pCivData->InputFileName);
	CivData::pCivData->pOutf->close();
	CivData::pCivData->pOutf->open(CivData::pCivData->OutputFileName);
	while (getline(infile, str))
	{
		(*CivData::pCivData->pOutf) << str << endl;
	}
	(*CivData::pCivData->pOutf).flush();
	infile.close();

	delete CivData::pCivData->pCivilizationData;
	CivData::pCivData->pCivilizationData = new CCivilizationData();

	GARealAlleleSetArray myalleles;
	// define each Gene range    for (auto grp : GeneGroupTypes) 
	for (int gID = 0; gID < CivData::pCivData->GoodID2Name.size(); ++gID)
	{
		myalleles.add((float)0.0, (float)1.0);

		/*myalleles.add((float)CivData::pCivData->GenesMin[stock][gID],
			(float)CivData::pCivData->GenesMax[stock][gID]);
		myalleles.add((float)CivData::pCivData->GenesMin[price][gID],
			(float)CivData::pCivData->GenesMax[price][gID]);
		myalleles.add((float)CivData::pCivData->GenesMin[priceadapt][gID],
			(float)CivData::pCivData->GenesMax[priceadapt][gID]);*/
	}

	GARealGenome genome(myalleles, myObjective);
	genome.userData((void*)(&pCurrentGeneration));// address of pointer

	GASimpleGA ga(genome);
	ga.maximize();		// We want to maximize the Individuals' Scores
	//ga.scaling(scale);		// specialize the scaling method to our sharing?
	ga.PopulationSize(nIndividuals);
	ga.nGenerations((unsigned int)CivData::pCivData->at(CivData::kGenerations) - 1);// minus initial
	ga.pCrossover(0.9);		// likelihood of crossing over parents
	ga.pMutation((float)CivData::pCivData->at(CivData::kMutationPER1000) / 1000);// mutating new offspring
	ga.elitist(gaTrue);//if(oldPop.best > Pop.best) replace Pop.worst = oldPop.best
	ga.scoreFrequency(1);		// keep the scores of every generation
	ga.selectScores(GAStatistics::AllScores);
	// ga.scoreFilename("GAscore.txt");
	ga.flushFrequency(1);	// specify how often to write the score to disk
	ga.objectiveFunction(myObjective);
	//ga.parameters(arc, arv, gaTrue); // parse commands, complain if bogus args

	//========================    run Generations   =============================

	int generationN = 0;
	CivData::pCivData->currentGenerationN = generationN;
	delete pCurrentGeneration;
	pCurrentGeneration = new CGeneration();
	// When you specify a random seed>0, the evolution will be exactly the same each time
	// you use that seed number.
	unsigned int seed = 12345;
	GAResetRNG(seed);// Similar to setting the random seed, but this one sets it 
					  //as long as the specified seed is non-zero.

	ga.initialize(seed);// generate and evaluate init Population

	while (!ga.done())
	{
		++generationN;
		CivData::pCivData->currentGenerationN = generationN;
		delete pCurrentGeneration;
		pCurrentGeneration = new CGeneration();
		ga.step(); // step <=> Generation

		if (!pCurrentGeneration->evaluated)
		{// ga.step() skipped this Generation, copy Data from previous one
			assert(generationN > 0);
			CivData::pCivData->pCivilizationData->at(generationN)
				= CivData::pCivData->pCivilizationData->at(generationN - 1);
		}
	}
}

//===============================================================
