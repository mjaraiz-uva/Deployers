
// Generation.h

// "Evolved Civilizations: 
//  The Spontaneous Birth and Development of Economic Systems"

#pragma once

#include "pch.h"
#include <fstream>
#include <iomanip>
#include <random>

class CGeneration : public vector<CIndividual> {
private:
	vector<unsigned int> getRandomList();

public:
	int nIndividuals;
	int yearsPerGeneration;
	CInParam* pInParam;

	// OptParams: UWantFactor,
	//            GStock[Grain], GStock[Land],
	//            GProductivity[Grain], GProductivity[Land]
	//            Indiv's Value
	//typedef array<Gene, NOptParams> COptParams;// includes Value
	//typedef vector<COptParams> CPopulationOptParams;
	CPopulationOptParams myPopOptParams;

	CGeneration();
	void initialize(CInParam* myInParam);
	~CGeneration();
	double runLifetime();
};

