//  Producers.h

// "Evolved Civilizations: 
//  The Spontaneous Birth and Development of Economic Systems"

#pragma once
#include "Goods.h"
#include <vector>

//=========================================================

class CProducer {
protected:
	CProducer(GoodType myProdTy)
		: myProductType(myProdTy)
	{
	}
public:
	CGoods myGoods;
	const GoodType myProductType;
	const CGoods& Goods();

	virtual CGoods produce(CGoods gIn);
};

//=========================================================

class CNature : public CProducer {
public:
	const double rate;

	CNature(double r, GoodType myProdTy);
};

//=========================================================

class CWildLand : public CNature {
public:

	CWildLand(double HasPERday);
	~CWildLand();
	CGoods produce(CGoods gIn);
};

//=========================================================

class CFarmland : public CProducer {
	const double DaysPERHa, SeedPERHa, Prod_rate;
public:
	CFarmland(double has, double daysPERHa,
		double KgPERHa, double productPERseed);
	~CFarmland();
	virtual CGoods produce(CGoods gIn);
};

ostream& operator<<(ostream& os, const CFarmland& arg);
ostream& operator<<(ostream& os, const CProducer& arg);
//=========================================================

class CProducers : public vector<CProducer *> {
};

ostream& operator<<(ostream& os, const CProducers& arg);

//=========================================================
