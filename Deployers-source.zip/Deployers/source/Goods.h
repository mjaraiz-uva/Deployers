// Goods.h

// "Evolved Civilizations: 
//  The Spontaneous Birth and Development of Economic Systems"

#pragma once

#include <iostream>
#include <array>
#include <map>
#include <string>

using namespace std;

const int NGoodTypes = 3;

// Genes: 
//GStock[NGoodTypes], GProductivity[NGoodTypes]
const int NGeneTypes = 7;

const int NOptParams = NGeneTypes + 1;//Last parameter: Indiviual's Value

//=========================================================
typedef int GoodType;
const GoodType GrainType = 0;
const GoodType LandType = 1;
const GoodType WorkType = 2;

typedef string GoodName;
const GoodName Grain = "Grain";
const GoodName Land = "Land";
const GoodName Work = "Work";

const array<GoodType, NGoodTypes> GoodTypes = { GrainType, LandType, WorkType };
const GoodName GoodNames[NGoodTypes] = { Grain, Land, Work };

const map<GoodName, GoodType> GoodName2Type =
{ {Grain, GrainType}, {Land, LandType}, {Work, WorkType} };

class CGood : public pair<GoodType, double>
{
public:
	const GoodName name;
	CGood(GoodType t, double v = 0);
	CGood(GoodName n, double v = 0);
	CGood& operator=(CGood g);
	CGood operator+(CGood g);
	CGood& operator+=(CGood g);
};

ostream& operator<< (ostream& os, const CGood & arg);
//=========================================================

class CGoods : public map<GoodType, double>
{
public:
	CGoods();
	~CGoods();
	CGoods operator+(CGoods g);
	CGoods& operator+=(CGoods g);
};

ostream& operator<< (ostream& os, const CGoods & arg);
//=========================================================

