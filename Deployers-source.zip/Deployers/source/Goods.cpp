// Goods.cpp

// "Deployers: 
//  The Spontaneous Rise and Development of Economic Systems"

#include "pch.h"

//=========================================================

CGood::CGood(GoodID gID, GoodValue q)
{
	assert(gID < CivData::pCivData->NGoodIDs);

	_ID = gID;
	_name = CivData::pCivData->GoodID2Name[gID];
	_quantity = q;
}

CGood::CGood(string nam, GoodValue q)
{
	auto result = CivData::pCivData->GoodName2ID.find(nam);
	if (result != CivData::pCivData->GoodName2ID.end())
		_ID = result->second;
	else
		assert(false); // invalid name

	_name = nam;
	_quantity = q;
}

CGood::CGood(const CGood& cg)
{
	_name = cg._name;
	_ID = cg._ID;
	_quantity = cg._quantity;
}

const GoodValue CGood::quantity() const 
{
	return _quantity;
}

bool CGood::operator==(const CGood& g) const
{
	return (_ID == g._ID && _quantity == g._quantity);
}
bool CGood::operator!=(const CGood& g) const
{
	return !((*this) == g);
}
bool CGood::operator>(const CGood& g) const
{
	return (_ID == g._ID && _quantity > g._quantity);
}
bool CGood::operator<(const CGood& g) const
{
	return (_ID == g._ID && _quantity < g._quantity);
}
bool CGood::operator>=(const CGood& g) const
{
	return (_ID == g._ID && _quantity >= g._quantity);
}
bool CGood::operator<=(const CGood& g) const
{
	return (_ID == g._ID && _quantity <= g._quantity);
}
CGood& CGood::operator=(const CGood& g)
{
	if (_ID == g._ID)
		_quantity = g._quantity;
	else
		assert(false);

	return *this;
}
CGood& CGood::operator+(const CGood& g) const
{
	CGood* ret = new CGood(_name, 0);
	if (_ID == g._ID)
		ret->_quantity = _quantity + g._quantity;
	else
		assert(false);

	return *ret;
}
CGood& CGood::operator+=(const CGood& g)
{
	if (_ID == g._ID)
		_quantity += g._quantity;
	else
		assert(false);

	return *this;
}
CGood& CGood::operator-(const CGood& g) const
{
	CGood& ret = *new CGood(_name, 0);
	if (_ID == g._ID)
		ret._quantity = _quantity - g._quantity;
	else
		assert(false);

	return ret;
}
CGood& CGood::operator-=(const CGood& g)
{
	if (_ID == g._ID)
		_quantity -= g._quantity;
	else
		assert(false);

	return *this;
}
CGood& CGood::operator=(GoodValue d)
{
	_quantity = d;

	return *this;
}
CGood& CGood::operator*(double d) const
{
	CGood* ret = new CGood(_name, 0);
	ret->_quantity = _quantity * d;
	return *ret;
}
CGood& CGood::operator/(double d) const
{
	CGood* ret = new CGood(_name, 0);
	(*ret)._quantity = _quantity / d;
	return *ret;
}
CGood& CGood::operator+(GoodValue d) const
{
	CGood* ret = new CGood(_name, 0);
	(*ret)._quantity = _quantity + d;
	return *ret;
}
CGood& CGood::operator-(GoodValue d) const
{
	CGood* ret = new CGood(_name, 0);
	(*ret)._quantity = _quantity - d;
	return *ret;
}

bool CGood::operator==(GoodValue d) const
{
	return (_quantity == d);
}

bool CGood::operator!=(GoodValue d) const
{
	return (_quantity != d);
}

bool CGood::operator>(GoodValue d) const
{
	return (_quantity > d);
}

bool CGood::operator>=(GoodValue d) const
{
	return (_quantity >= d);
}

bool CGood::operator<(GoodValue d) const
{
	return (_quantity < d);
}

bool CGood::operator<=(GoodValue d) const
{
	return (_quantity <= d);
}

CGood& CGood::operator*=(double d)
{
	_quantity *= d;
	return *this;
}
CGood& CGood::operator/=(double d)
{
	_quantity /= d;
	return *this;
}
CGood& CGood::operator+=(GoodValue d)
{
	_quantity += d;
	return *this;
}
CGood& CGood::operator-=(GoodValue d)
{
	_quantity -= d;
	return *this;
}

CGood& operator*(double d, CGood g)
{
	CGood* ret = new CGood(g._name, 0);
	ret->_quantity = g._quantity * d;
	return *ret;
}

//==================   CGoods   ===========================


CGoods::CGoods() {

}
CGoods::~CGoods() {

}

/*

for (auto gID : GoodIDs) {};// examples of loops
for (auto gnm : vGoodNames) {};

examples of CGood usage:

CGood gm("Wood", 2.5), gm1("Land"), food_kg("Grain", 1234.5);
gm1 = (2 * gm1 * 4 + 8) / 2;
gm = 3.45;
CGood Wood0("Wood", 1.5), Wood1("Wood", 0.5);

examples of CGoods usage:

indiv.GoodsAtHome("Grain") = 700;
indiv.GoodsAtHome(food_kg) += 750;
*/

CGood& CGoods::operator[](GoodID gID)
{
	auto result = find(gID);
	if (result != end())
		return result->second;
	else
	{
		// this is a Good type not included in GoodsAtHome yet
		CGood g = CGood(gID,0);
		this->insert(pair<GoodID, CGood>(gID, g));

		return (*this).at(gID);
	}
}

GoodValue CGoods::operator()(GoodID gID)
{
	if (this->find(gID) == end())
		return 0;
	else
		return (*this)[gID].quantity();
}

CGoods& CGoods::operator=(const CGoods& cgds)
{
	for (auto cgd : cgds)
		(*this)[cgd.first] = cgd.second;

	return *this;
}

CGoods& CGoods::operator+(const CGoods& cgds) const
{
	CGoods* ret = new CGoods();
	for (auto cgd : cgds)
		(*ret)[cgd.first] = (*this).at(cgd.first) + cgd.second;

	return *ret;
}

CGoods& CGoods::operator+=(const CGoods& cgds)
{
	for (auto cgd : cgds)
		(*this)[cgd.first] += cgd.second;

	return *this;
}

CGoods& CGoods::operator+=(const CGood& cgd)
{
	((*this)[cgd._ID])._quantity += cgd._quantity;

	return *this;
}

CGoods& CGoods::operator-(const CGoods& cgds) const
{
	CGoods* ret = new CGoods();
	for (auto cgd : cgds)
		(*ret)[cgd.first] = (*this).at(cgd.first) - cgd.second;

	return *ret;
}

CGoods& CGoods::operator-=(const CGoods& cgds)
{
	for (auto cgd : cgds)
		(*this)[cgd.first] -= cgd.second;

	return *this;
}
