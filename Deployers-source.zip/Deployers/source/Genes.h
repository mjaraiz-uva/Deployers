// Genes.h

// "Evolved Civilizations: 
//  The Spontaneous Birth and Development of Economic Systems"

#pragma once
#include "Goods.h"

//=========================================================

typedef double Gene;

//=========================================================

class CGenes
{
public:
	array<Gene, NGoodTypes> GStock;
	array<Gene, NGoodTypes> GProductivity;
	CGenes();
	void initialize();
	CGenes & operator=(CGenes gn);
};

ostream& operator<< (ostream& os, const CGenes & arg);

//=========================================================
