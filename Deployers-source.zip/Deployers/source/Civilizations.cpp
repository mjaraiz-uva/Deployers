
// CivInterface.cpp

// "Evolved Civilizations: 
//  The Spontaneous Birth and Development of Economic Systems"

#include "Civilization.h"
#include "CivInterface.h"
#include "GlgMain.h"
#include <math.h>

GlgAppContext AppContext;

// Main Entry point.

int GlgMain( int argc, char *argv[], GlgAppContext InitAppContext )
{
   GlgSessionC glg_session( False, InitAppContext, argc, argv );
 
   CInParam myInParam;
   CCivilization myCivilization(&myInParam);
   CivInterface Civ_Interface(&myCivilization);

   AppContext = glg_session.GetAppContext();

   Civ_Interface.LoadWidget( "CivInterface.g" );

   Civ_Interface.SetSize( 1600, 750, 900, 700 );// (Xleft,Ytop, width,hight)

   // Setting window title. */
   Civ_Interface.SetResource( "ScreenName", "Evolved Civilizations" );

   // Enable input callback before hierarchy definition
   Civ_Interface.EnableCallback( GLG_INPUT_CB );
 
   // Set initial drawing parameters.
   Civ_Interface.InitializeDrawing();

   /* Start periodic dynamic updates. */
   Civ_Interface.StartUpdates();
   return (int) GlgMainLoop( AppContext );
}

