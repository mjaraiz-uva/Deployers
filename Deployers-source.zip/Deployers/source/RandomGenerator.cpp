// RandomGenerator.cpp: implementation of the RandomGenerator class.
// Return random numbers between 0 and 1

//#include "StdAfx.h"
//#include "RandomGenerator.h"
//#include <cmath>

#include "pch.h"

/*RandomGenerator::RandomGenerator(unsigned int seed1, unsigned int seed2) : sqrt1_2(sqrt(.5))
{
   ChangeSeed(seed1,seed2);
}

//-------------------------------------------------------------------
//

void RandomGenerator::ChangeSeed(unsigned int seed1, unsigned int seed2)
{
   
   unsigned int ii, jj;
   unsigned int i,j,k,l,m;
   double s, t;
   
   if((seed1>31328)||(seed2>30081))
   {
       (*CivData::pCivData->pOutf) << 
       "The first seed must have a value between 0 and 31328\n"
        << "and the second must be between 0 and 30081" << endl;
   }
   
   i=((seed1/177)%177)+2;
   j=(seed1%177)+2;
   k=((seed2/169)%178)+1;
   l=seed2%169;
   for(ii=1;ii<=97;ii++)
   {
      s=0.0;
      t=0.5;
      for(jj=1;jj<=24;jj++)
      {
         m=(((i*j)%179)*k)%179;
         i=j;
         j=k;
         k=m;
         l=(53*l+1)%169;
         if(((l*m)%64)>=32)
            s+=t;
         t*=0.5;
      }
      u[ii]=s;
   }

  c=362436.0/16777216.0;
  cd=7654321.0/16777216.0;
  cm=16777213.0/16777216.0;

  i97=97;
  j97=33;
}

//-------------------------------------------------------------------
// Some improvements for speed in C language.

float RandomGenerator::Rand()
{ 
  double uni;

  uni=u[i97]-u[j97];
  if(uni < 0.0)
    uni++;
  u[i97--]=uni;
  if(i97==0)
    i97=97;
  if(--j97==0)
    j97=97;
  c-=cd;
  if(c<0.0)
    c+=cm;
  uni-=c;
  if(uni<0.0)
    uni++;
  return(uni);
}

//-------------------------------------------------------------------
// Return a number between 0 and n. n isn't included.

unsigned int RandomGenerator::RandInt(int n)
{
   unsigned int nRet = (unsigned int)(Rand()*n);
   return nRet;
}*/
