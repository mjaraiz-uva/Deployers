
// CInParam.h

#pragma once

#include <map>
#include <vector>
#include <iostream>
#include <fstream>
#include <string>
#include "Goods.h"
#include "Genes.h"

using namespace std;

//*************************  Optimization Parameters  *****************************
// OptParams: UWantFactor,
//            GStock[Grain], GStock[Land],
//            GProductivity[Grain], GProductivity[Land]
//            Indiv's Value
typedef array<double, NOptParams> COptParams;// includes Value
typedef vector<COptParams> CPopulationOptParams;// see runLifetime
//*****************************************************************************

class CInParam : public map<string, double>
{
public:
	// OptParams ranges:
	COptParams MaxOptParams;
	COptParams MinOptParams;

	string inFileName;
	ofstream* pOutf;

	static string // keywords
		kIndividuals, kYearsPerGeneration,kGenerations, 
		kPrintLevel, kMarket,
		kMutation,
		kUWantFactor_Min,
		kUWantFactor_Max,
		kGStock_Grain_Max,
		kGStock_Grain_Min,
		kGStock_Land_Max,
		kGStock_Land_Min,
		kGStock_Work_Max,
		kGStock_Work_Min,
		kGProd_Grain_Max,
		kGProd_Grain_Min,
		kGProd_Land_Max,
		kGProd_Land_Min,
		kGProd_Work_Max,
		kGProd_Work_Min;

	CInParam();
	CInParam& readFile(string inFileName);
};