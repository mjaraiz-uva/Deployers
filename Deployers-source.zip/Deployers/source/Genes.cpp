// Genes.cpp

// "Evolved Civilizations: 
//  The Spontaneous Birth and Development of Economic Systems"

#include "pch.h"

//=========================================================

CGenes::CGenes()
{
	/* for (int gty = 0; gty < vGoodNames.size(); ++gty)
	{
		(*this)[stock][gty] = 0;// GStockDist(random);
		(*this)[price][gty] = 0;// GPriceDist(random);
	}
	initialize();*/
};

void CGenes::initialize()
{
	for (int gty = 0; gty < CivData::pCivData->v_GoodNames.size(); ++gty)
	{
		(*this)[stock][gty] = 0;// GStockDist(random);
		(*this)[price][gty] = 0;// GPriceDist(random);
	}
}
string CGenes::GeneName(GeneType gnty)
{
	int group = gnty / NGoodTypes;
	int gdty = gnty % NGoodTypes;
	string name = GeneGroupType2Name[group] + CivData::pCivData->v_GoodNames[gdty];
	return name;
}

GeneGroupType CGenes::getGeneGroupType(GeneType gnty)
{
	return GeneGroupType(gnty / NGoodTypes);
}

GoodType CGenes::getGeneGoodType(GeneType gnty)
{
	return GoodType(gnty % NGoodTypes);
}

CGenes& CGenes::operator=(CGenes gn)
{
	for (int gty = 0; gty < CivData::pCivData->v_GoodNames.size(); ++gty)
	{
		(*this)[stock][gty] = gn[stock][gty];
		(*this)[price][gty] = gn[price][gty];
	}
	return *this;
};

ostream& operator<< (ostream& os, const CGenes& arg)
{
	os << "Genes(";
	for (int gty = 0; gty < CivData::pCivData->v_GoodNames.size(); ++gty)
		os << arg[stock][gty] << " ";
	os << " ; ";
	for (int gty = 0; gty < CivData::pCivData->v_GoodNames.size(); ++gty)
		os << arg[price][gty] << " ";
	os << ")";

	return os;
};

//=========================================================
