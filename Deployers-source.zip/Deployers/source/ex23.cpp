/* ----------------------------------------------------------------------------
  ex23.C
  mbwall 5jan96
  Copyright (c) 1995-1996  Massachusetts Institute of Technology

 DESCRIPTION:
   This example shows how to use max/min feature of GAlib to maximize or 
minimize your objective functions.
---------------------------------------------------------------------------- */
//#include "pch.h"
#include <stdio.h>
#include <math.h>

#include "ga.h"
#include "GAArray.h"
#include "GAAllele.h"
#include "GARealGenome.h"

#include "Genes.h"

#define STD_IOS_IN      ios::in
#define STD_IOS_OUT     ios::out
#define STD_IOS_TRUNC   ios::trunc


#ifndef M_PI
#define M_PI            3.14159265358979323846
#endif

#define MIN_VALUE -2
#define MAX_VALUE 2
#define INC       0.005

// This objective tries to maximize each element in the genome.

float Objective4(GAGenome& g)
{
	GARealGenome& genome = (GARealGenome&)g;
	float value = 0.0;
	for (int i = 0; i < genome.length(); i++)
		value += genome.gene(i);
	return value;
}

// Genes: UWantFactor,
//        GStock[Grain], GStock[Land],
//        GProductivity[Grain], GProductivity[Land]
// typedef array<Gene, 5> CGenome;
// typedef vector<CGenome> CPopulationGenes;
void getNextPopulationGenes(CPopulationGenes& myPop, CGenome minG, CGenome maxG)
{
	int nIndiv = myPop.size();

	GARealAlleleSetArray alleles;
	for (unsigned int i=0; i < minG.size(); i++)
		alleles.add(minG.at(i), maxG.at(i));
	GARealGenome genome(alleles, Objective4);

	GASimpleGA ga(genome);
	ga.maximize();		// by default we want to maximize the objective
	//ga.scaling(scale);		// set the scaling method to our sharing
	ga.PopulationSize(myPop.size());	// how many individuals in the Population
	ga.nGenerations(25);		// number of generations to evolve
	ga.pMutation(0.001);		// likelihood of mutating new offspring
	ga.pCrossover(0.9);		// likelihood of crossing over parents
	ga.scoreFilename("bog.dat");	// name of file for scores
	ga.scoreFrequency(1);		// keep the scores of every generation
	ga.flushFrequency(10);	// specify how often to write the score to disk
	ga.selectScores(GAStatistics::AllScores);
	//ga.parameters(arc, arv, gaTrue); // parse commands, complain if bogus args

	ga.initialize();

	// dump the initial Population to file

	ofstream outfile;

	cout << "printing initial Population to file..." << endl;
	outfile.open("_initPopulation.txt");
	for(int ii=0; ii<ga.Population().size(); ii++){
		genome = ga.Population().individual(ii);
		outfile << genome.gene(0) << "\t\t" << genome.score() << "\n";
	}
	outfile.close();

	while(!ga.done()) ga.step();

	// dump the final Population to file

	cout << "printing final Population to file..." << endl;
	outfile.open("_finalPopulation.txt");
	for(int i=0; i<ga.Population().size(); i++){
		genome = ga.Population().individual(i);
		outfile << genome.gene(0) << "\t" << genome.score() << "\n";
	}
	outfile.close();

	// dump the function to file so you can plot the Population on it
	/*
	cout << "printing function to file..." << endl;
	outfile.open("_gene0.txt", (STD_IOS_OUT | STD_IOS_TRUNC));
	for(float x=MIN_VALUE; x<=MAX_VALUE; x+=INC){
		outfile << genome.gene(0,x) << "\t" << genome.score() << "\n";
	}
	outfile.close();
	*/
};
//===============================================================

float Objective(GAGenome&);
float Comparator(const GAGenome&, const GAGenome&);

int ex23(int arc, char **arv)
//main(int argc, char **argv)
{
  cout << "Example 23\n\n";
  cout << "This program tries to maximize or minimize, depending on the\n";
  cout << "command line argument that you give it.  Use the command-line\n";
  cout << "argument 'mm -1' to minimize (the default for this example), or\n";
  cout << "'mm 1' to maximize.  The objective function is a simple \n";
  cout << "sinusoidal.\n\n"; cout.flush();

// See if we've been given a seed to use (for testing purposes).  When you
// specify a random seed, the evolution will be exactly the same each time
// you use that seed number.

  for(int jj=1; jj<arc; jj++) {
    if(strcmp(arv[jj++],"seed") == 0) {
      GARandomSeed((unsigned int)atoi(arv[jj]));
    }
  }

  ofstream outfile;

  GARealAlleleSet alleles(MIN_VALUE, MAX_VALUE); 
  GARealGenome genome(1, alleles, Objective);
  GASharing scale(Comparator);

  GASimpleGA ga(genome);
  ga.minimize();		// by default we want to minimize the objective
  ga.scaling(scale);		// set the scaling method to our sharing
  ga.PopulationSize(50);	// how many individuals in the Population
  ga.nGenerations(25);		// number of generations to evolve
  ga.pMutation(0.001);		// likelihood of mutating new offspring
  ga.pCrossover(0.9);		// likelihood of crossing over parents
  ga.scoreFilename("bog.dat");	// name of file for scores
  ga.scoreFrequency(1);		// keep the scores of every generation
  ga.flushFrequency(10);	// specify how often to write the score to disk
  ga.selectScores(GAStatistics::AllScores);
  ga.parameters(arc, arv, gaTrue); // parse commands, complain if bogus args

  ga.initialize();

// dump the initial Population to file

  cout << "printing initial Population to file..." << endl;
  outfile.open("popi.dat", (STD_IOS_OUT | STD_IOS_TRUNC));
  for(int ii=0; ii<ga.Population().size(); ii++){
    genome = ga.Population().individual(ii);
    outfile << genome.gene(0) << "\t\t" << genome.score() << "\n";
  }
  outfile.close();

  while(!ga.done()) ga.step();

// dump the final Population to file

  cout << "printing final Population to file..." << endl;
  outfile.open("popf.dat", (STD_IOS_OUT | STD_IOS_TRUNC));
  for(int i=0; i<ga.Population().size(); i++){
    genome = ga.Population().individual(i);
    outfile << genome.gene(0) << "\t" << genome.score() << "\n";
  }
  outfile.close();

// dump the function to file so you can plot the Population on it

  cout << "printing function to file..." << endl;
  outfile.open("sinusoid.dat", (STD_IOS_OUT | STD_IOS_TRUNC));
  for(float x=MIN_VALUE; x<=MAX_VALUE; x+=INC){
    outfile << genome.gene(0,x) << "\t" << genome.score() << "\n";
  }
  outfile.close();
  return 0;
}
 
// This objective function returns the sin of the value in the genome.
float
Objective(GAGenome& g) {
  GARealGenome& genome = (GARealGenome &)g;
  return 1 + sin((double)genome.gene(0)*2*M_PI); 
}
// The comparator returns a number in the interval [0,1] where 0 means that
// the two genomes are identical (zero diversity) and 1 means they are 
// completely different (maximum diversity).
float
Comparator(const GAGenome& g1, const GAGenome& g2) {
 GARealGenome& a = (GARealGenome &)g1;
  GARealGenome& b = (GARealGenome &)g2;
  return exp( -((double)a.gene(0) - (double)b.gene(0)) * (double)(a.gene(0) - (double)b.gene(0)) / 1000.0);
}
