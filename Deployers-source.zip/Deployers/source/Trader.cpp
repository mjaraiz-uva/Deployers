
//  Trader.cpp

#include "pch.h"

vector< pair<unsigned int, CTrader*> > CTrader::_InteractingTraders;
vector< pair<unsigned int, CTrader*> > CTrader::_InteractingWorkers;

//======================  CTrader  ===================================

CTrader::CTrader(GoodID traderType, GoodID id, CGeneration* _pGenerat)
	: _traderType(traderType), _ID(id), _pGeneration(_pGenerat)
{
	_pUsedBank = nullptr;
	_myBankAccountStatus.clear();
	_HasWorkedCurrentMonth = false;
	_Manager = nullptr;
	_MinCash = 0;
	Cash() = 0;
	_myPriceAdapt = 1.2;
	_TotalAssetsPreviousYear = 0;
}

CTrader::~CTrader()
{
}

bool CTrader::IsIndividual()
{
	return _traderType == Individual;
}

void CTrader::MakeListOfInteractingIndivsAndProducers()
{
	// Get a random list of this month's interacting Traders
	// (TheState or Indiv or Producer)

	int nNeighbors = _pGeneration->nMaxInteractingNeighbors;

	vector<unsigned int> randomIndivN =
		_pGeneration->getRandomListOfIndividual_IDs(nNeighbors);

	if (nNeighbors == 0)
		return;

	_InteractingTraders.clear();
	int Nneigh = 0;
	GoodID ID = -1;
	while (randomIndivN.size() > 0)
	{
		ID = randomIndivN.back();
		randomIndivN.pop_back();
		_InteractingTraders.push_back(pair<unsigned int, CTrader*>(
			ID, (CTrader*)(_pGeneration->vpIndividuals[ID])));
		if (++Nneigh == nNeighbors)
			break;

		if (_pGeneration->vpIndividuals[ID]->_mProducers.size() > 0)
		{
			vector<GoodID> productsIDs;
			for (auto gID : _pGeneration->vpIndividuals[ID]->_mProducers)
				productsIDs.push_back(gID.first);

			std::shuffle(productsIDs.begin(), productsIDs.end(),
				CivData::pCivData->myRandomEngine);

			for (auto gID : productsIDs)
			{
				_InteractingTraders.push_back(pair<unsigned int, CTrader*>(
					gID, _pGeneration->vpIndividuals[ID]->_mProducers[gID]));
				if (++Nneigh == nNeighbors)
					break;
			}
		}
		if (Nneigh == nNeighbors)
			break;
	}

	// TheState allways in the interaction list, the last one
	_InteractingTraders.pop_back();
	_InteractingTraders.push_back(pair<unsigned int, CTrader*>(
		TheStateID, CivData::pTheState));
}

void CTrader::Make_List_of_interactingWorkers()
{
	// Get a random list of this month's interacting neighbors (Indiv or Producer)

	int nNeighbors = _pGeneration->nMaxInteractingNeighbors;

	vector<unsigned int> randomIndivN =
		_pGeneration->getRandomListOfIndividual_IDs(nNeighbors);
	nNeighbors = (int)randomIndivN.size(); // nNeighbors <= nIndividuals

	_InteractingWorkers.clear();
	int Nneigh = 0;
	GoodID ID = -1;
	while (randomIndivN.size() > 0)
	{
		ID = randomIndivN.back();
		randomIndivN.pop_back();
		_InteractingWorkers.push_back(pair<unsigned int, CTrader*>(
			ID, (CTrader*)(_pGeneration->vpIndividuals[ID])));
		if (++Nneigh == nNeighbors)
			break;
	}
}


bool CTrader::canBeEmployed()
{
	if (
		IsIndividual()
		&& !isEmployed()
		&& !_HasWorkedCurrentMonth
		&& !HasActiveProducer()
		)
		return true;
	else
		return false;
}

bool CTrader::isEmployed()
{
	return (_Manager != nullptr);
}

bool CTrader::HasActiveProducer()
{
	if (IsIndividual())
	{
		for (auto gPair : ((CIndividual*)this)->_mProducers)
			for (auto productPair : gPair.second->myProductsData)
				if (productPair.second->active)
					return true;
	}
	else
	{
		for (auto productPair : ((CProducer*)this)->myProductsData)
			if (productPair.second->active)
				return true;
	}

	return false;
}

CProducer* CTrader::getMyProducerOfProductID(GoodID productID)
{
	if (productID == workers_n)
		return nullptr;

	if (_traderType == Individual || _traderType == TheState)
	{
		for (auto gPair : this->_mProducers)
		{
			CProducer* pProd = (CProducer*)gPair.second;
			if (pProd->myProductsData.find(productID)
				!= pProd->myProductsData.end())
				return pProd;
		}
	}
	else if (_traderType == Producer)
	{
		CProducer* pProd = (CProducer*)this;
		if (pProd->myProductsData.find(productID)
			!= pProd->myProductsData.end())
			return pProd;
	}
	else
		assert(false);

	return nullptr;
}


GoodValue& CTrader::Cash()
{
	assert(_MinCash >= 0);
	return _Cash;
}

void CTrader::setMyPriceOf(GoodID gID, double price)
{
	assert(price >= 0);

	if ((*CivData::pCivData).at(CivData::kFixedPrices))
	{
		if (_myPrice[gID] == 0)
			_myPrice[gID] = price;

		return;
	}

	if (gID == workers_n)
	{
		_myPrice[workers_n] = price;
		return;
	}

	CProducer* myProducer = getMyProducerOfProductID(gID);
	if (myProducer == nullptr)
		_myPrice[gID] = price;
	else
	{
		if (price >= myProducer->myProductsData[gID]->ProductionPrice)
			_myPrice[gID] = price;
	}
}

double CTrader::myCurrentPriceOf(GoodID gID, double sellerPrice)
{
	if (gID == workers_n)
	{
		return _myPrice[workers_n];
	}

	if (_Goods_I_have.find(gID) == _Goods_I_have.end()  // Individuals
		&& _ListOfGoods_to_buy.find(gID) == _ListOfGoods_to_buy.end()//Individuals

		&& _Goods_to_sell.find(gID) == _Goods_to_sell.end()) // Producers	
		return 0; // I'n not yet interested on this good

	if (_myPrice[gID] == 0 && sellerPrice > 0)
		setMyPriceOf(gID, sellerPrice);

	return _myPrice[gID];
}


void CTrader::MakeListOfGoodsToBuy()
{
	_ListOfGoods_to_buy -= _ListOfGoods_to_buy;// reset values to 0

	for (auto gPair : _ListOfGoods_I_wish_to_have)
	{
		auto gID = gPair.first;

		assert(gID != workers_n);// Only Producers can hire workers

		GoodValue needed = max((GoodValue)0,
			_ListOfGoods_I_wish_to_have(gID) - _Goods_I_have(gID));

		// Food has a special treatment for efficiency reasons
		if (gID == food_kg && needed < 0.3 * _ListOfGoods_I_wish_to_have(food_kg))
			needed = 0;

		_ListOfGoods_to_buy[gID] = needed;
	}
}

GoodValue CTrader::GetTotalAssets()
{
	auto CurrentTimestep = _pGeneration->CurrentTimestep;
	if (CurrentTimestep == 0)
		return 0;

	auto marketPrices = CivData::pCivData->pCurrentGenerationData->MarketPrices;
	GoodValue gIhaveValue = 0, gToSellValue = 0;

	for (auto& gPair : _Goods_I_have)
	{
		GoodID gID = gPair.first;
		double value = gPair.second.quantity();// Producers: 1
		if (gID < CivData::pCivData->first_producerType)
			value *= marketPrices[gID][CurrentTimestep - 1];
		else
			continue;

		gIhaveValue += value;
	}

	for (auto& gPair : _Goods_to_sell)
	{
		GoodID gID = gPair.first;
		double value = gPair.second.quantity();// Producers: 1
		if (gID < CivData::pCivData->first_producerType)
			value *= marketPrices[gID][CurrentTimestep - 1];
		else
			continue;

		gToSellValue += value;
	}

	GoodValue totalAssets =
		gIhaveValue + gToSellValue + Cash() + _pUsedBank->ClientCurrentBalance(this);

	return totalAssets;
}

void CTrader::PayAnnualTax()
{
	if (!CivData::pCivData->bRobotsColony && !CivData::pCivData->bSingleRobot)
		CivData::pTheState->ChargeAnnualTaxFromTrader(this);
}

void CTrader::PaySellerVAT(GoodValue moneyTraded)
{
	if (!CivData::pCivData->bRobotsColony && !CivData::pCivData->bSingleRobot)
		CivData::pTheState->ChargeVATtoTrader(this, moneyTraded);
}

void CTrader::ReturnLoansToMyBank()
{
	GoodValue currentDebt = -_pUsedBank->ClientCurrentBalance(this);

	if (currentDebt <= 0 || Cash() <= 2 * _MinCash)
		return;

	GoodValue payed = min(currentDebt, Cash() - _MinCash);
	if (payed < currentDebt / 100.0)
		return;

	CBankEntry loanStatus = _pUsedBank->ClientCashOperation(this, payed);
	if (loanStatus._operationOK) // if balance = 0, account closed
		Cash() -= payed;
	_myBankAccountStatus = loanStatus;

	// Write transaction of selected Individual to output file

	auto balance = _pUsedBank->ClientCurrentBalance(this);
	if ((*CivData::pCivData)[CivData::kWriteTransactions]
		&& _ID == (*CivData::pCivData)[CivData::kWriteIndivN])
	{
		ofstream& Outf = *CivData::pCivData->pOutf;
		Outf << "\nMonth " << CivData::pCivData->currentTimestep << ", ";

		if (_traderType == Individual)
			Outf << "Indiv_" << _ID;
		else
		{
			assert(_traderType == Producer);
			Outf << CivData::pCivData->GoodID2Name[((CProducer*)this)
				->_producerType] << "_" << _ID;
		}

		Outf << " returns loan " << payed << " m.u.";
		Outf << " Balance= " << balance;
		Outf.flush();
	}

	if (balance == 0) // change Bank
		_pUsedBank = CivData::pCentralBank->getRandomBank();
}

void CTrader::BuyGoods()
{
	for (const auto& gPair : _ListOfGoods_to_buy)
	{
		if (gPair.second == 0)
			continue;

		GoodID gID = gPair.first;
		if (gID == workers_n)
		{
			Make_List_of_interactingWorkers();
			GoodValue Nhired = 0;
			for (auto nNei : _InteractingWorkers)
			{
				CTrader& neighbor = *nNei.second;

				Nhired += TradeGoodWithNeighbor(neighbor,
					gPair.second, MarketOperation::buy);
				if (Nhired == gPair.second.quantity())
					break;
			}
		}
		else
		{
			if (_Goods_to_sell(gID) > 0) // don't buy what you can produce/sell
			{
				GoodValue extra = gPair.second.quantity();
				GoodValue available = _Goods_to_sell.at(gID).quantity();
				extra = min(extra, available);
				_Goods_to_sell[gID] -= extra;
				_Goods_I_have[gID] += extra;

				_ListOfGoods_to_buy[gID] = 0;
			}
			else if (getMyProducerOfProductID(gID) == this)
			{
				// Producer: don't buy your productIDs
				_ListOfGoods_to_buy[gID] = 0;
				continue;
			}

			for (auto nNei : _InteractingTraders)
			{
				CTrader& neighbor = *nNei.second;
				if (&neighbor == this)
					continue;

				if (gPair.second <= 0)
					break;
				TradeGoodWithNeighbor(neighbor, gPair.second, MarketOperation::buy);
			}
		}
	}
}

GoodValue CTrader::TradeGoodWithNeighbor(CTrader& neighbor, const CGood& good,
	MarketOperation marketOp)
{
	GoodID gID = good._ID;
	GoodValue tradedQuantity = 0;
	if (&neighbor == this || good.quantity() == 0)
		return tradedQuantity = 0;

	if (gID == workers_n)
	{
		assert(!this->IsIndividual());
		bool hired = ((CProducer*)this)->TryToHireNeighbor(neighbor);
		if (hired)
			return 1;
		else
			return 0;
	}

	CTrader* pBuyer = 0;
	CTrader* pSeller = 0;
	GoodValue gBuyMax = 0, gSellMax = 0;
	if (marketOp == MarketOperation::buy)
	{
		gBuyMax = good.quantity();
		pBuyer = this;

		if (neighbor._Goods_to_sell(gID) <= 0)
			return tradedQuantity = 0;

		pSeller = &neighbor;
	}
	else
	{
		if (neighbor._ListOfGoods_to_buy(gID) <= 0)
			return tradedQuantity = 0;

		pBuyer = &neighbor;

		gSellMax = good.quantity();
		pSeller = this;
	}

	double priceAgreed;

	if ((*CivData::pCivData).at(CivData::kUseMoney))
	{
		priceAgreed = AgreePriceWithNeighbor(this, &neighbor, good, marketOp);
		if (priceAgreed <= 0)
			return tradedQuantity = 0;
	}
	else
		priceAgreed = 0;

	if (marketOp == MarketOperation::buy)
	{
		gBuyMax = min<GoodValue>(good.quantity(), // desired quantity
			pBuyer->MaxPurchaseQuantity(gID, priceAgreed, *pSeller));
		gSellMax = pSeller->MaxSellQuantity(gID);
	}
	else // sell
	{
		gBuyMax = pBuyer->MaxPurchaseQuantity(gID, priceAgreed, *pSeller);
		gSellMax = min<GoodValue>(good.quantity(),// try to sell this quantity
			pSeller->MaxSellQuantity(gID));
	}

	tradedQuantity = min< GoodValue>(gSellMax, gBuyMax);

	// Carry out the trade ------------------------------------------------------

	if (tradedQuantity > 0)
	{
		GoodValue moneyTraded = tradedQuantity * priceAgreed;

		// Statistics:

		int month = CivData::pCivData->currentTimestep;
		CivData::pCivData->pGeneration->thisTimestepTradedPrices[gID]
			+= priceAgreed;
		++CivData::pCivData->pGeneration->thisTimestepNtrades[gID];

		CAccountEntry sellerEntry(month, moneyTraded, gID, pBuyer->_ID, tradedQuantity);
		pSeller->_Account._Entries.push_back(sellerEntry);
		CAccountEntry buyerEntry(month, -moneyTraded, gID, pSeller->_ID, tradedQuantity);
		pBuyer->_Account._Entries.push_back(buyerEntry);

		// Pay and write transaction of selected Individual to output file

		string concept = "";
		if (moneyTraded <= pBuyer->Cash())
		{
			if ((*CivData::pCivData)[CivData::kWriteTransactions]
				&& ((*CivData::pCivData)[CivData::kWriteIndivN] == -9
					|| pBuyer->_ID == (*CivData::pCivData)[CivData::kWriteIndivN]
					|| pSeller->_ID == (*CivData::pCivData)[CivData::kWriteIndivN])
				)
				concept = " buys " + to_string(tradedQuantity) + " "
				+ CivData::pCivData->GoodID2Name[gID]
				+ ", and pays in cash= " + to_string(moneyTraded) + ", from ";

			PayInCash(pBuyer, pSeller, moneyTraded, concept);
		}
		else
		{
			if (pBuyer->Cash() < 1 * pBuyer->_MinCash)
			{
				GoodValue qtty =
					pBuyer->GetCashFromBank(1 * pBuyer->_MinCash - pBuyer->Cash());
				pBuyer->Cash() += qtty;
			}

			if (moneyTraded <= pBuyer->Cash())
			{
				if ((*CivData::pCivData)[CivData::kWriteTransactions]
					&& ((*CivData::pCivData)[CivData::kWriteIndivN] == -9
						|| pBuyer->_ID == (*CivData::pCivData)[CivData::kWriteIndivN]
						|| pSeller->_ID == (*CivData::pCivData)[CivData::kWriteIndivN])
					)
					concept = " buys " + to_string(tradedQuantity) + " "
					+ CivData::pCivData->GoodID2Name[gID]
					+ ", and pays in cash= " + to_string(moneyTraded) + ", from ";

				PayInCash(pBuyer, pSeller, moneyTraded, concept);
			}
			else
			{
				pBuyer->_MinCash = max(moneyTraded, pBuyer->_MinCash);

				if ((*CivData::pCivData)[CivData::kWriteTransactions]
					&& ((*CivData::pCivData)[CivData::kWriteIndivN] == -9
						|| pBuyer->_ID == (*CivData::pCivData)[CivData::kWriteIndivN]
						|| pSeller->_ID == (*CivData::pCivData)[CivData::kWriteIndivN])
					)
					concept = " buys " + to_string(tradedQuantity) + " "
					+ CivData::pCivData->GoodID2Name[gID]
					+ ", and transfers= " + to_string(moneyTraded) + " m.u., from ";

				bool ok = _pUsedBank->PayThroughBankTransfer(pBuyer, pSeller,
					moneyTraded, concept);
				if (!ok)
					return tradedQuantity = 0;// pBuyer Bank has not enough resources
			}
		}

		pSeller->PaySellerVAT(moneyTraded);

		pSeller->_Goods_to_sell[gID] -= tradedQuantity;

		pBuyer->_Goods_I_have[gID] += tradedQuantity;
		pBuyer->_ListOfGoods_to_buy[gID] -= tradedQuantity;
		assert(pBuyer->_ListOfGoods_to_buy[gID] >= 0);

		//--------------------------------------------------------------------------

		// Both individuals learn from this SUCCESSFUL Market interaction:

		if ((*CivData::pCivData).at(CivData::kUseMoney))
		{
			// Buyer: lower the price

			pBuyer->setMyPriceOf(gID, pBuyer->_myPrice[gID] / pBuyer->_myPriceAdapt);

			// Seller:

			double productionPrice;
			if (!pSeller->IsIndividual())// (pSeller->getMyProducerOfProductID(gID) != nullptr)
				if (pSeller->getMyProducerOfProductID(gID) != nullptr)
				{
					productionPrice =
						pSeller->getMyProducerOfProductID(gID)->myProductsData[gID]->ProductionPrice;

					pSeller->setMyPriceOf(gID,
						min(productionPrice * CivData::pCivData->maxPriceFactor,
							pSeller->_myPrice[gID] * pSeller->_myPriceAdapt));
				}
				else
				{
					pSeller->setMyPriceOf(gID,
						pSeller->_myPrice[gID] * pSeller->_myPriceAdapt);
				}
		}

		return tradedQuantity;
	}

	return tradedQuantity = 0;
}

void CTrader::WriteTransaction(CTrader* pFromTrader, CTrader* pToTrader,
	string concept)
{
	if (!CivData::pCivData->at(CivData::kWriteTransactions))
		return;

	if (concept == "")
		return;

	int indN = (*CivData::pCivData)[CivData::kWriteIndivN];
	ofstream& Outf = *CivData::pCivData->pOutf;

	Outf << "\nMonth " << _pGeneration->CurrentTimestep;

	if (pFromTrader->_traderType == Individual)
		Outf << ", Indiv_" << pFromTrader->_ID;
	else if (pFromTrader->_traderType == Producer)
		Outf << ", "
		<< CivData::pCivData->GoodID2Name[((CProducer*)pFromTrader)->_producerType]
		<< "_" << pFromTrader->_ID;
	else if (pFromTrader->_traderType == TheState)
		Outf << ", TheState";

	Outf << " " << concept << " ";

	if (pToTrader->_traderType == Individual)
		Outf << "Indiv_" << pToTrader->_ID;
	else if (pToTrader->_traderType == Producer)
		Outf << CivData::pCivData->GoodID2Name[((CProducer*)pToTrader)->_producerType]
		<< "_" << pToTrader->_ID;
	else if (pToTrader->_traderType == TheState)
		Outf << "TheState";
	//Outf << endl;

	Outf.flush();
}

bool CTrader::PayThroughBankTransfer(
	CTrader* pFromTrader, CTrader* pToTrader, GoodValue value, string concept)
{
	if (CivData::pCivData->bSingleRobot)
		return true;

	if (!(*CivData::pCivData).at(CivData::kUseMoney))
	{
		assert(value == 0);
		return true;
	}

	assert(_pGeneration->CheckGenerationBalance());//

	// Value can be + (payment) or - (charge)
	// First try to withdraw the money, because this operation can fail

	// if value>0:
	CTrader* pDraw = pFromTrader;
	CTrader* pDeposit = pToTrader;

	if (value < 0)
	{
		pDraw = pToTrader;
		pDeposit = pFromTrader;
	}

	GoodValue absVal = abs(value);
	CBankEntry accStatus =
		pDraw->_pUsedBank->ClientCashOperation(pDraw, -absVal, 120);
	if (accStatus._operationOK) // if accStatus._value = 0, account closed
	{
		pDraw->_myBankAccountStatus = accStatus;
	}
	else
	{
		assert(pDraw->_myBankAccountStatus._value == accStatus._value);
		return false;
	}

	// the pDeposit deposits the money
	accStatus = pDeposit->_pUsedBank->ClientCashOperation(pDeposit, absVal);
	if (accStatus._operationOK) // if balance = 0, account closed
	{
		pDeposit->_myBankAccountStatus = accStatus;

		assert(_pGeneration->CheckGenerationBalance());//

		WriteTransaction(pFromTrader, pToTrader, concept);

		return true;
	}
	else // operation failed (not enough Reserves), no change
	{
		assert(false);
		assert(accStatus._pTrader == pToTrader);
		assert(pDraw->_myBankAccountStatus._value == accStatus._value);
		return false;
	}
}

bool CTrader::PayInCash(CTrader* pFromTrader, CTrader* pToTrader,
	GoodValue value, string concept)
{
	if (CivData::pCivData->bSingleRobot)
		return true;

	if (!(*CivData::pCivData).at(CivData::kUseMoney))
	{
		assert(value == 0);
		return true;
	}

	if (pFromTrader->Cash() >= value)
	{
		pFromTrader->Cash() -= value;
		pToTrader->Cash() += value;

		// Write transaction of selected Individual to output file

		int indN = (*CivData::pCivData)[CivData::kWriteIndivN];

		if (pFromTrader->_ID == indN || pToTrader->_ID == indN
			|| indN == -9)
			WriteTransaction(pFromTrader, pToTrader, concept);

		return true;
	}
	else
		return false;
}

GoodValue CTrader::GetCashFromBank(GoodValue cashNeeded)
{
	GoodValue increase = 0;
	CBankEntry myCurrLoan = _pUsedBank->ClientCashOperation(this, -cashNeeded,
		3 * CivData::pCivData->stepsPerYear);
	if (myCurrLoan._operationOK) // if balance = 0, account closed
	{
		increase = _myBankAccountStatus._value - myCurrLoan._value;
		assert(increase >= 0);
	}

	_myBankAccountStatus = myCurrLoan;// let's hope we got the loan
	return increase;
}

double CTrader::AgreePriceWithNeighbor(CTrader* THIS, CTrader* neighbor,
	const CGood& good, MarketOperation marketOp)
{
	GoodID gID = good._ID;
	if (gID == workers_n)
	{
		assert(!THIS->IsIndividual() // Only Producers can hire (buy) employees
			&& marketOp == MarketOperation::buy);
		if (!neighbor->canBeEmployed())
			return 0;
	}

	// 1. Check if we have a Buyer and a Seller for this gID

	CTrader* pBuyer = THIS;
	CTrader* pSeller = neighbor;
	if (marketOp == MarketOperation::sell)
	{
		pSeller = THIS;
		pBuyer = neighbor;
		assert(!(THIS->IsIndividual() && gID == workers_n));// Individuals can't hire (buy) workers
	}

	double priceAgreed = 0;
	double buyerPrice, sellerPrice;
	if ((*CivData::pCivData).at(CivData::kFixedPrices))
	{
		buyerPrice = sellerPrice = priceAgreed =
			(*CivData::pCivData).pCurrentGenerationData->
			MarketPrices[gID][0];
	}
	else
	{
		sellerPrice = pSeller->myCurrentPriceOf(gID);
		buyerPrice = pBuyer->myCurrentPriceOf(gID, sellerPrice);

		if (buyerPrice <= 0 || sellerPrice <= 0)
			return 0;
	}


	// The Buyer's price should be higher than or equal
	// to the Seller's (workers: salary)
	if (buyerPrice >= sellerPrice)
	{
		priceAgreed = sellerPrice;// usually the price is set by the seller
		return priceAgreed;
	}
	else
	{
		// Both individuals learn from this FAILED Market interaction

		double productionPrice;
		if (gID == workers_n)
		{
			productionPrice = CivData::pCivData->minSalary;

			// Seller: lower the price up to minSalary

			pSeller->setMyPriceOf(gID,
				max(productionPrice, pSeller->_myPrice[gID] / pSeller->_myPriceAdapt));


			// Buyer: increase the price up to maxSalary
			buyerPrice = min((double)CivData::pCivData->maxSalary,
				pBuyer->_myPrice[gID] * pBuyer->_myPriceAdapt);
			pBuyer->setMyPriceOf(gID, buyerPrice);
		}
		else
		{
			CProducer* pSellerProducer = pSeller->getMyProducerOfProductID(gID);

			if (pSellerProducer != nullptr)
				productionPrice =
				pSellerProducer->myProductsData[gID]->ProductionPrice;
			else // allow non-producing Sellers, that will lower their price down to 0
				productionPrice = 0;

			// Seller: can lower the price up to productionPrice

			pSeller->setMyPriceOf(gID,
				max(productionPrice, pSeller->_myPrice[gID] / pSeller->_myPriceAdapt));


			// Buyer: increase the price if Seller can produce it,
			// otherwise don't change, just let him lower his price
			if (pSellerProducer != nullptr)
			{
				buyerPrice = min(productionPrice * CivData::pCivData->maxPriceFactor,
					max(productionPrice, pBuyer->_myPrice[gID] * pBuyer->_myPriceAdapt));
				pBuyer->setMyPriceOf(gID, buyerPrice);
			}
		}

		priceAgreed = 0;
		return priceAgreed;
	}
}

GoodValue CTrader::MaxPurchaseQuantity(GoodID gID,
	double priceAgreed, CTrader& seller)
{
	GoodValue gSellMax = seller._Goods_to_sell(gID);
	GoodValue gPurchaseMax = min(gSellMax, _ListOfGoods_to_buy(gID));

	if (!(*CivData::pCivData).at(CivData::kUseMoney))
		return gPurchaseMax;

	GoodValue maxMoneyNeeded = ceil(priceAgreed * gPurchaseMax) - Cash();
	if (maxMoneyNeeded > 0)
	{
		GoodValue qtty = GetCashFromBank(maxMoneyNeeded);
		Cash() += qtty;
	}

	gPurchaseMax = min<GoodValue>(floor(Cash() / priceAgreed), _ListOfGoods_to_buy(gID));

	return gPurchaseMax;
}

GoodValue CTrader::MaxSellQuantity(GoodID gID, GoodValue buyerQuantity)
{
	if (IsIndividual() && gID == workers_n && canBeEmployed())
		return 1; // sell only 1 worker (pSeller pointer)

	return _Goods_to_sell(gID);
}
